export interface TeacherUser {
  id: string;
  name: string;
  title: string;
  email: string;
  role: "teacher";
  photoUrl?: string;
}

export const teachersList: TeacherUser[] = [
  {
    "id": "teacher-ryan-ahlers",
    "name": "Ryan Ahlers",
    "title": "Principal/Director",
    "email": "ryanahlers@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/ryan_ahlers_68de1794a786a8.74628120.JPG"
  },
  {
    "id": "teacher-naomi-lane",
    "name": "Naomi Lane",
    "title": "Director of Academics and College Counseling",
    "email": "naomilane@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/naomi_lane_68de17ada94c56.03067490.JPG"
  },
  {
    "id": "teacher-steve-mccambridge",
    "name": "Steve McCambridge",
    "title": "Senior Advisor",
    "email": "stevemccambridge@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/steve_mccambridge_69faebf51f72c1.78451461.png"
  },
  {
    "id": "teacher-sophanarith-song",
    "name": "Sophanarith Song",
    "title": "Deputy Director",
    "email": "songsophannarith@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/song_sophannarith_68de20a08308b7.16372118.JPG"
  },
  {
    "id": "teacher-chenda-soth",
    "name": "Chenda Soth",
    "title": "Accounting Manager",
    "email": "sothchenda@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/soth_chenda_68de144d25c461.45304122.JPG"
  },
  {
    "id": "teacher-eak-sangha",
    "name": "Eak Sangha",
    "title": "IT Manager",
    "email": "eaksangha@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/eak_sangha_68de1b8f5e07d4.69721532.JPG"
  },
  {
    "id": "teacher-kong-sokthearoath",
    "name": "Kong Sokthearoath",
    "title": "Student Services Manager",
    "email": "kongsokthearoath@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/kong_sokthearoath_68de17c4ee0878.58421472.JPG"
  },
  {
    "id": "teacher-chhay-leang-eng",
    "name": "Chhay Leang Eng",
    "title": "Accounting and Purchasing",
    "email": "chhayleangeng@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chhay_leang_eng_68de1805eb4ea2.87459018.JPG"
  },
  {
    "id": "teacher-chea-bunthai",
    "name": "Chea Bunthai",
    "title": "Stock Controller",
    "email": "cheabunthai@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chea_bunthai_68de1c90938907.38486448.JPG"
  },
  {
    "id": "teacher-chouch-sreyvong",
    "name": "Chouch Sreyvong",
    "title": "IT Support",
    "email": "chouchsreyvong@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chouch_sreyvong_68de185c4ea186.34420502.JPG"
  },
  {
    "id": "teacher-kay-pheaktra",
    "name": "Kay Pheaktra",
    "title": "IT Support",
    "email": "kaypheaktra@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/kay_pheaktra_68de186939c805.29449262.JPG"
  },
  {
    "id": "teacher-sou-sreynuth",
    "name": "Sou Sreynuth",
    "title": "Student Services  ",
    "email": "sousreynuth@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/sou_sreynuth_689061cf27c942.87732801.JPG"
  },
  {
    "id": "teacher-chek-chantrea",
    "name": "Chek Chantrea",
    "title": "Executive Assistant Intern",
    "email": "chekchantrea@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chek_chantrea_6a1d1f9ce3aea9.04927573.JPG"
  },
  {
    "id": "teacher-hom-sa-oum",
    "name": "Hom Sa Oum",
    "title": "National Program Coordinator and High School Math Teacher",
    "email": "homsaoum@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hom_sa_oum_68de1883458e29.08118665.JPG"
  },
  {
    "id": "teacher-yeng-chhaily",
    "name": "Yeng Chhaily",
    "title": "National Program Coordinator and High School Khmer Teacher",
    "email": "yengchhaily@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/yeng_chhaily_68de189d05f884.47475142.JPG"
  },
  {
    "id": "teacher-chhan-sokny",
    "name": "Chhan Sokny",
    "title": "Pre-K Coordinator",
    "email": "chhansokny@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chhan_sokny_68de1960860093.60963101.JPG"
  },
  {
    "id": "teacher-chan-hon",
    "name": "Chan Hon",
    "title": "Pre-K Teacher",
    "email": "chanhon@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hon_chan_68de196f786fa5.87468138.JPG"
  },
  {
    "id": "teacher-chhat-navy",
    "name": "Chhat Navy",
    "title": "Pre-K Assistant",
    "email": "chhatnavy@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chhat_navy_68de197be70a68.42003376.JPG"
  },
  {
    "id": "teacher-theng-chanthach",
    "name": "Theng Chanthach",
    "title": "Pre-K Assistant",
    "email": "thengchanthach@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/theng_chanthach_68de198d7ee5e0.08470431.JPG"
  },
  {
    "id": "teacher-betis-louise-michaela",
    "name": "Betis Louise Michaela",
    "title": "Pre-K Assistant",
    "email": "michaelalouisebetis@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/michaela_louise_betis_68de199bad70c7.68503219.JPG"
  },
  {
    "id": "teacher-sorm-rasy",
    "name": "Sorm Rasy",
    "title": "KG Homeroom Teacher",
    "email": "sormrasy@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/sorm_rasy_68de19ae689877.76160424.JPG"
  },
  {
    "id": "teacher-sang-srey-ny",
    "name": "Sang Srey Ny",
    "title": "KG Teacher",
    "email": "sangsreyny@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/sang_srey_ny_68de19be05c353.23082541.JPG"
  },
  {
    "id": "teacher-jodie-dobson",
    "name": "Jodie Dobson",
    "title": "Grade 1 Homeroom Teacher",
    "email": "jodiedobson@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/jodie_dobson_689061fa251489.30035627.JPG"
  },
  {
    "id": "teacher-suon-bopha",
    "name": "Suon Bopha",
    "title": "Grade 2 Homeroom Teacher",
    "email": "suonbopha@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/bopha_suon_689061ed05f698.95284393.JPG"
  },
  {
    "id": "teacher-thon-sokunthea",
    "name": "Thon Sokunthea",
    "title": "Grade 1, 2, 3 Teacher",
    "email": "thonsokunthea@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/thon_sokunthea_68de19e4cfdb17.96122682.JPG"
  },
  {
    "id": "teacher-chhav-soeurn",
    "name": "Chhav Soeurn",
    "title": "Grade 1 and 2 Assistant",
    "email": "chhavsoeurn@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chhav_soeurn_68de19f373c807.82392674.JPG"
  },
  {
    "id": "teacher-lloyd-ahlers",
    "name": "Lloyd Ahlers",
    "title": "Grade 3 Homeroom Teacher and Grade 4 English Teacher",
    "email": "lloydahlers@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/lloyd_ahlers_68de1a0edf3020.98741734.JPG"
  },
  {
    "id": "teacher-mit-kim-san",
    "name": "Mit Kim San",
    "title": "Grade 3 and 4 Assistant",
    "email": "mitkimsan@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/mit_kim_san_68de1a230e3ae1.95049162.JPG"
  },
  {
    "id": "teacher-chan-leakhena",
    "name": "Chan Leakhena",
    "title": "Grade 3 Math Teacher and High School Assistant",
    "email": "chanleakhena@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chan_leakhena_68de1a38620f63.99223346.JPG"
  },
  {
    "id": "teacher-yeamtot-srey-im",
    "name": "Yeamtot Srey Im",
    "title": "Grade 4 Homeroom Teacher and Grade 3 Math and Science Teacher",
    "email": "yeamtotsreyim@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/yeamtot_srey_im_68de1a46185276.43267823.JPG"
  },
  {
    "id": "teacher-so-chantrea",
    "name": "So Chantrea",
    "title": "Grade 4, 5, and 6 Teacher",
    "email": "sochantrea@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/so_chantrea_68de1a54125085.71716909.JPG"
  },
  {
    "id": "teacher-nina-hoogervorst",
    "name": "Nina Hoogervorst",
    "title": "Grade 5 Homeroom Teacher",
    "email": "ninahoogervorst@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/nina_hoogervorst_68de1a64b47e89.21170106.JPG"
  },
  {
    "id": "teacher-tab-sophy",
    "name": "Tab Sophy",
    "title": "Grade 5 and 6 Assistant",
    "email": "tabsophy@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/tab_sophy_68de1a75b0e213.40260703.JPG"
  },
  {
    "id": "teacher-hannah-tagg",
    "name": "Hannah Tagg",
    "title": "Grade 6 Homeroom Teacher and Grade 6 and 7 English Teacher",
    "email": "hannahtagg@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hannah_tagg_68de1a860745d8.59703005.JPG"
  },
  {
    "id": "teacher-chheng-yorng-chhieng",
    "name": "Chheng Yorng Chhieng",
    "title": "Grade 6 Math, AP Computer Science and Economics Teacher",
    "email": "chhengyorngchhieng@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chheng_yorng_chhieng_68de1a90b73538.18298417.JPG"
  },
  {
    "id": "teacher-mark-bailey",
    "name": "Mark Bailey",
    "title": "Grade 7 Homeroom Teacher, and Grade 5, 6, and 7 Science and AP Computer Science Teacher",
    "email": "markbailey@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/mark_bailey_68de1aac21cdd2.78723294.JPG"
  },
  {
    "id": "teacher-ngov-sok-eng",
    "name": "Ngov Sok Eng",
    "title": "Grade 7 Math Teacher and High School Assistant",
    "email": "ngovsokeng@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/ngov_sok_eng_68de1abc0d90b1.80431745.JPG"
  },
  {
    "id": "teacher-bun-usa",
    "name": "Bun Usa",
    "title": "Librarian and Testing Coordinator",
    "email": "bunusa@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/bun_usa_68de1aca237167.85327994.JPG"
  },
  {
    "id": "teacher-hang-sokcha",
    "name": "Hang Sokcha",
    "title": "High School Math Teacher",
    "email": "hangsokcha@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hang_sokcha_692ff4ad54a956.42204157.JPG"
  },
  {
    "id": "teacher-walker-hedgepath",
    "name": "Walker Hedgepath",
    "title": "High School English and History Lead",
    "email": "walkerhedgepath@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/walker_hedgepath_68de1ae7a0ca69.90423725.JPG"
  },
  {
    "id": "teacher-phai-vanny",
    "name": "Phai Vanny",
    "title": "High School Math and Science Teacher",
    "email": "phaivanny@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/phai_vanny_689061ddad5098.30078857.JPG"
  },
  {
    "id": "teacher-helga-joshua",
    "name": "Helga Joshua",
    "title": "High School Science Teacher",
    "email": "helgajoshua@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/helga_joshua_68906244dc7585.89215490.JPG"
  },
  {
    "id": "teacher-eang-pichsorphea",
    "name": "Eang Pichsorphea",
    "title": "High School Science Teacher",
    "email": "eangpichsorphea@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/eang_pichsorphea_68de1af5ed1c57.84163405.JPG"
  },
  {
    "id": "teacher-sek-srey-mou",
    "name": "Sek Srey Mou",
    "title": "High School History and Geography Teacher",
    "email": "seksreymou@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/sek_srey_mou_68f1e1a78ed3c6.77993484.JPG"
  },
  {
    "id": "teacher-but-sreyoun",
    "name": "But Sreyoun",
    "title": "High School Science Teacher",
    "email": "butsreyoun@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/but_sreyoun_68de1b27b634d8.85166338.JPG"
  },
  {
    "id": "teacher-lann-alang",
    "name": "Lann Alang",
    "title": "High School Khmer Teacher",
    "email": "lannalang@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/Lann_Alang.JPG"
  },
  {
    "id": "teacher-ae-vichheka",
    "name": "Ae Vichheka",
    "title": "Intern Teacher",
    "email": "aevichheka@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/ae_vichheka_68de0021c319c2.23621133.JPG"
  },
  {
    "id": "teacher-chhit-boramey",
    "name": "Chhit Boramey",
    "title": "Intern",
    "email": "chhitboramey@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/chhit_boramey_68f1d91b1f75e8.88272035.JPG"
  },
  {
    "id": "teacher-hann-kaknika",
    "name": "Hann Kaknika",
    "title": "Intern Teaching Assistant",
    "email": "hannkaknika@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hann_kaknika_68de21524372b3.71668392.JPG"
  },
  {
    "id": "teacher-hong-malen",
    "name": "Hong Malen",
    "title": "Intern Admin",
    "email": "hongmalen@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hong_malen_68e4c8cd961542.07742945.Jpg"
  },
  {
    "id": "teacher-hun-sokchanra",
    "name": "Hun Sokchanra",
    "title": "Intern Teaching Assistant",
    "email": "hunsokchanra@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hun_sokchanra_68de21630df081.61754085.JPG"
  },
  {
    "id": "teacher-im-sreynong",
    "name": "Im Sreynong",
    "title": "Intern Teacher",
    "email": "imsreynong@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/im_sreynong_68ddfffd98ea72.18939113.JPG"
  },
  {
    "id": "teacher-ly-vichara",
    "name": "Ly Vichara",
    "title": "Intern Teaching Assistant",
    "email": "lyvichara@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/ly_vichara_68de2174a9e660.88454948.JPG"
  },
  {
    "id": "teacher-eleanor-harris",
    "name": "Eleanor Harris",
    "title": "Teacher",
    "email": "eleanorharris@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/eleanor_harris_692919ad86acc8.50643325.JPG"
  },
  {
    "id": "teacher-vuth-sinady",
    "name": "Vuth Sinady",
    "title": "Media and Communication Intern",
    "email": "vuthsinady@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/vuth_sinady_69b8bd0887c557.34518752.JPG"
  },
  {
    "id": "teacher-hoan-liheng",
    "name": "Hoan Liheng",
    "title": "PE Coach",
    "email": "hoanliheng@jpa.org.kh",
    role: "teacher",
    "photoUrl": "https://apps.jpa.org.kh/images/staff_photos/hoan_liheng_69b7a0b8ee7f92.80550259.JPG"
  }
];
