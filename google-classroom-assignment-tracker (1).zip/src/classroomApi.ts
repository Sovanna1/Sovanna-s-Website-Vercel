import { Course, UnifiedAssignment, NotificationItem, Contact } from "./types";
import { teachersList } from "./teachersData";
import { studentsList } from "./studentsData";

const COURSE_COLORS = ["indigo", "rose", "emerald", "violet", "amber", "orange", "cyan", "pink", "slate"];

/**
 * Fetch and map official Google Classroom API data
 */
export async function fetchRealGoogleClassroomData(accessToken: string): Promise<{
  courses: Course[];
  assignments: UnifiedAssignment[];
  contacts: Contact[];
  announcements: NotificationItem[];
}> {
  try {
    const coursesRes = await fetch("https://classroom.googleapis.com/v1/courses?courseStates=ACTIVE", {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    
    if (!coursesRes.ok) {
      throw new Error(`Google Classroom API error: ${coursesRes.statusText}`);
    }
    
    const coursesVal = await coursesRes.json();
    const googleCourses: any[] = coursesVal.courses || [];
    
    const mappedCourses: Course[] = googleCourses.map((c, idx) => ({
      id: c.id,
      name: c.name,
      section: c.section || "Active Class",
      descriptionHeading: c.descriptionHeading || c.name,
      description: c.description || "Class imported from Google Classroom.",
      alternateLink: c.alternateLink,
      color: COURSE_COLORS[idx % COURSE_COLORS.length]
    }));
    
    const activeCourses = mappedCourses.slice(0, 8);
    const assignmentsList: UnifiedAssignment[] = [];
    const contactsList: Contact[] = [];
    const announcementsList: NotificationItem[] = [];
    
    await Promise.all(activeCourses.map(async (course) => {
      try {
        // Fetch coursework
        const cwRes = await fetch(`https://classroom.googleapis.com/v1/courses/${course.id}/courseWork`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (cwRes.ok) {
          const cwData = await cwRes.json();
          const list: any[] = cwData.courseWork || [];
          list.forEach(item => {
            let parsedDueDate: Date | null = null;
            if (item.dueDate) {
              const { year, month, day } = item.dueDate;
              parsedDueDate = new Date(year, month - 1, day);
            }
            
            assignmentsList.push({
              id: item.id,
              courseId: course.id,
              courseName: course.name,
              courseColor: course.color || "indigo",
              title: item.title,
              description: item.description || "No description provided.",
              maxPoints: item.maxPoints || 100,
              dueDate: parsedDueDate,
              state: "assigned",
              alternateLink: item.alternateLink,
              updateTime: item.updateTime || new Date().toISOString()
            });
          });
        }
        
        // Fetch teachers
        const teachersRes = await fetch(`https://classroom.googleapis.com/v1/courses/${course.id}/teachers`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (teachersRes.ok) {
          const tData = await teachersRes.json();
          const teachers: any[] = tData.teachers || [];
          teachers.forEach(t => {
            const profile = t.profile || {};
            contactsList.push({
              id: profile.id || `teacher-${Date.now()}-${Math.random()}`,
              name: profile.name?.fullName || "Google Instructor",
              email: profile.emailAddress,
              photoUrl: profile.photoUrl || "",
              role: "teacher",
              title: "Google Classroom Teacher"
            });
          });
        }

        // Fetch students
        const studentsRes = await fetch(`https://classroom.googleapis.com/v1/courses/${course.id}/students`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (studentsRes.ok) {
          const sData = await studentsRes.json();
          const students: any[] = sData.students || [];
          students.forEach(s => {
            const profile = s.profile || {};
            contactsList.push({
              id: profile.id || `student-${Date.now()}-${Math.random()}`,
              name: profile.name?.fullName || "Classmate",
              email: profile.emailAddress,
              photoUrl: profile.photoUrl || "",
              role: "classmate",
              title: `Student in ${course.name}`
            });
          });
        }

        // Fetch announcements
        const annRes = await fetch(`https://classroom.googleapis.com/v1/courses/${course.id}/announcements`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (annRes.ok) {
          const annData = await annRes.json();
          const announcements: any[] = annData.announcements || [];
          announcements.forEach(a => {
            announcementsList.push({
              id: a.id,
              type: "new",
              message: `[${course.name}] Announcement: ${a.text ? a.text.substring(0, 150) + (a.text.length > 150 ? "..." : "") : "New post on stream"}`,
              timestamp: new Date(a.creationTime || Date.now()),
              read: false,
              assignmentId: a.id
            });
          });
        }
        
      } catch (err) {
        console.warn(`Error loading details for course ${course.name}:`, err);
      }
    }));
    
    // De-duplicate contacts list by email
    const uniqueContacts: Contact[] = [];
    const contactEmails = new Set<string>();
    contactsList.forEach(c => {
      if (c.email) {
        if (!contactEmails.has(c.email)) {
          contactEmails.add(c.email);
          uniqueContacts.push(c);
        }
      } else {
        uniqueContacts.push(c);
      }
    });

    return {
      courses: mappedCourses,
      assignments: assignmentsList,
      contacts: uniqueContacts.length > 0 ? uniqueContacts : getSimulatedContacts(),
      announcements: announcementsList
    };
    
  } catch (error) {
    console.error("fetchRealGoogleClassroomData failed:", error);
    throw error;
  }
}

// Persisted session simulated state for coursework updates
let simulationTimestep = 0;

/**
 * Triggers a simulated offline update event to show live classroom feedback loops
 */
export function triggerSimulatedUpdate(onNotification: (notif: NotificationItem) => void): UnifiedAssignment[] {
  simulationTimestep++;
  
  onNotification({
    id: `sim-notif-${Date.now()}`,
    type: "sync",
    message: "Offline local sync complete. Roster checks up-to-date.",
    timestamp: new Date()
  });

  return [];
}

/**
 * Reset simulated state (offline)
 */
export function resetSimulation(): UnifiedAssignment[] {
  simulationTimestep = 0;
  return [];
}

/**
 * Returns empty array initial offline assignments
 */
export function getInitialSimulatedAssignments(email: string = "student@school-classroom.org"): UnifiedAssignment[] {
  return [];
}

/**
 * Returns default empty array of courses for fallbacks
 */
export function getSimulatedCourses(email: string = "student@school-classroom.org"): Course[] {
  return [];
}

/**
 * Retrieves the actual list of classmates and instructors
 */
export function getSimulatedContacts(): Contact[] {
  return teachersList.map(t => ({
    id: t.id,
    name: t.name,
    email: t.email,
    photoUrl: t.photoUrl || "",
    phone: "",
    role: "teacher",
    title: t.title
  }));
}

/**
 * Dynamically resolves and assigns academic classrooms (courses) to a teacher
 * based on their specific title and the subjects they are designated to teach
 */
export function getTeacherSpecificCourses(teacherName: string, titleStr: string): Course[] {
  const normName = teacherName.toLowerCase().trim();
  const n = titleStr.toLowerCase();
  const courses: Course[] = [];

  // 1. Sok Eng
  if (normName.includes("sok eng")) {
    return [
      { id: "se-1", name: "Math G7", section: "Room H7", descriptionHeading: "Math G7", description: "Grade 7 Mathematics.", color: "indigo" },
      { id: "se-2", name: "Math G9", section: "Room T5", descriptionHeading: "Math G9", description: "Grade 9 Mathematics.", color: "indigo" },
      { id: "se-3", name: "Independent Study G12", section: "Room T4", descriptionHeading: "Independent Study", description: "Grade 12 Independent Study.", color: "slate" },
    ];
  }
  
  // 2. Sreymou Sek
  if (normName.includes("sreymou sek") || normName.includes("srey mou") || normName.includes("sreymou")) {
    return [
      { id: "sm-1", name: "History G7", section: "Room H7", descriptionHeading: "History G7", description: "Grade 7 History.", color: "rose" },
      { id: "sm-2", name: "History G8", section: "Room H6", descriptionHeading: "History G8", description: "Grade 8 History.", color: "rose" },
      { id: "sm-3", name: "History G9", section: "Room T5", descriptionHeading: "History G9", description: "Grade 9 History.", color: "rose" },
      { id: "sm-4", name: "History G10", section: "Room H3", descriptionHeading: "History G10", description: "Grade 10 History.", color: "rose" },
      { id: "sm-5", name: "History G11", section: "Room T3", descriptionHeading: "History G11", description: "Grade 11 History.", color: "rose" },
      { id: "sm-6", name: "History G12", section: "Room T5/T6", descriptionHeading: "History G12", description: "Grade 12 History.", color: "rose" },
      { id: "sm-7", name: "Geography G9", section: "Room T5", descriptionHeading: "Geography G9", description: "Grade 9 Geography.", color: "emerald" },
    ];
  }

  // 3. Sorphea Eang
  if (normName.includes("sorphea eang") || normName.includes("sorphea")) {
    return [
      { id: "sp-1", name: "Physics 7", section: "Room H7", descriptionHeading: "Physics G7", description: "Grade 7 Physics.", color: "emerald" },
      { id: "sp-2", name: "Physics 8", section: "Room T5", descriptionHeading: "Physics G8", description: "Grade 8 Physics.", color: "emerald" },
      { id: "sp-3", name: "Physics G9", section: "Room T5", descriptionHeading: "Physics G9", description: "Grade 9 Physics.", color: "emerald" },
      { id: "sp-4", name: "Physics 11", section: "Room T4/T6", descriptionHeading: "Physics G11", description: "Grade 11 Physics.", color: "emerald" },
      { id: "sp-5", name: "Physics 12", section: "Room T6", descriptionHeading: "Physics G12", description: "Grade 12 Physics.", color: "emerald" },
    ];
  }

  // 4. Sreyoun But
  if (normName.includes("sreyoun but") || normName.includes("sreyoun") || normName.includes("srey oun")) {
    return [
      { id: "sb-1", name: "Biology G7", section: "Room H7", descriptionHeading: "Biology G7", description: "Grade 7 Biology.", color: "emerald" },
      { id: "sb-2", name: "Chemistry G8", section: "Room T5", descriptionHeading: "Chemistry G8", description: "Grade 8 Chemistry.", color: "indigo" },
      { id: "sb-3", name: "Biology G9", section: "Room T5", descriptionHeading: "Biology G9", description: "Grade 9 Biology.", color: "emerald" },
      { id: "sb-4", name: "Chemistry G9", section: "Room T5", descriptionHeading: "Chemistry G9", description: "Grade 9 Chemistry.", color: "indigo" },
      { id: "sb-5", name: "Chemistry G10", section: "Room T5", descriptionHeading: "Chemistry G10", description: "Grade 10 Chemistry.", color: "indigo" },
      { id: "sb-6", name: "Chemistry G11", section: "Room T4", descriptionHeading: "Chemistry G11", description: "Grade 11 Chemistry.", color: "indigo" },
      { id: "sb-7", name: "Chemistry G12", section: "Room T3/T6", descriptionHeading: "Chemistry G12", description: "Grade 12 Chemistry.", color: "indigo" },
    ];
  }

  // 5. Sreynong Im
  if (normName.includes("sreynong im") || normName.includes("sreynong")) {
    return [
      { id: "sn-1", name: "US History G7", section: "Room H7", descriptionHeading: "US History G7", description: "Grade 7 US History.", color: "rose" },
      { id: "sn-2", name: "World History", section: "Room H2", descriptionHeading: "World History", description: "World History.", color: "rose" },
    ];
  }

  // 6. Mark Bailey
  if (normName.includes("mark bailey") || normName.includes("bailey")) {
    return [
      { id: "mb-1", name: "Science G5", section: "Grade 5", descriptionHeading: "Science G5", description: "Grade 5 Science.", color: "emerald" },
      { id: "mb-2", name: "Science G6", section: "Grade 6", descriptionHeading: "Science G6", description: "Grade 6 Science.", color: "emerald" },
      { id: "mb-3", name: "Science G7", section: "Room H7", descriptionHeading: "Science G7", description: "Grade 7 Science.", color: "emerald" },
    ];
  }

  // 7. Hannah Tagg
  if (normName.includes("hannah tagh") || normName.includes("hannah tagg") || normName.includes("tagg")) {
    return [
      { id: "ht-1", name: "English G6", section: "Grade 6", descriptionHeading: "English G6", description: "Grade 6 English.", color: "violet" },
      { id: "ht-2", name: "English G7", section: "Room H7", descriptionHeading: "English G7", description: "Grade 7 English.", color: "violet" },
    ];
  }

  // 8. Saoum Hom
  if (normName.includes("saoum hom") || normName.includes("saoum") || normName.includes("sa oum")) {
    return [
      { id: "sh-1", name: "Algebra 1 G8", section: "Room T6", descriptionHeading: "Algebra 1 G8", description: "Grade 8 Algebra 1.", color: "indigo" },
      { id: "sh-2", name: "Math G8", section: "Room T6", descriptionHeading: "Math G8", description: "Grade 8 Math.", color: "indigo" },
      { id: "sh-3", name: "Earth Science G9", section: "Room T5", descriptionHeading: "Earth Science G9", description: "Grade 9 Earth Science.", color: "emerald" },
      { id: "sh-4", name: "Math G9", section: "Room T6", descriptionHeading: "Math G9", description: "Grade 9 Math.", color: "indigo" },
      { id: "sh-5", name: "Math G10", section: "Room T6/H3", descriptionHeading: "Math G10", description: "Grade 10 Math.", color: "indigo" },
      { id: "sh-6", name: "Math G11", section: "Room T3/T6", descriptionHeading: "Math G11", description: "Grade 11 Math.", color: "indigo" },
      { id: "sh-7", name: "Math G12", section: "Room T6", descriptionHeading: "Math G12", description: "Grade 12 Math.", color: "indigo" },
    ];
  }

  // 9. Chhaily Yeng
  if (normName.includes("chhaily yeng") || normName.includes("chhaily")) {
    return [
      { id: "cy-1", name: "Khmer G7", section: "Room H7", descriptionHeading: "Khmer G7", description: "Grade 7 Khmer.", color: "amber" },
      { id: "cy-2", name: "Khmer G8", section: "Room H6/T5", descriptionHeading: "Khmer G8", description: "Grade 8 Khmer.", color: "amber" },
      { id: "cy-3", name: "Khmer G9", section: "Room T5", descriptionHeading: "Khmer G9", description: "Grade 9 Khmer.", color: "amber" },
      { id: "cy-4", name: "Morals and Ethics G9", section: "Room T5", descriptionHeading: "Morals & Ethics G9", description: "Grade 9 Morals and Ethics.", color: "orange" },
      { id: "cy-5", name: "Khmer G10", section: "Room H3/T5", descriptionHeading: "Khmer G10", description: "Grade 10 Khmer.", color: "amber" },
    ];
  }

  // 10. Vanny Phai
  if (normName.includes("vanny phai") || normName.includes("vanny")) {
    return [
      { id: "vp-1", name: "Coding 7", section: "Room H5", descriptionHeading: "Coding 7", description: "Grade 7 Coding.", color: "cyan" },
      { id: "vp-2", name: "Coding 8", section: "Room H5", descriptionHeading: "Coding 8", description: "Grade 8 Coding.", color: "cyan" },
      { id: "vp-3", name: "Biology G9", section: "Room H2", descriptionHeading: "Biology G9", description: "Grade 9 Biology.", color: "emerald" },
      { id: "vp-4", name: "Algebra 2", section: "Room T5", descriptionHeading: "Algebra 2", description: "Algebra 2.", color: "indigo" },
      { id: "vp-5", name: "Grade 10 Project", section: "Room H1", descriptionHeading: "Grade 10 Project", description: "Grade 10 Projects.", color: "violet" },
      { id: "vp-6", name: "PROJECTS", section: "Room H2", descriptionHeading: "Projects", description: "General Projects.", color: "violet" },
    ];
  }

  // 11. Yorngchhieng Chheng
  if (normName.includes("yorngchhieng chheng") || normName.includes("yorng chhieng") || normName.includes("yorngchhieng")) {
    return [
      { id: "yc-1", name: "Math G6", section: "Grade 6", descriptionHeading: "Math G6", description: "Grade 6 Math.", color: "indigo" },
      { id: "yc-2", name: "Pre Algebra", section: "Room H7", descriptionHeading: "Pre Algebra", description: "Pre Algebra.", color: "indigo" },
      { id: "yc-3", name: "Grade 11 Project", section: "Room T5", descriptionHeading: "Grade 11 Project", description: "Grade 11 Project.", color: "violet" },
    ];
  }

  // 12. Walker Hedgepath
  if (normName.includes("walker hedgepath") || normName.includes("hedgepath")) {
    return [
      { id: "wh-1", name: "English", section: "Room T3", descriptionHeading: "English", description: "General English.", color: "violet" },
      { id: "wh-2", name: "Writing Skills/College Prep", section: "Room T3", descriptionHeading: "Writing/College Prep", description: "Writing Skills and College Prep.", color: "violet" },
      { id: "wh-3", name: "English 10/11 HL", section: "Room T3", descriptionHeading: "English 10/11 HL", description: "English 10/11 Higher Level.", color: "violet" },
      { id: "wh-4", name: "PROJECTS", section: "Room H2", descriptionHeading: "Projects", description: "General Projects.", color: "violet" },
    ];
  }

  // 13. Sokcha Hang
  if (normName.includes("sokcha hang") || normName.includes("sokcha")) {
    return [
      { id: "shg-1", name: "Algebra 2", section: "Room H3", descriptionHeading: "Algebra 2", description: "Algebra 2.", color: "indigo" },
      { id: "shg-2", name: "AP Calculus Headstart 10", section: "Room H3", descriptionHeading: "AP Calc 10", description: "AP Calculus Headstart Grade 10.", color: "indigo" },
      { id: "shg-3", name: "AP Calculus Headstart 11", section: "Room H3", descriptionHeading: "AP Calc 11", description: "AP Calculus Headstart Grade 11.", color: "indigo" },
      { id: "shg-4", name: "AP Calculus BC Headstart", section: "Room H3", descriptionHeading: "AP Calc BC", description: "AP Calculus BC Headstart.", color: "indigo" },
    ];
  }

  // 14. Helga Joshua
  if (normName.includes("helga joshua") || normName.includes("joshua")) {
    return [
      { id: "hj-1", name: "Physical Science", section: "Room H1", descriptionHeading: "Physical Science", description: "Physical Science.", color: "emerald" },
      { id: "hj-2", name: "Personal Writing", section: "Room H1", descriptionHeading: "Personal Writing", description: "Personal Writing.", color: "violet" },
      { id: "hj-3", name: "Grade 10 Project", section: "Room H1", descriptionHeading: "Grade 10 Project", description: "Grade 10 Project.", color: "violet" },
    ];
  }

  if (normName.includes("chek chantrea")) {
    courses.push(
      {
        id: `course-chantrea-1`,
        name: "Algebra 1 & Foundations",
        section: "Grade 9",
        descriptionHeading: "Algebra I Core Math Block",
        description: "Linear equations, graphing, systems of equations, and inequalities.",
        color: "indigo"
      },
      {
        id: `course-chantrea-2`,
        name: "Introduction to General Science",
        section: "Grade 9",
        descriptionHeading: "Introductory Science Survey",
        description: "Surveying earth sciences, biological systems, and simple mechanics.",
        color: "emerald"
      }
    );
  } else if (normName.includes("eleanor harris")) {
    courses.push(
      {
        id: `course-harris-1`,
        name: "Secondary Advanced English",
        section: "Grade 10-11",
        descriptionHeading: "Secondary Language Arts Syllabus",
        description: "Fostering analytical critique, advanced speech, and vocabulary mastery.",
        color: "violet"
      },
      {
        id: `course-harris-2`,
        name: "Academic Essay Writing",
        section: "Grade 11-12",
        descriptionHeading: "Scholarly Research & Citation Standards",
        description: "Preparing juniors & seniors for university-level thesis drafting.",
        color: "rose"
      }
    );
  } else {
    // Dynamic parsing from title
    if (n.includes("math")) {
      if (n.includes("grade 3")) {
        courses.push({
          id: `course-dyn-math-3`,
          name: "Grade 3 Mathematics",
          section: "Grade 3",
          descriptionHeading: "Primary Math Block - Grade 3",
          description: "Multiplication, division, simple fractions, and foundational geometry.",
          color: "indigo"
        });
      }
      if (n.includes("grade 6")) {
        courses.push({
          id: `course-dyn-math-6`,
          name: "Grade 6 Mathematics",
          section: "Grade 6",
          descriptionHeading: "Middle School Math Block - Grade 6",
          description: "Ratios, proportions, negative numbers, and early algebraic expressions.",
          color: "indigo"
        });
      }
      if (n.includes("grade 7")) {
        courses.push({
          id: `course-dyn-math-7`,
          name: "Grade 7 Mathematics",
          section: "Grade 7",
          descriptionHeading: "Middle School Math Block - Grade 7",
          description: "Proportional relationships, linear equations, and geometric measurements.",
          color: "indigo"
        });
      }
      if (n.includes("high school") || n.includes("ap")) {
        courses.push(
          {
            id: `course-dyn-hsmath-1`,
            name: "High School Algebra & Precalculus",
            section: "Grade 10-12",
            descriptionHeading: "Upper Academy Mathematics",
            description: "Advanced trigonometry, sequences, series, and early calculus concepts.",
            color: "indigo"
          },
          {
            id: `course-dyn-hsmath-2`,
            name: "AP Calculus AB",
            section: "Grade 11-12",
            descriptionHeading: "Advanced Placement Calculus AB",
            description: "Limits, derivatives, integrals, and the Fundamental Theorem of Calculus.",
            color: "violet"
          }
        );
      }
      if (courses.length === 0) {
        courses.push({
          id: `course-dyn-math-gen`,
          name: "General Mathematics",
          section: "Mixed Grades",
          descriptionHeading: "Core Mathematics Curriculum",
          description: "Developing robust computational skills, math modeling, and logic.",
          color: "indigo"
        });
      }
    }

    if (n.includes("english")) {
      if (n.includes("grade 4")) {
        courses.push({
          id: `course-dyn-eng-4`,
          name: "Grade 4 English Language Arts",
          section: "Grade 4",
          descriptionHeading: "Elementary Reading & Grammar",
          description: "Developing fluid reading comprehension, writing forms, and vocabulary.",
          color: "violet"
        });
      }
      if (n.includes("grade 6") || n.includes("grade 7")) {
        courses.push(
          {
            id: `course-dyn-eng-6`,
            name: "Grade 6 English Literature",
            section: "Grade 6",
            descriptionHeading: "Grade 6 Story & Context Studies",
            description: "Analysing characters, themes, and creative structures.",
            color: "violet"
          },
          {
            id: `course-dyn-eng-7`,
            name: "Grade 7 English Grammar & Writing",
            section: "Grade 7",
            descriptionHeading: "Grade 7 Persuasive Essays & Composition",
            description: "Strengthening structured prose, paragraphing, and evidence.",
            color: "indigo"
          }
        );
      }
      if (n.includes("high school") || n.includes("ap English")) {
        courses.push({
          id: `course-dyn-hseng`,
          name: "AP English Literature & Composition",
          section: "High School",
          descriptionHeading: "AP English Lit Roster Block",
          description: "Rigorous college-level analysis of fiction and poetry.",
          color: "violet"
        });
      }
      if (courses.length === 0) {
        courses.push({
          id: `course-dyn-eng-gen`,
          name: "English & Communication Study",
          section: "Mixed Grades",
          descriptionHeading: "Language Arts Coursework",
          description: "Improving reading speed, comprehension, and essays.",
          color: "violet"
        });
      }
    }

    if (n.includes("science")) {
      if (n.includes("grade 5") || n.includes("grade 6") || n.includes("grade 7") || n.includes("science Teacher")) {
        courses.push(
          {
            id: `course-dyn-science-elem`,
            name: "Middle School General Science",
            section: "Grade 5-7",
            descriptionHeading: "Integrated Environmental & Physical Science",
            description: "Observing changes, ecosystem lifecycles, and atomic properties.",
            color: "emerald"
          }
        );
      }
      if (n.includes("high school") || n.includes("ap")) {
        courses.push(
          {
            id: `course-dyn-science-hs1`,
            name: "AP Chemistry",
            section: "Grade 11-12",
            descriptionHeading: "Organic & Physical Chemistry AP Blocks",
            description: "Stoichiometry, electron structure, equilibrium, and kinetics.",
            color: "emerald"
          },
          {
            id: `course-dyn-science-hs2`,
            name: "AP Physics C",
            section: "Grade 11-12",
            descriptionHeading: "Calculus-Based Engineering Physics",
            description: "Calculus-based physics exploring mechanics, forces, and motion.",
            color: "cyan"
          }
        );
      }
      if (courses.length === 0) {
        courses.push({
          id: `course-dyn-sci-gen`,
          name: "General Sciences & Lab",
          section: "Secondary",
          descriptionHeading: "Introductory Laboratory Sciences",
          description: "Investigating the natural world through experiments and hypothesis.",
          color: "emerald"
        });
      }
    }

    if (n.includes("history") || n.includes("geography") || n.includes("social studies")) {
      courses.push(
        {
          id: `course-dyn-hist-1`,
          name: "AP World History",
          section: "High School",
          descriptionHeading: "Global Historical Movements",
          description: "Timelines, power systems, cultural shifts, and primary sources.",
          color: "rose"
        },
        {
          id: `course-dyn-hist-2`,
          name: "AP Human Geography",
          section: "High School",
          descriptionHeading: "Advanced Geography & Anthro-Studies",
          description: "Researching human-environment interactions and demographic structures.",
          color: "emerald"
        }
      );
    }

    if (n.includes("khmer")) {
      courses.push(
        {
          id: `course-dyn-khmer-1`,
          name: "High School Khmer Literature",
          section: "Grade 10-12",
          descriptionHeading: "Classical Khmer Prose & Poetry",
          description: "Mastering the rules, historical texts, and deep reading of Khmer classics.",
          color: "amber"
        },
        {
          id: `course-dyn-khmer-2`,
          name: "Khmer History & Cultural Heritage",
          section: "Grade 10-12",
          descriptionHeading: "Angkorian History & Social Principles",
          description: "A complete survey of historical events, arts, and traditions in Cambodia.",
          color: "orange"
        }
      );
    }

    if (n.includes("computer science") || n.includes("ap csp")) {
      courses.push({
        id: `course-dyn-cs`,
        name: "AP Computer Science A",
        section: "High School",
        descriptionHeading: "Java Programming & Algorithms",
        description: "Object-oriented software development, variables, arrays, lists, recursion.",
        color: "cyan"
      });
    }

    if (n.includes("economics")) {
      courses.push({
        id: `course-dyn-econ`,
        name: "AP Microeconomics",
        section: "High School",
        descriptionHeading: "AP Microeconomics Block",
        description: "Supply and demand, market mechanisms, perfect competition, monopolies.",
        color: "rose"
      });
    }

    if (n.includes("pe ") || n.includes("coach") || n.includes("physical education")) {
      courses.push({
        id: `course-dyn-pe`,
        name: "Health & Physical Education",
        section: "All Grades",
        descriptionHeading: "Active Sports & Personal Health",
        description: "Developing athletic skills, team collaboration, and lifetime wellness.",
        color: "orange"
      });
    }

    if (n.includes("pre-k") || n.includes("pk") || (n.includes("assistant") && n.includes("pre-k")) || n.includes("pred-k")) {
      courses.push({
        id: `course-dyn-pk`,
        name: "Pre-K Early Learning Block",
        section: "Pre-K",
        descriptionHeading: "Cognitive Play & Discovery",
        description: "Encouraging curiosity, motor skills, simple phonetic sounds, and social learning.",
        color: "teal"
      });
    }

    if (n.includes("kg ") || n.includes("kindergarten")) {
      courses.push(
        {
          id: `course-dyn-kg-1`,
          name: "Kindergarten Reading Circle",
          section: "Kindergarten",
          descriptionHeading: "KG Phonics & Literacy",
          description: "Interactive storybook sessions, phonemes, simple words, and reading tracks.",
          color: "pink"
        },
        {
          id: `course-dyn-kg-2`,
          name: "Kindergarten Math & Colors",
          section: "Kindergarten",
          descriptionHeading: "KG Basics & Arithmetic",
          description: "Counting systems, shapes, classifications, and color relationships.",
          color: "violet"
        }
      );
    }

    if (n.includes("grade 1") || n.includes("grade 1,")) {
      courses.push({
        id: `course-dyn-g1`,
        name: "Grade 1 Elementary Homeroom",
        section: "Grade 1",
        descriptionHeading: "Primary Grade 1 Curriculums",
        description: "Reading development, spelling worksheets, basic writing practices.",
        color: "indigo"
      });
    }

    if (n.includes("grade 2") || n.includes("grade 1, 2") || n.includes("grade 2 homeroom")) {
      courses.push({
        id: `course-dyn-g2`,
        name: "Grade 2 Elementary Homeroom",
        section: "Grade 2",
        descriptionHeading: "Primary Grade 2 Curriculums",
        description: "Extending mathematical addition, advanced phonics, and reading blocks.",
        color: "rose"
      });
    }

    if (n.includes("grade 3") || n.includes("grade 1, 2 and 3") || n.includes("grade 3 and 4") || n.includes("grade 3 homeroom")) {
      courses.push({
        id: `course-dyn-g3`,
        name: "Grade 3 Elementary Homeroom",
        section: "Grade 3",
        descriptionHeading: "Primary Grade 3 Curriculums",
        description: "Intermediate storytelling, multiplication tables, environmental science.",
        color: "violet"
      });
    }

    if (n.includes("grade 4") || n.includes("grade 3 and 4") || n.includes("grade 4, 5") || n.includes("grade 4 homeroom")) {
      courses.push({
        id: `course-dyn-g4`,
        name: "Grade 4 Elementary Homeroom",
        section: "Grade 4",
        descriptionHeading: "Primary Grade 4 Curriculums",
        description: "Advanced vocabulary, geography, division, early history studies.",
        color: "emerald"
      });
    }

    if (n.includes("grade 5") || n.includes("grade 4, 5 and 6") || n.includes("grade 5 homeroom")) {
      courses.push({
        id: `course-dyn-g5`,
        name: "Grade 5 Middle School Homeroom",
        section: "Grade 5",
        descriptionHeading: "Grade 5 Transition Program",
        description: "Preparing students with key analytical essays, and science investigations.",
        color: "slate"
      });
    }

    if (n.includes("grade 6") || n.includes("grade 5 and 6") || n.includes("grade 6 homeroom")) {
      courses.push({
        id: `course-dyn-g6`,
        name: "Grade 6 Middle School Homeroom",
        section: "Grade 6",
        descriptionHeading: "Grade 6 Transition Program",
        description: "Independent labs, historical inquiry, primary resources, algebra prep.",
        color: "indigo"
      });
    }

    if (n.includes("grade 7") || n.includes("grade 7 homeroom")) {
      courses.push({
        id: `course-dyn-g7`,
        name: "Grade 7 Middle School Homeroom",
        section: "Grade 7",
        descriptionHeading: "Grade 7 Core High School Prep",
        description: "Advanced math modeling, world geography projects, structural grammar.",
        color: "amber"
      });
    }

    // Fallbacks if nothing matched but we are staff
    if (courses.length === 0) {
      if (n.includes("librarian")) {
        courses.push({
          id: `course-dyn-lib`,
          name: "Library Literacy & Research Skills",
          section: "All Grades",
          descriptionHeading: "Information Literacy & Media Resources",
          description: "Learning database citation, catalog search, print archives, and research methodologies.",
          color: "teal"
        });
      } else {
        courses.push({
          id: `course-dyn-genstaff`,
          name: "Interdisciplinary Study & Advisory",
          section: "Staff Admin Block",
          descriptionHeading: "Guided Core Advisory & Support",
          description: "Academic counsel, study hall supervision, and collaborative work blocks.",
          color: "slate"
        });
      }
    }
  }

  return courses;
}
