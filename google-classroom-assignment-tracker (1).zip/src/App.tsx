import React, { useEffect, useState, useCallback } from "react";
import Sidebar from "./components/Sidebar";
import AssignmentList from "./components/AssignmentList";
import ClassroomExplorer from "./components/ClassroomExplorer";
import AnalyticsView from "./components/AnalyticsView";
import NotificationsPanel from "./components/NotificationsPanel";
import SettingsView from "./components/SettingsView";
import LoginPortal from "./components/LoginPortal";
import CountdownTimer from "./components/CountdownTimer";
import UpcomingTests from "./components/UpcomingTests";
import { Course, UnifiedAssignment, SyncConfig, NotificationItem, Contact, SharedHomework } from "./types";
import {
  getSimulatedCourses,
  getInitialSimulatedAssignments,
  getSimulatedContacts,
  triggerSimulatedUpdate,
  getTeacherSpecificCourses
} from "./classroomApi";
import { Bell, AlertCircle, X, Sparkles, RefreshCw, LogOut, Sun, Moon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ContactsView from "./components/ContactsView";
import HomeworkSheetView from "./components/HomeworkSheetView";
import SnackScheduleView from "./components/SnackScheduleView";
import AlumniGlobeView from "./components/AlumniGlobeView";
import { studentsList } from "./studentsData";
import { teachersList } from "./teachersData";

export default function App() {
  const isLiveMode = false; // Constrain completely offline-first

  // Dark mode state loaded from localStorage or system theme defaults
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const savedTheme = localStorage.getItem("theme_mode");
    if (savedTheme) {
      return savedTheme === "dark";
    }
    return false;
  });

  // Sync dark mode class on document element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme_mode", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme_mode", "light");
    }
  }, [darkMode]);

  // Navigation Tab State
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  
  // Current logged in Student User State
  const [currentUser, setCurrentUser] = useState<any>(() => {
    const savedSimulatedUser = localStorage.getItem("simulated_student_user");
    return savedSimulatedUser ? JSON.parse(savedSimulatedUser) : null;
  });

  const [errorAlert, setErrorAlert] = useState<string | null>(null);

  // User details state
  const [userName, setUserName] = useState<string>(() => {
    const savedSimulatedUser = localStorage.getItem("simulated_student_user");
    return savedSimulatedUser ? JSON.parse(savedSimulatedUser).displayName : "Not Signed In";
  });
  const [userEmail, setUserEmail] = useState<string>(() => {
    const savedSimulatedUser = localStorage.getItem("simulated_student_user");
    return savedSimulatedUser ? JSON.parse(savedSimulatedUser).email : "not_signed_in@classroom.edu";
  });
  const [userPhoto, setUserPhoto] = useState<string | undefined>(undefined);

  // Core Classroom Data
  const [courses, setCourses] = useState<Course[]>([]);
  const [assignments, setAssignments] = useState<UnifiedAssignment[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [sharedHomework, setSharedHomework] = useState<SharedHomework[]>([]);
  
  // Settings & Sync Prefs
  const [syncConfig, setSyncConfig] = useState<SyncConfig>({
    autoSync: true,
    intervalSec: 30,
  });
  const [lastSynced, setLastSynced] = useState<Date | null>(new Date());
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Notifications Feeds
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [toasts, setToasts] = useState<NotificationItem[]>([]);

  // Upcoming Tests Tab Visit Popup State
  const [showUpcomingTestsPopup, setShowUpcomingTestsPopup] = useState(false);
  const [hasShownPopupForUser, setHasShownPopupForUser] = useState<string | null>(null);

  // Load & filter all notifications (combines local sync and global homework alerts)
  const loadMergedNotifications = useCallback((emailVal?: string, userObj?: any) => {
    const activeUser = userObj || currentUser;
    const activeEmail = emailVal || activeUser?.email;
    if (!activeUser || !activeEmail) return;

    // 1. Get personal local notifications (welcome, sync alerts etc.)
    const cachedNotifications = localStorage.getItem(`student_notifications_${activeEmail}`);
    let localList: NotificationItem[] = [];
    if (cachedNotifications) {
      try {
        localList = JSON.parse(cachedNotifications).map((n: any) => ({
          ...n,
          timestamp: new Date(n.timestamp)
        }));
      } catch (e) {
        console.error("Error parsing local notifications", e);
      }
    } else {
      localList = [
        {
          id: `wel-${Date.now()}`,
          type: "sync",
          message: `Welcome to your academic Learning Board, ${activeUser.displayName}!`,
          timestamp: new Date(),
          read: false,
        }
      ];
      localStorage.setItem(`student_notifications_${activeEmail}`, JSON.stringify(localList));
    }

    // 2. Get global homework notifications
    const cachedGlobalList = localStorage.getItem("student_homework_notifications_global");
    let globalList: any[] = [];
    if (cachedGlobalList) {
      try {
        globalList = JSON.parse(cachedGlobalList);
      } catch (e) {
        console.error("Error parsing global notifications", e);
      }
    } else {
      // Pre-seed from initial shared homework (Hamlet, Optimization, etc.)
      const initialHw = [
        {
          id: "shared-hw-9",
          title: "Introduction to Plot Diagrams",
          gradeLevel: "Grade 9",
          createdBy: "Walker Hedgepath",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 4 * 3600 * 1000).toISOString()
        },
        {
          id: "shared-hw-10",
          title: "Photosynthesis Cellular Respiration Matrix",
          gradeLevel: "Grade 10",
          createdBy: "Helga Joshua",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 3 * 3600 * 1000).toISOString()
        },
        {
          id: "shared-hw-11",
          title: "Hamlet Act III Soliloquy Analysis",
          gradeLevel: "Grade 11",
          createdBy: "Walker Hedgepath",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
        },
        {
          id: "shared-hw-12",
          title: "Optimization Word Problems Packet",
          gradeLevel: "Grade 12",
          createdBy: "Hang Sokcha",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 1 * 3600 * 1000).toISOString()
        }
      ];

      globalList = initialHw.map(hw => ({
        id: `hw-notification-${hw.id}-default`,
        type: "new" as const,
        message: `[Homework Update] Teacher / Staff ${hw.createdBy} posted homework: "${hw.title}" for ${hw.gradeLevel}.`,
        timestamp: hw.timestamp,
        gradeLevel: hw.gradeLevel,
        createdByRole: hw.createdByRole,
        assignmentId: hw.id,
        assignmentTitle: hw.title
      }));
      localStorage.setItem("student_homework_notifications_global", JSON.stringify(globalList));
    }

    // 2.5. Get global upcoming test notifications
    const cachedTestGlobalList = localStorage.getItem("student_test_notifications_global");
    let testGlobalList: any[] = [];
    if (cachedTestGlobalList) {
      try {
        testGlobalList = JSON.parse(cachedTestGlobalList);
      } catch (e) {
        console.error("Error parsing global test notifications", e);
      }
    } else {
      // Pre-seed from initial default tests
      const initialTests = [
        {
          id: "test-apcsa-1",
          title: "Unit 5: Polymorphism & Inheritance Exam",
          course: "AP CSA",
          gradeLevel: "Grade 11",
          creator: "Chheng Yorng Chhieng",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 3.5 * 3600 * 1000).toISOString()
        },
        {
          id: "test-apcalc-1",
          title: "Unit 4: Optimization & Related Rates Test",
          course: "AP Calculus AB",
          gradeLevel: "Grade 12",
          creator: "Hang Sokcha",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 2.5 * 3600 * 1000).toISOString()
        },
        {
          id: "test-lit-1",
          title: "Oedipus Rex Plot Construction Assessment",
          course: "World Literature & Composition",
          gradeLevel: "Grade 9",
          creator: "Walker Hedgepath",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 1.5 * 24 * 3600 * 1000).toISOString()
        },
        {
          id: "test-bio-1",
          title: "Photosynthesis & Cellular Processes Quiz",
          course: "AP Biology",
          gradeLevel: "Grade 10",
          creator: "Helga Joshua",
          createdByRole: "teacher",
          timestamp: new Date(Date.now() - 50 * 60 * 1000).toISOString()
        }
      ];

      testGlobalList = initialTests.map(test => ({
        id: `test-notification-${test.id}-default`,
        type: "new" as const,
        message: `[Upcoming Test] Teacher / Staff ${test.creator} posted a test: "${test.title}" (${test.course}) for ${test.gradeLevel}.`,
        timestamp: test.timestamp,
        gradeLevel: test.gradeLevel,
        createdByRole: test.createdByRole,
        testId: test.id,
        testTitle: test.title
      }));
      localStorage.setItem("student_test_notifications_global", JSON.stringify(testGlobalList));
    }

    // 3. Filter global notifications by user's ACCESS LEVEL / grade level
    const isTeacher = activeUser.role === "teacher" || activeUser.grade === "All Grades";
    const userGrade = activeUser.grade || "";

    const matchingGlobal = globalList.filter((notif: any) => {
      if (isTeacher) return true; // Teachers/Staff see ALL homework notifications
      // Students see only notifications matching their grade level or "All Grades"
      return notif.gradeLevel === "All Grades" || notif.gradeLevel === userGrade;
    });

    const matchingTestGlobal = testGlobalList.filter((notif: any) => {
      if (isTeacher) return true; // Teachers/Staff see ALL test notifications
      return notif.gradeLevel === "All Grades" || notif.gradeLevel === userGrade;
    });

    // 4. Load personal read/unread state and cleared/dismissed state for global notifications
    const cachedReadGlobal = localStorage.getItem(`student_global_read_notifications_${activeEmail}`);
    const readGlobalIds: string[] = cachedReadGlobal ? JSON.parse(cachedReadGlobal) : [];

    const cachedClearedGlobal = localStorage.getItem(`student_global_cleared_notifications_${activeEmail}`);
    const clearedGlobalIds: string[] = cachedClearedGlobal ? JSON.parse(cachedClearedGlobal) : [];

    // Filter out cleared global notifications
    const activeGlobal = matchingGlobal.filter((notif: any) => !clearedGlobalIds.includes(notif.id));
    const activeTestGlobal = matchingTestGlobal.filter((notif: any) => !clearedGlobalIds.includes(notif.id));

    // Convert global homework notification items into NotificationItem schema
    const formattedGlobalList: NotificationItem[] = activeGlobal.map((notif: any) => ({
      id: notif.id,
      type: notif.type,
      message: notif.message,
      timestamp: new Date(notif.timestamp),
      read: readGlobalIds.includes(notif.id),
      assignmentId: notif.assignmentId,
      assignmentTitle: notif.assignmentTitle,
      gradeLevel: notif.gradeLevel,
      createdByRole: notif.createdByRole
    }));

    // Convert global test notification items into NotificationItem schema
    const formattedTestGlobalList: NotificationItem[] = activeTestGlobal.map((notif: any) => ({
      id: notif.id,
      type: notif.type,
      message: notif.message,
      timestamp: new Date(notif.timestamp),
      read: readGlobalIds.includes(notif.id),
      assignmentId: notif.testId, // map to assignmentId/assignmentTitle fields so view renders it perfectly or as a test entry
      assignmentTitle: notif.testTitle,
      gradeLevel: notif.gradeLevel,
      createdByRole: notif.createdByRole
    }));

    // 5. Merge, sort by timestamp descending, and update state
    const combined = [...localList, ...formattedGlobalList, ...formattedTestGlobalList].sort(
      (a, b) => b.timestamp.getTime() - a.timestamp.getTime()
    );

    setNotifications(combined);
  }, [currentUser]);

  // Push new notification helper
  const addNotification = useCallback((type: NotificationItem["type"], message: string, detail?: { assignmentId?: string, assignmentTitle?: string }) => {
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type,
      message,
      timestamp: new Date(),
      read: false,
      ...detail
    };

    if (currentUser) {
      const cached = localStorage.getItem(`student_notifications_${currentUser.email}`);
      let localList: any[] = [];
      if (cached) {
        try {
          localList = JSON.parse(cached);
        } catch (e) {
          console.error("error parsing list", e);
        }
      }
      const updated = [newNotif, ...localList];
      localStorage.setItem(`student_notifications_${currentUser.email}`, JSON.stringify(updated));
    }

    setToasts((prev) => [...prev, newNotif]);

    // Slide out toasts after 4.5 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newNotif.id));
    }, 4500);

    loadMergedNotifications();
  }, [currentUser, loadMergedNotifications]);

  // Helper for adding global homework notifications that filters on access level
  const addGlobalHomeworkNotification = useCallback((item: SharedHomework, creatorRole: string, isUpdate: boolean = false) => {
    const globalNotifsKey = "student_homework_notifications_global";
    const phrase = isUpdate ? "updated" : "posted";
    
    // Create the message indicating the author and access/grade level
    const roleLabel = creatorRole === "teacher" ? "Teacher / Staff" : "Student";
    const gradeSuffix = item.gradeLevel === "All Grades" ? "all classes" : item.gradeLevel;
    const message = `[Homework Update] ${roleLabel} ${item.createdBy} ${phrase} homework: "${item.title}" for ${gradeSuffix}.`;

    const newNotif = {
      id: `hw-notification-${item.id}-${Date.now()}`,
      type: "new" as const,
      message,
      timestamp: new Date().toISOString(),
      gradeLevel: item.gradeLevel,
      createdByRole: creatorRole,
      assignmentId: item.id,
      assignmentTitle: item.title,
    };

    const cachedGlobal = localStorage.getItem(globalNotifsKey);
    let globalList = cachedGlobal ? JSON.parse(cachedGlobal) : [];
    // Prepend the new notification
    globalList = [newNotif, ...globalList];
    localStorage.setItem(globalNotifsKey, JSON.stringify(globalList));

    // Also trigger local toast for active session
    setToasts((prev) => [...prev, { ...newNotif, timestamp: new Date(newNotif.timestamp), read: false }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newNotif.id));
    }, 4500);

    // Refresh notifications feed instantly
    loadMergedNotifications();
  }, [currentUser, loadMergedNotifications]);

  // Helper for adding global test notifications that filters on access level
  const addGlobalTestNotification = useCallback((item: any, creatorRole: string) => {
    const globalNotifsKey = "student_test_notifications_global";
    
    // Create the message indicating the author and access/grade level
    const roleLabel = creatorRole === "teacher" ? "Teacher / Staff" : "Student";
    const gradeSuffix = item.grade === "All Grades" ? "all classes" : item.grade;
    const message = `[Upcoming Test] ${roleLabel} ${item.creator} posted a test: "${item.title}" (${item.course}) for ${gradeSuffix}.`;

    const newNotif = {
      id: `test-notification-${item.id}-${Date.now()}`,
      type: "new" as const,
      message,
      timestamp: new Date().toISOString(),
      gradeLevel: item.grade,
      createdByRole: creatorRole,
      testId: item.id,
      testTitle: item.title,
    };

    const cachedGlobal = localStorage.getItem(globalNotifsKey);
    let globalList = cachedGlobal ? JSON.parse(cachedGlobal) : [];
    globalList = [newNotif, ...globalList];
    localStorage.setItem(globalNotifsKey, JSON.stringify(globalList));

    // Also trigger local toast for active session
    setToasts((prev) => [...prev, { ...newNotif, timestamp: new Date(newNotif.timestamp), read: false }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newNotif.id));
    }, 4500);

    // Refresh notifications feed instantly
    loadMergedNotifications();
  }, [currentUser, loadMergedNotifications]);

  // Load User Data upon authentication changes
  useEffect(() => {
    if (!currentUser) {
      setCourses([]);
      setAssignments([]);
      setContacts([]);
      setNotifications([]);
      return;
    }

    const emailVal = currentUser.email;

    // 1. Load Courses
    const cachedCourses = localStorage.getItem(`student_courses_${emailVal}`);
    let loadedCourses: Course[] = [];
    if (cachedCourses) {
      loadedCourses = JSON.parse(cachedCourses).filter((c: any) => {
        if (!c.id || !c.name) return false;
        if (["course-1", "course-2", "course-3", "course-4"].includes(c.id)) return false;
        if (c.id.startsWith("dm-") || c.id.startsWith("sr-") || c.id.startsWith("mc-")) return false;
        
        const nameLower = c.name.toLowerCase();
        const isClubOrGym = 
          nameLower === "running" || 
          nameLower === "sdc" || 
          nameLower === "robotics" || 
          nameLower === "sports" || 
          nameLower === "engineering" ||
          nameLower.includes("club") ||
          nameLower.includes("gym") ||
          nameLower.includes("sports") ||
          nameLower.includes("robotics") ||
          nameLower.includes("engineering");
          
        return !isClubOrGym;
      });
      // Clean up the cache with only user-created courses
      localStorage.setItem(`student_courses_${emailVal}`, JSON.stringify(loadedCourses));
    }
    
    // Fallback: seed courses if no courses exist in cache
    if (loadedCourses.length === 0) {
      if (currentUser?.role === "teacher") {
        loadedCourses = getTeacherSpecificCourses(currentUser.displayName, currentUser.title || "Teacher");
      } else {
        const studentRec = studentsList.find(s => 
          s.name.toLowerCase().replace(/[^a-z0-9]/g, "") === currentUser.displayName.toLowerCase().replace(/[^a-z0-9]/g, "")
        );
        if (studentRec) {
          const subjects = [
            { name: studentRec.schedule.english, color: "indigo" },
            { name: studentRec.schedule.math, color: "violet" },
            { name: studentRec.schedule.science, color: "emerald" },
            { name: studentRec.schedule.socialStudies, color: "rose" }
          ].filter(sub => sub.name && sub.name !== "None");

          loadedCourses = subjects.map((sub, idx) => ({
            id: `course-${studentRec.lastName.toLowerCase()}-${idx}`,
            name: sub.name,
            section: studentRec.grade,
            descriptionHeading: `${sub.name} - ${studentRec.grade} Curriculum`,
            description: `Syllabus class block for registered schedule.`,
            color: sub.color
          }));
        } else {
          loadedCourses = getSimulatedCourses(emailVal);
        }
      }
      localStorage.setItem(`student_courses_${emailVal}`, JSON.stringify(loadedCourses));
    }
    setCourses(loadedCourses);

    // 2. Load Assignments
    const cachedAssignments = localStorage.getItem(`student_assignments_${emailVal}`);
    let loadedAssignments: UnifiedAssignment[] = [];
    if (cachedAssignments) {
      loadedAssignments = JSON.parse(cachedAssignments)
        .map((a: any) => ({
          ...a,
          dueDate: a.dueDate ? new Date(a.dueDate) : null
        }))
        .filter((a: any) => 
          a.id && 
          !["work-101", "work-102", "work-201", "work-301", "work-401"].includes(a.id) && 
          !a.id.startsWith("dm-") && 
          !a.id.startsWith("sr-") && 
          !a.id.startsWith("mc-")
        );
      // Clean up the cache with only user-created assignments
      localStorage.setItem(`student_assignments_${emailVal}`, JSON.stringify(loadedAssignments));
    }

    // No longer seeding any dummy assignments. Only spreadsheet/user assignments should exist.
    if (loadedAssignments.length === 0) {
      loadedAssignments = [];
      localStorage.setItem(`student_assignments_${emailVal}`, JSON.stringify(loadedAssignments));
    }
    setAssignments(loadedAssignments);

    // 3. Load Contacts dynamically (do not cache to ensure updates to the teachers/peers list apply)
    const loadedContacts = getSimulatedContacts();
    setContacts(loadedContacts);

    // 4. Load Notifications via our access-filtered merge engine
    loadMergedNotifications(emailVal, currentUser);

    // 5. Load Sync Config
    const cachedSyncConfig = localStorage.getItem(`student_sync_config_${emailVal}`);
    if (cachedSyncConfig) {
      setSyncConfig(JSON.parse(cachedSyncConfig));
    } else {
      const defaultConfig = { autoSync: true, intervalSec: 30 };
      setSyncConfig(defaultConfig);
      localStorage.setItem(`student_sync_config_${emailVal}`, JSON.stringify(defaultConfig));
    }

    // 6. Load Global Shared Homework
    const cachedSharedHw = localStorage.getItem(`student_shared_homework_global`);
    if (cachedSharedHw) {
      setSharedHomework(JSON.parse(cachedSharedHw));
    } else {
      const defaultSharedHw = [
        {
          id: "shared-hw-9",
          courseId: "shared-9",
          courseName: "English 1",
          courseColor: "indigo",
          title: "Introduction to Plot Diagrams",
          description: "Construct a detail-rich plot diagram mapping the exposition, rising action, and climax of Oedipus Rex.",
          dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
          maxPoints: 100,
          createdBy: "Walker Hedgepath",
          createdById: "teacher-walker-hedgepath",
          gradeLevel: "Grade 9",
          updatedAt: new Date().toISOString()
        },
        {
          id: "shared-hw-10",
          courseId: "shared-10",
          courseName: "AP Biology",
          courseColor: "emerald",
          title: "Photosynthesis Cellular Respiration Matrix",
          description: "Submit a complete diagram explaining reactions, input reagents, and yield metrics for Light / Calvin processes.",
          dueDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
          maxPoints: 80,
          createdBy: "Helga Joshua",
          createdById: "teacher-helga-joshua",
          gradeLevel: "Grade 10",
          updatedAt: new Date().toISOString()
        },
        {
          id: "shared-hw-11",
          courseId: "shared-11",
          courseName: "World Literature & Composition",
          courseColor: "indigo",
          title: "Hamlet Act III Soliloquy Analysis",
          description: "Analyze how Shakespeare employs rhetorical questions and existential elements to convey central themes.",
          dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
          maxPoints: 100,
          createdBy: "Walker Hedgepath",
          createdById: "teacher-walker-hedgepath",
          gradeLevel: "Grade 11",
          updatedAt: new Date().toISOString()
        },
        {
          id: "shared-hw-12",
          courseId: "shared-12",
          courseName: "AP Calculus AB",
          courseColor: "violet",
          title: "Optimization Word Problems Packet",
          description: "Resolve sections 4.1 to 4.5 of the textbook. Document derivative test calculations clearly.",
          dueDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString(),
          maxPoints: 100,
          createdBy: "Hang Sokcha",
          createdById: "teacher-hang-sokcha",
          gradeLevel: "Grade 12",
          updatedAt: new Date().toISOString()
        }
      ];
      setSharedHomework(defaultSharedHw);
      localStorage.setItem(`student_shared_homework_global`, JSON.stringify(defaultSharedHw));
    }

  }, [currentUser]);

  // Mark single notification as read
  const handleMarkNotificationAsRead = useCallback(async (id: string) => {
    if (!currentUser) return;
    const emailVal = currentUser.email;

    if (id.startsWith("hw-notification-") || id.startsWith("test-notification-")) {
      // It's a global notification! Add it to the read global list
      const cachedReadGlobal = localStorage.getItem(`student_global_read_notifications_${emailVal}`);
      const readGlobalIds: string[] = cachedReadGlobal ? JSON.parse(cachedReadGlobal) : [];
      if (!readGlobalIds.includes(id)) {
        const updated = [...readGlobalIds, id];
        localStorage.setItem(`student_global_read_notifications_${emailVal}`, JSON.stringify(updated));
      }
    } else {
      // It's a user-local notification! Mark it read in local list
      const cachedNotifications = localStorage.getItem(`student_notifications_${emailVal}`);
      if (cachedNotifications) {
        const localList = JSON.parse(cachedNotifications);
        const updated = localList.map((n: any) => (n.id === id ? { ...n, read: true } : n));
        localStorage.setItem(`student_notifications_${emailVal}`, JSON.stringify(updated));
      }
    }
    loadMergedNotifications();
  }, [currentUser, loadMergedNotifications]);

  // Mark all notifications as read
  const handleMarkAllNotificationsAsRead = useCallback(async () => {
    if (!currentUser) return;
    const emailVal = currentUser.email;

    // 1. Mark all currently loaded global notifications as read
    const cachedReadGlobal = localStorage.getItem(`student_global_read_notifications_${emailVal}`);
    const readGlobalIds: string[] = cachedReadGlobal ? JSON.parse(cachedReadGlobal) : [];
    
    // Gather all currently visible global notification IDs
    const visibleGlobalNotifIds = notifications
      .filter((n) => n.id.startsWith("hw-notification-") || n.id.startsWith("test-notification-"))
      .map((n) => n.id);

    const mergedReadIds = Array.from(new Set([...readGlobalIds, ...visibleGlobalNotifIds]));
    localStorage.setItem(`student_global_read_notifications_${emailVal}`, JSON.stringify(mergedReadIds));

    // 2. Mark all user-local notifications as read
    const cachedNotifications = localStorage.getItem(`student_notifications_${emailVal}`);
    if (cachedNotifications) {
      const localList = JSON.parse(cachedNotifications);
      const updated = localList.map((n: any) => ({ ...n, read: true }));
      localStorage.setItem(`student_notifications_${emailVal}`, JSON.stringify(updated));
    }

    loadMergedNotifications();
  }, [currentUser, notifications, loadMergedNotifications]);

  // Clear all notifications
  const handleClearAllNotifications = useCallback(() => {
    if (!currentUser) return;
    const emailVal = currentUser.email;

    // 1. Clear all local notifications
    localStorage.setItem(`student_notifications_${emailVal}`, JSON.stringify([]));

    // 2. Clear/dismiss all currently loaded global notifications by marking them as cleared for this user
    const cachedClearedGlobal = localStorage.getItem(`student_global_cleared_notifications_${emailVal}`);
    const clearedGlobalIds: string[] = cachedClearedGlobal ? JSON.parse(cachedClearedGlobal) : [];

    const visibleGlobalNotifIds = notifications
      .filter((n) => n.id.startsWith("hw-notification-") || n.id.startsWith("test-notification-"))
      .map((n) => n.id);

    const mergedClearedIds = Array.from(new Set([...clearedGlobalIds, ...visibleGlobalNotifIds]));
    localStorage.setItem(`student_global_cleared_notifications_${emailVal}`, JSON.stringify(mergedClearedIds));

    loadMergedNotifications();
  }, [currentUser, notifications, loadMergedNotifications]);

  // Monitor navigation tab and user login state to show the upcoming test popup only once per session
  useEffect(() => {
    if (currentUser) {
      // Precise ID lookup for known non-teaching, administrative and support staff
      const STAFF_IDS = new Set([
        "teacher-ryan-ahlers",
        "teacher-naomi-lane",
        "teacher-steve-mccambridge",
        "teacher-sophanarith-song",
        "teacher-chenda-soth",
        "teacher-eak-sangha",
        "teacher-kong-sokthearoath",
        "teacher-chhay-leang-eng",
        "teacher-chea-bunthai",
        "teacher-chouch-sreyvong",
        "teacher-kay-pheaktra",
        "teacher-sou-sreynuth",
        "teacher-chek-chantrea",
        "teacher-hong-malen",
        "teacher-vuth-sinady",
        "teacher-bun-usa",
        "teacher-chhit-boramey"
      ]);

      const isStaff = (currentUser.role === "teacher" && STAFF_IDS.has(currentUser.uid)) || currentUser.role === "admin";

      if (activeTab === "dashboard" && !isStaff && hasShownPopupForUser !== currentUser.uid) {
        setShowUpcomingTestsPopup(true);
        setHasShownPopupForUser(currentUser.uid);
      }
    } else {
      // Clear popup triggers upon logout
      setHasShownPopupForUser(null);
      setShowUpcomingTestsPopup(false);
    }
  }, [activeTab, currentUser, hasShownPopupForUser]);

  // Select filtered upcoming tests for display inside the popup
  const modalTests = React.useMemo(() => {
    if (!currentUser) return [];
    
    const saved = localStorage.getItem("upcoming_tests");
    let testsList = [];
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        testsList = parsed.map((t: any) => {
          if (t.creator === "But Sreyoun") {
            return { ...t, creator: "Chheng Yorng Chhieng" };
          }
          return t;
        });
      } catch (err) {
        testsList = [];
      }
    } else {
      testsList = [
        {
          id: "test-apcsa-1",
          title: "Unit 5: Polymorphism & Inheritance Exam",
          course: "AP CSA",
          grade: "Grade 11",
          date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Chheng Yorng Chhieng"
        },
        {
          id: "test-apcalc-1",
          title: "Unit 4: Optimization & Related Rates Test",
          course: "AP Calculus AB",
          grade: "Grade 12",
          date: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Hang Sokcha"
        },
        {
          id: "test-lit-1",
          title: "Oedipus Rex Plot Construction Assessment",
          course: "World Literature & Composition",
          grade: "Grade 9",
          date: new Date(Date.now() + 1.5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Walker Hedgepath"
        },
        {
          id: "test-bio-1",
          title: "Photosynthesis & Cellular Processes Quiz",
          course: "AP Biology",
          grade: "Grade 10",
          date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Helga Joshua"
        }
      ];
    }
    
    const isTeacher = currentUser.role === "teacher" || currentUser.role === "admin";
    const userGrade = currentUser.grade;
    
    return testsList.filter((test: any) => {
      if (isTeacher) return true;
      if (userGrade) return test.grade === userGrade;
      return false;
    }).sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [currentUser, showUpcomingTestsPopup]);

  // Sync state dispatcher (Proactive simulation fetcher engine)
  const performSync = useCallback(async () => {
    if (!currentUser) return;

    setIsSyncing(true);
    addNotification("sync", "Interrogating local academic rosters and sync protocols...");
    
    // Smooth delay for simulated fetch
    await new Promise((resolve) => setTimeout(resolve, 800));

    try {
      const updatedAssignments = triggerSimulatedUpdate((notif) => {
        addNotification(notif.type, notif.message, {
          assignmentId: notif.assignmentId,
          assignmentTitle: notif.assignmentTitle
        });
      });

      setAssignments((currentAssignments) => {
        const merged = currentAssignments.map((existing) => {
          const updatedMatch = updatedAssignments.find((u) => u.id === existing.id);
          if (updatedMatch) {
            // Keep student's submitted local changes
            if (existing.state === "submitted" && updatedMatch.state !== "graded") {
              return existing;
            }
            return {
              ...existing,
              state: updatedMatch.state,
              grade: updatedMatch.grade ? Number(updatedMatch.grade) : existing.grade,
              updateTime: updatedMatch.updateTime
            };
          }
          return existing;
        });

        // Pull in brand new assignments
        updatedAssignments.forEach((item) => {
          if (!merged.some((m) => m.id === item.id)) {
            merged.unshift({
              ...item,
              dueDate: item.dueDate ? new Date(item.dueDate) : null
            });
          }
        });

        if (currentUser) {
          localStorage.setItem(`student_assignments_${currentUser.email}`, JSON.stringify(merged));
        }
        return merged;
      });

      setLastSynced(new Date());
      addNotification("sync", "Classrooms up-to-date. Roster synchronization complete.");
    } catch (err) {
      console.warn("Simulated sync error", err);
    } finally {
      setIsSyncing(false);
    }
  }, [addNotification, currentUser]);

  // Handle Mark as Done (or status change)
  const handleTurnInAssignment = async (id: string) => {
    // Look up if this item corresponds to a global shared homework
    const isSharedHw = sharedHomework.find((h) => h.id === id);
    
    setAssignments((prev) => {
      const exists = prev.some((ass) => ass.id === id);
      let updated;
      if (exists) {
        updated = prev.map((ass) => {
          if (ass.id === id) {
            return {
              ...ass,
              state: "submitted" as const,
              updateTime: new Date().toISOString()
            };
          }
          return ass;
        });
      } else if (isSharedHw) {
        const newAss: UnifiedAssignment = {
          id: id,
          courseId: isSharedHw.courseId,
          courseName: isSharedHw.courseName,
          courseColor: isSharedHw.courseColor,
          title: isSharedHw.title,
          description: isSharedHw.description,
          maxPoints: isSharedHw.maxPoints,
          dueDate: isSharedHw.dueDate ? new Date(isSharedHw.dueDate) : null,
          state: "submitted",
          updateTime: new Date().toISOString()
        };
        updated = [...prev, newAss];
      } else {
        updated = prev;
      }
      if (currentUser) {
        localStorage.setItem(`student_assignments_${currentUser.email}`, JSON.stringify(updated));
      }
      return updated;
    });

    if (isSharedHw) {
      addNotification("sync", `Marked done shared homework: "${isSharedHw.title}"!`);
    } else {
      const matchedAss = assignments.find(a => a.id === id);
      addNotification("sync", `Marked task complete: "${matchedAss?.title || id}"`);
    }
  };

  const handleCustomStudentLogin = async (name: string, gradeLevel: string, passwordText: string) => {
    setErrorAlert(null);
    setIsSyncing(true);
    addNotification("sync", `Roster matching: Authenticating and initializing ${name} (${gradeLevel})...`);

    // Smooth transition
    await new Promise((resolve) => setTimeout(resolve, 600));

    const email = `${name.toLowerCase().replace(/[^a-z0-9]/g, "")}@school-classroom.org`;
    const simulatedUser = {
      uid: `simulated-${name.toLowerCase().replace(/[^a-z0-9]/g, "")}`,
      displayName: name,
      email: email,
      grade: gradeLevel,
      photoURL: undefined,
      isSimulated: true,
    };

    localStorage.setItem("simulated_student_user", JSON.stringify(simulatedUser));
    setCurrentUser(simulatedUser);
    setUserName(name);
    setUserEmail(email);

    addNotification("sync", `Welcome, ${name}! Logged in to ${gradeLevel} Classroom Portal.`);
    setIsSyncing(false);
  };

  const handleTeacherLogin = async (teacherId: string, name: string, title: string, email: string) => {
    setErrorAlert(null);
    setIsSyncing(true);
    addNotification("sync", `Roster matching: Authenticating and initializing faculty member ${name}...`);

    // Smooth transition
    await new Promise((resolve) => setTimeout(resolve, 600));

    const simulatedUser = {
      uid: teacherId,
      displayName: name,
      email: email,
      grade: "All Grades",
      title: title,
      role: "teacher",
      isSimulated: true,
    };

    localStorage.setItem("simulated_student_user", JSON.stringify(simulatedUser));
    setCurrentUser(simulatedUser);
    setUserName(name);
    setUserEmail(email);
    setActiveTab("dashboard");

    addNotification("sync", `Welcome back, ${name}! Logged in as ${title}.`);
    setIsSyncing(false);
  };

  const handleLogoutLive = () => {
    localStorage.removeItem("simulated_student_user");
    setCurrentUser(null);
    setCourses([]);
    setAssignments([]);
    setUserName("Not Signed In");
    setUserEmail("not_signed_in@classroom.edu");
    setUserPhoto(undefined);
    addNotification("sync", "Disconnected portfolio account.");
  };

  const handleDeleteCourse = async (courseId: string) => {
    const updatedCourses = courses.filter((c) => c.id !== courseId);
    setCourses(updatedCourses);
    if (currentUser) {
      localStorage.setItem(`student_courses_${currentUser.email}`, JSON.stringify(updatedCourses));
    }

    const updatedAssignments = assignments.filter((a) => a.courseId !== courseId);
    setAssignments(updatedAssignments);
    if (currentUser) {
      localStorage.setItem(`student_assignments_${currentUser.email}`, JSON.stringify(updatedAssignments));
    }

    addNotification("sync", "Removed classroom and associated course assignments.");
  };

  const handleAddCourse = async (newCourse: Course) => {
    const updatedCourses = [...courses, newCourse];
    setCourses(updatedCourses);
    if (currentUser) {
      localStorage.setItem(`student_courses_${currentUser.email}`, JSON.stringify(updatedCourses));
    }
    addNotification("sync", `Added custom classroom: "${newCourse.name}"`);
  };

  const handleAddAssignment = async (newAssignment: UnifiedAssignment) => {
    const updatedAssignments = [newAssignment, ...assignments];
    setAssignments(updatedAssignments);
    if (currentUser) {
      localStorage.setItem(`student_assignments_${currentUser.email}`, JSON.stringify(updatedAssignments));
    }
    addNotification("sync", `Created draft assignment: "${newAssignment.title}"`);
  };

  const handleSaveSharedHomework = async (item: SharedHomework) => {
    const index = sharedHomework.findIndex((h) => h.id === item.id);
    let updatedHw: SharedHomework[] = [];
    const isUpdate = index !== -1;
    if (isUpdate) {
      updatedHw = [...sharedHomework];
      updatedHw[index] = item;
    } else {
      updatedHw = [...sharedHomework, item];
    }
    setSharedHomework(updatedHw);
    localStorage.setItem(`student_shared_homework_global`, JSON.stringify(updatedHw));
    
    // Add access-level global homework notification
    const creatorRole = currentUser?.role === "teacher" || currentUser?.grade === "All Grades" ? "teacher" : "student";
    addGlobalHomeworkNotification(item, creatorRole, isUpdate);
    
    addNotification("sync", `${isUpdate ? "Updated" : "Published"} shared homework: "${item.title}" on the sheet.`);
  };

  const handleDeleteSharedHomework = async (id: string) => {
    const updatedHw = sharedHomework.filter((h) => h.id !== id);
    setSharedHomework(updatedHw);
    localStorage.setItem(`student_shared_homework_global`, JSON.stringify(updatedHw));
    addNotification("sync", "Removed homework task from shared board.");
  };

  const handleUpdateSyncConfig = (newConfig: SyncConfig) => {
    setSyncConfig(newConfig);
    if (currentUser) {
      localStorage.setItem(`student_sync_config_${currentUser.email}`, JSON.stringify(newConfig));
    }
  };

  // Dynamically merge global shared homework entries with student-specific status states
  const mergedAssignments = React.useMemo(() => {
    if (!currentUser) return [];

    const userGrade = currentUser?.grade || "All Grades";

    // Filter shared homework relevant to this student's grade or All Grades
    const relevantShared = sharedHomework.filter(
      hw => hw.gradeLevel === "All Grades" || hw.gradeLevel === userGrade
    );

    const merged = relevantShared.map((hw) => {
      const existing = assignments.find(a => a.id === hw.id);
      if (existing) {
        return {
          id: hw.id,
          courseId: hw.courseId,
          courseName: hw.courseName,
          courseColor: hw.courseColor,
          title: hw.title,
          description: hw.description || "Shared Homework Sheet assignment",
          maxPoints: hw.maxPoints,
          dueDate: hw.dueDate ? new Date(hw.dueDate) : null,
          state: existing.state,
          grade: existing.grade,
          alternateLink: "#homework-sheet",
          updateTime: hw.updatedAt
        };
      } else {
        return {
          id: hw.id,
          courseId: hw.courseId,
          courseName: hw.courseName,
          courseColor: hw.courseColor,
          title: hw.title,
          description: hw.description || "Shared Homework Sheet assignment",
          maxPoints: hw.maxPoints,
          dueDate: hw.dueDate ? new Date(hw.dueDate) : null,
          state: "assigned" as const,
          alternateLink: "#homework-sheet",
          updateTime: hw.updatedAt
        };
      }
    });

    // Also include any assignments the user has that aren't in sharedHomework (e.g. sync'd tasks or custom post)
    assignments.forEach(ass => {
      if (!relevantShared.some(hw => hw.id === ass.id)) {
        merged.push({
          ...ass,
          alternateLink: ass.alternateLink || undefined // ensure it falls back if needed
        });
      }
    });

    return merged.sort((a, b) => {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate.getTime() - b.dueDate.getTime();
    });
  }, [assignments, sharedHomework, currentUser]);

  // Render specific tab panels
  const renderTabContent = () => {
    switch (activeTab) {
      case "homework-sheet": {
        const userGrade = currentUser?.role === "teacher" ? "All Grades" : (currentUser?.grade || "All Grades");
        return (
          <HomeworkSheetView
            homeworkList={sharedHomework}
            courses={courses}
            currentGrade={userGrade}
            currentUserId={currentUser?.uid}
            currentUserName={currentUser?.displayName || "Student"}
            onSaveHomework={handleSaveSharedHomework}
            onDeleteHomework={handleDeleteSharedHomework}
          />
        );
      }

      case "snacks":
        return (
          <SnackScheduleView
            courses={courses}
            isTeacher={currentUser?.role === "teacher"}
            currentUser={currentUser}
          />
        );

      case "student-roster":
        return (
          <ClassroomExplorer
            courses={courses}
            assignments={mergedAssignments}
            onDeleteCourse={handleDeleteCourse}
            onAddCourse={handleAddCourse}
            onAddAssignment={handleAddAssignment}
            initialTab="roster"
            currentUser={currentUser}
          />
        );

      case "courses":
        return (
          <ClassroomExplorer
            courses={courses}
            assignments={mergedAssignments}
            onDeleteCourse={handleDeleteCourse}
            onAddCourse={handleAddCourse}
            onAddAssignment={handleAddAssignment}
            currentUser={currentUser}
          />
        );
      
      case "contacts":
        return (
          <ContactsView
            contacts={contacts}
            isSyncing={isSyncing}
            onRefresh={performSync}
            currentUser={currentUser}
          />
        );
        
      case "globe":
        return <AlumniGlobeView darkMode={darkMode} />;
      
      case "analytics":
        return (
          <AnalyticsView
            assignments={mergedAssignments}
            courses={courses}
            isTeacher={currentUser?.role === "teacher"}
            currentUser={currentUser}
          />
        );
      
      case "notifications":
        return (
          <NotificationsPanel
            notifications={notifications}
            onClearAll={handleClearAllNotifications}
            onMarkAsRead={handleMarkNotificationAsRead}
            onMarkAllAsRead={handleMarkAllNotificationsAsRead}
          />
        );
      
      case "settings":
        return (
          <SettingsView
            syncConfig={syncConfig}
            onUpdateSyncConfig={handleUpdateSyncConfig}
            onLogoutLive={handleLogoutLive}
            currentUser={currentUser}
          />
        );
      
      case "dashboard":
      default:
        return (
          <div className="space-y-6">
            <CountdownTimer />

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
              {/* Primary Content: Assignment Updates */}
              <div id="assignment-updates-section" className="xl:col-span-8 space-y-6">
                <div className="bg-slate-50/30 rounded-3xl p-1 border border-slate-100/50">
                  <AssignmentList
                    assignments={mergedAssignments}
                    courses={courses}
                    isLiveMode={isLiveMode}
                    onTurnIn={handleTurnInAssignment}
                  />
                </div>
              </div>

              {/* Secondary Content: Academic Calendar / Testing */}
              <div id="academic-calendar-section" className="xl:col-span-4 sticky top-8">
                <UpcomingTests 
                  currentUser={currentUser} 
                  onAddTestNotification={addGlobalTestNotification}
                />
              </div>
            </div>
          </div>
        );
    }
  };

  // Lock whole website behind LoginPortal if currentUser is empty
  if (!currentUser) {
    return (
      <LoginPortal
        isSyncing={isSyncing}
        errorAlert={errorAlert}
        onClearError={() => setErrorAlert(null)}
        onCustomStudentLogin={handleCustomStudentLogin}
        onTeacherLogin={handleTeacherLogin}
      />
    );
  }

  return (
    <div id="classroom-app-container" className="flex min-h-screen bg-slate-50 text-slate-800">
      
      <div id="toast-stack-container" className="fixed top-4 right-4 z-55 max-w-sm w-full space-y-2 pointer-events-none">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              layout
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, y: -10 }}
              transition={{ duration: 0.25 }}
              className="bg-slate-900 text-white rounded-xl shadow-lg border border-slate-800 p-4 pointer-events-auto flex items-start gap-3.5"
            >
              <div className="shrink-0 mt-0.5">
                {toast.type === "new" ? (
                  <div className="w-5 h-5 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <Bell className="w-3.5 h-3.5" />
                  </div>
                ) : toast.type === "graded" ? (
                  <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                ) : toast.type === "warning" ? (
                  <div className="w-5 h-5 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-400">
                    <AlertCircle className="w-3.5 h-3.5" />
                  </div>
                ) : (
                  <div className="w-5 h-5 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  </div>
                )}
              </div>

              <div className="flex-1 text-xs">
                <p className="font-bold text-slate-105">{toast.message}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Automatic event • {new Date(toast.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>

              <button
                id={`btn-close-toast-${toast.id}`}
                onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
                className="text-slate-400 hover:text-white p-0.5 pointer-events-auto cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Main Left Side Nav bar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        notificationsCount={notifications.filter(n => !n.read).length}
        userRole={currentUser?.role}
      />

      {/* Primary Workspace Viewport Container */}
      <main id="main-content-pane" className="flex-1 p-6 md:p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto space-y-6">
          
          {/* Top Welcome Panel / Dynamic Jumbotron */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
            <div>
              <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                JPA Quick Access Portal
              </h2>
              <p className="text-xs text-indigo-600 font-bold mt-1 font-mono">
                🟢 Sync Active
              </p>
            </div>
            
            <div className="flex items-center gap-3 shrink-0">
              {userPhoto ? (
                <img
                  src={userPhoto}
                  alt="Profile"
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full border border-slate-200 object-cover shadow-sm"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-indigo-700 text-white flex items-center justify-center font-bold shadow-sm">
                  {userName.charAt(0).toUpperCase()}
                </div>
              )}
              <div className="min-w-0 pr-2">
                <h4 id="topbar-user-name" className="text-sm font-extrabold text-slate-800 truncate leading-tight">{userName}</h4>
                <p id="topbar-user-email" className="text-[11px] text-slate-500 truncate mt-0.5">{userEmail}</p>
              </div>

              {/* Dark mode Toggle Button */}
              <button
                id="topbar-darkmode-toggle"
                onClick={() => setDarkMode(!darkMode)}
                title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
                className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 dark:hover:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              >
                {darkMode ? (
                  <Sun className="w-5 h-5 text-amber-400" />
                ) : (
                  <Moon className="w-5 h-5 text-slate-600" />
                )}
              </button>

              <button
                id="topbar-logout-btn"
                onClick={handleLogoutLive}
                title="Sign Out"
                className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Active View viewport */}
          <div className="min-h-[50vh]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.2 }}
              >
                {renderTabContent()}
              </motion.div>
            </AnimatePresence>
          </div>

        </div>
      </main>

      {/* Upcoming Test Tab Visit Popup Overlay */}
      <AnimatePresence>
        {activeTab === "dashboard" && showUpcomingTestsPopup && (
          <motion.div
            id="upcoming-tests-popup-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-[100] flex items-center justify-center p-4 cursor-default"
            onClick={() => setShowUpcomingTestsPopup(false)}
          >
            <motion.div
              id="upcoming-tests-popup-card"
              initial={{ scale: 0.94, y: 8, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.94, y: 8, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 355 }}
              className="bg-white rounded-3xl shadow-xl border border-slate-100 max-w-sm w-full overflow-hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header Box */}
              <div className="bg-white border-b border-slate-100 p-5 relative shrink-0">
                <button
                  id="upcoming-tests-popup-close-x"
                  onClick={() => setShowUpcomingTestsPopup(false)}
                  className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 hover:bg-slate-50 p-1.5 rounded-xl transition duration-150 cursor-pointer"
                  title="Close"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 bg-indigo-55/80 rounded-lg flex items-center justify-center border border-indigo-100">
                    <Sparkles className="w-4 h-4 text-indigo-650 animate-pulse" />
                  </div>
                  <div>
                    <h2 className="text-sm font-extrabold text-slate-900 tracking-tight">
                      Upcoming Test Reminder
                    </h2>
                  </div>
                </div>
              </div>

              {/* Popup Content */}
              <div className="p-5 space-y-4">
                {modalTests.length > 0 ? (
                  (() => {
                    const test = modalTests[0];
                    const testDate = new Date(test.date);
                    const today = new Date();
                    testDate.setHours(0, 0, 0, 0);
                    today.setHours(0, 0, 0, 0);
                    const diffTime = testDate.getTime() - today.getTime();
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                    let badgeText = "";
                    let badgeColor = "";
                    if (diffDays === 0) {
                      badgeText = "TODAY";
                      badgeColor = "text-red-700 bg-red-50 border-red-100 font-extrabold animate-pulse";
                    } else if (diffDays === 1) {
                      badgeText = "TOMORROW";
                      badgeColor = "text-amber-805 bg-amber-50 border-amber-100 font-black";
                    } else if (diffDays < 0) {
                      badgeText = "PAST DUE";
                      badgeColor = "text-slate-500 bg-slate-100 border-slate-200 font-bold";
                    } else {
                      badgeText = `IN ${diffDays} DAYS`;
                      badgeColor = "text-indigo-700 bg-indigo-50 border-indigo-100 font-extrabold";
                    }

                    return (
                      <div id={`upcoming-test-hero-${test.id}`} className="space-y-4 animate-fade-in">
                        <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl space-y-3">
                          <div className="flex items-center justify-between gap-3">
                            <span className="text-[10px] font-black tracking-widest uppercase bg-indigo-600 text-white px-2 py-0.5 rounded-md">
                              {test.course}
                            </span>
                            <span className={`text-[9.5px] tracking-wider px-2 py-0.5 rounded-md border ${badgeColor}`}>
                              {badgeText}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h4 className="font-extrabold text-slate-900 text-base tracking-tight leading-snug">
                              {test.title}
                            </h4>
                            <p className="text-xs text-slate-500">
                              By {test.creator} • {test.grade}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs bg-slate-50/50 border border-slate-100 p-3 rounded-xl">
                          <span className="text-slate-500 font-bold">Planned Test Date:</span>
                          <span className="text-slate-800 font-black font-mono">
                            {test.date}
                          </span>
                        </div>
                      </div>
                    );
                  })()
                ) : (
                  <div className="text-center py-6 bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
                    <Sparkles className="w-5 h-5 text-indigo-400 mx-auto mb-2" />
                    <h4 className="font-bold text-slate-700 text-sm">No Scheduled Tests</h4>
                  </div>
                )}
              </div>

              {/* Action Footer */}
              <div className="p-4 bg-white border-t border-slate-100 flex justify-end shrink-0">
                <button
                  id="upcoming-tests-popup-dismiss-btn"
                  onClick={() => setShowUpcomingTestsPopup(false)}
                  className="w-full text-center py-2 text-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition duration-150 cursor-pointer shadow-sm hover:shadow"
                >
                  Got it, Continue
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
