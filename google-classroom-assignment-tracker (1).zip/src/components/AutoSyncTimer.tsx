import React, { useEffect, useState } from "react";
import { RefreshCw, Play, Pause } from "lucide-react";

interface AutoSyncTimerProps {
  autoSync: boolean;
  intervalSec: number;
  onSync: () => void;
  isSyncing: boolean;
  lastSynced: Date | null;
  onToggleAutoSync: (enabled: boolean) => void;
  onIntervalChange: (sec: number) => void;
}

export default function AutoSyncTimer({
  autoSync,
  intervalSec,
  onSync,
  isSyncing,
  lastSynced,
  onToggleAutoSync,
  onIntervalChange,
}: AutoSyncTimerProps) {
  const [timeLeft, setTimeLeft] = useState(intervalSec);

  // Reset countdown when interval or autoSync mode changes
  useEffect(() => {
    setTimeLeft(intervalSec);
  }, [intervalSec, autoSync]);

  // Countdown timer loop
  useEffect(() => {
    if (!autoSync || isSyncing) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          return 0; // Set to 0 to trigger sync in useEffect safely
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [autoSync, isSyncing]);

  // Handle synchronization trigger safely outside of component state update flow
  useEffect(() => {
    if (timeLeft === 0) {
      onSync();
      setTimeLeft(intervalSec);
    }
  }, [timeLeft, intervalSec, onSync]);

  const percentage = autoSync ? (timeLeft / intervalSec) * 100 : 100;
  
  // Format last synced text nicely
  const formatLastSynced = () => {
    if (!lastSynced) return "Never synced";
    const secAgo = Math.floor((Date.now() - lastSynced.getTime()) / 1000);
    if (secAgo < 5) return "Just now";
    if (secAgo < 60) return `${secAgo}s ago`;
    const minAgo = Math.floor(secAgo / 60);
    return `${minAgo}m ago`;
  };

  const [lastSyncText, setLastSyncText] = useState(formatLastSynced());

  useEffect(() => {
    const textTimer = setInterval(() => {
      setLastSyncText(formatLastSynced());
    }, 3000);
    setLastSyncText(formatLastSynced());
    return () => clearInterval(textTimer);
  }, [lastSynced]);

  return (
    <div id="sync-timer-widget" className="bg-white rounded-xl border border-slate-100 p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div id="circular-timer-container" className="relative w-12 h-12 flex items-center justify-center">
          {/* Background SVG Circle */}
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="24"
              cy="24"
              r="20"
              className="stroke-slate-100"
              strokeWidth="3.5"
              fill="transparent"
            />
            {autoSync && !isSyncing && (
              <circle
                cx="24"
                cy="24"
                r="20"
                className="stroke-indigo-600 transition-all duration-1000 ease-linear"
                strokeWidth="3.5"
                fill="transparent"
                strokeDasharray={`${2 * Math.PI * 20}`}
                strokeDashoffset={`${2 * Math.PI * 20 * (1 - percentage / 100)}`}
                strokeLinecap="round"
              />
            )}
          </svg>
          <div className="absolute text-xs font-semibold text-slate-700">
            {autoSync ? `${timeLeft}s` : "Off"}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-slate-800 text-sm">Automated Realtime Sync</h3>
            <span
              className={`inline-block w-2.5 h-2.5 rounded-full ${
                isSyncing
                  ? "bg-amber-400 animate-pulse"
                  : autoSync
                  ? "bg-emerald-500"
                  : "bg-slate-300"
              }`}
            />
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {isSyncing ? "Syncing Google Classroom..." : `Last synced: ${lastSyncText}`}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 w-full md:w-auto justify-end">
        {/* Sync now button */}
        <button
          id="btn-manual-sync"
          disabled={isSyncing}
          onClick={onSync}
          className="flex items-center gap-2 px-3.5 py-1.5 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin text-indigo-600" : ""}`} />
          Sync Now
        </button>

        {/* Start / Stop Auto Sync */}
        <button
          id="btn-toggle-autosync"
          onClick={() => onToggleAutoSync(!autoSync)}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all border ${
            autoSync
              ? "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100"
              : "bg-indigo-550 hover:bg-indigo-600 text-white border-indigo-600"
          }`}
        >
          {autoSync ? (
            <>
              <Pause className="w-3.5 h-3.5" /> Stop Auto
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" /> Start Auto
            </>
          )}
        </button>

        {/* Set Sync Interval */}
        <select
          id="select-sync-interval"
          disabled={!autoSync}
          value={intervalSec}
          onChange={(e) => onIntervalChange(Number(e.target.value))}
          className="bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-lg p-1.5 font-medium focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 disabled:opacity-50"
        >
          <option value={15}>15s (Demo)</option>
          <option value={30}>30s</option>
          <option value={60}>1 min</option>
          <option value={300}>5 min</option>
        </select>
      </div>
    </div>
  );
}
