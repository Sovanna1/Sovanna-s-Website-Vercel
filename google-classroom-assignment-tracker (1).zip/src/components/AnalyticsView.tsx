import React, { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";
import { 
  GraduationCap, 
  BookOpen, 
  Clock, 
  Users, 
  Target, 
  Activity, 
  TrendingUp, 
  Award,
  Calendar,
  AlertCircle,
  TrendingDown,
  CheckCircle2,
  Upload,
  FileSpreadsheet,
  X
} from "lucide-react";
import { Course } from "../types";
import { studentsList } from "../studentsData";

const jpaLogo = "https://apps.jpa.org.kh/images/JPA-Logo.png";

// Static JPA senior reference roster matching original JPA dashboard details
const jpaSeniors = [
  { name: 'Mitona Ae', target: 1540, current: 1480, math: 770, ebrw: 710, courses: ['English Language and Composition', 'AP Calculus AB', 'AP Chemistry', 'AP Comparative Government', 'AP CSA'], club: 'SDC', gender: 'F' },
  { name: 'Malik Bora', target: 1500, current: 1420, math: 740, ebrw: 680, courses: ['English Language and Composition', 'AP Calculus AB', 'AP Chemistry', 'Economics 1', 'AP CSA'], club: 'SDC', gender: 'M' },
  { name: 'Samawatvotey Bun', target: 1520, current: 1460, math: 760, ebrw: 700, courses: ['English Language and Composition', 'AP Calculus AB', 'AP Chemistry', 'AP Comparative Government', 'AP CSA'], club: 'SDC', gender: 'F' },
  { name: 'Nita Chab', target: 1350, current: 1210, math: 590, ebrw: 620, courses: ['English Language and Composition', 'College Algebra', 'Conceptual Physics', 'Economics 1'], club: 'SDC', gender: 'F' },
  { name: 'Ravyketrya Eng', target: 1550, current: 1490, math: 780, ebrw: 710, courses: ['English Language and Composition', 'AP Calculus AB', 'AP Chemistry', 'AP Comparative Government', 'AP CSA'], club: 'SDC', gender: 'F' },
  { name: 'Sophea Heam', target: 1400, current: 1280, math: 640, ebrw: 640, courses: ['English Language and Composition', 'College Algebra', 'AP Chemistry', 'AP Human Geography'], club: 'SDC', gender: 'F' },
  { name: 'Sokoan Koeum', target: 1420, current: 1310, math: 690, ebrw: 620, courses: ['English Language and Composition', 'AP Calculus AB', 'Conceptual Physics', 'Economics 1'], club: 'Robotics', gender: 'F' },
  { name: 'Solida Lay', target: 1380, current: 1240, math: 600, ebrw: 640, courses: ['English Language and Composition', 'College Algebra', 'Conceptual Physics', 'AP Human Geography'], club: 'Sports', gender: 'F' },
  { name: 'Pannin Pann', target: 1480, current: 1410, math: 730, ebrw: 680, courses: ['English Language and Composition', 'AP Calculus AB', 'Conceptual Physics', 'Economics 1', 'AP CSA'], club: 'Robotics', gender: 'M' },
  { name: 'Liza Romudom', target: 1360, current: 1220, math: 580, ebrw: 640, courses: ['English Language and Composition', 'College Algebra', 'Conceptual Physics', 'AP Human Geography'], club: 'Sports', gender: 'F' },
  { name: 'Sona Set', target: 1530, current: 1470, math: 780, ebrw: 690, courses: ['English Language and Composition', 'AP Calculus AB', 'AP Chemistry', 'AP Comparative Government', 'AP CSA'], club: 'Running', gender: 'F' },
  { name: 'Sanny Siep', target: 1490, current: 1430, math: 750, ebrw: 680, courses: ['English Language and Composition', 'AP Calculus AB', 'Conceptual Physics', 'AP Comparative Government', 'AP CSA'], club: 'SDC', gender: 'M' },
  { name: 'Kanha Son', target: 1530, current: 1480, math: 760, ebrw: 720, courses: ['English Language and Composition', 'AP Calculus AB', 'AP Chemistry', 'AP Comparative Government', 'AP CSA'], club: 'Robotics', gender: 'F' },
  { name: 'Kolyan Yip', target: 1350, current: 1230, math: 610, ebrw: 620, courses: ['English Language and Composition', 'College Algebra', 'Conceptual Physics', 'AP Human Geography'], club: 'Robotics', gender: 'F' }
];

// Typical JPA SAT Prep Diagnostics History Timeline data (Weekly)
const diagnosticTimelineData: Record<string, Array<{ week: string; math: number; ebrw: number; total: number }>> = {
  'Mitona Ae': [
    { week: 'Diag 1', math: 710, ebrw: 650, total: 1360 },
    { week: 'Diag 2', math: 730, ebrw: 660, total: 1390 },
    { week: 'Diag 3', math: 750, ebrw: 690, total: 1440 },
    { week: 'Diag 4', math: 770, ebrw: 710, total: 1480 },
  ],
  'Malik Bora': [
    { week: 'Diag 1', math: 690, ebrw: 620, total: 1310 },
    { week: 'Diag 2', math: 710, ebrw: 640, total: 1350 },
    { week: 'Diag 3', math: 720, ebrw: 660, total: 1380 },
    { week: 'Diag 4', math: 740, ebrw: 680, total: 1420 },
  ],
  'Samawatvotey Bun': [
    { week: 'Diag 1', math: 720, ebrw: 670, total: 1390 },
    { week: 'Diag 2', math: 740, ebrw: 690, total: 1430 },
    { week: 'Diag 3', math: 750, ebrw: 690, total: 1440 },
    { week: 'Diag 4', math: 760, ebrw: 700, total: 1460 },
  ],
  'Nita Chab': [
    { week: 'Diag 1', math: 520, ebrw: 550, total: 1070 },
    { week: 'Diag 2', math: 550, ebrw: 580, total: 1130 },
    { week: 'Diag 3', math: 570, ebrw: 600, total: 1170 },
    { week: 'Diag 4', math: 590, ebrw: 620, total: 1210 },
  ],
  'Ravyketrya Eng': [
    { week: 'Diag 1', math: 730, ebrw: 660, total: 1390 },
    { week: 'Diag 2', math: 740, ebrw: 680, total: 1420 },
    { week: 'Diag 3', math: 770, ebrw: 700, total: 1470 },
    { week: 'Diag 4', math: 780, ebrw: 710, total: 1490 },
  ]
};

// Generic generator for timeline if student doesn't have custom data
const generateTimelineData = (mathScore: number, ebrwScore: number) => {
  return [
    { week: 'Diag 1', math: Math.max(400, mathScore - 70), ebrw: Math.max(400, ebrwScore - 60), total: Math.max(800, mathScore + ebrwScore - 130) },
    { week: 'Diag 2', math: Math.max(400, mathScore - 40), ebrw: Math.max(400, ebrwScore - 30), total: Math.max(800, mathScore + ebrwScore - 70) },
    { week: 'Diag 3', math: Math.max(400, mathScore - 20), ebrw: Math.max(400, ebrwScore - 10), total: Math.max(800, mathScore + ebrwScore - 30) },
    { week: 'Diag 4', math: mathScore, ebrw: ebrwScore, total: mathScore + ebrwScore },
  ];
};

// Radar masteries dataset (Subject Skill areas out of 100)
const mathMasteries = [
  { subject: 'Heart of Algebra', score: 88, fullMark: 100 },
  { subject: 'Passport to Advanced Math', score: 82, fullMark: 100 },
  { subject: 'Problem Solving & Data', score: 91, fullMark: 100 },
  { subject: 'Command of Evidence', score: 85, fullMark: 100 },
  { subject: 'Words in Context', score: 78, fullMark: 100 },
  { subject: 'Analysis in Science/Social', score: 84, fullMark: 100 },
];

interface AnalyticsViewProps {
  assignments?: any;
  courses: Course[];
  currentUser: any;
  isTeacher: boolean;
}

export default function AnalyticsView({ courses, currentUser, isTeacher }: AnalyticsViewProps) {
  // Ensure the logged in student resides in the roster list representation dynamically and mapping all grades
  const getSeniorsList = () => {
    // Map all students from studentsList to the required SAT profile structure
    const list = studentsList.map(s => {
      // Check if they already exist in the static jpaSeniors template to preserve realistic senior target/scores
      const existingSenior = jpaSeniors.find(js => js.name.toLowerCase() === s.name.toLowerCase());
      if (existingSenior) {
        return {
          ...existingSenior,
          lastName: s.lastName,
          firstName: s.firstName,
          grade: s.grade || "Grade 12",
        };
      }

      // Generate realistic scores based on grade for other students
      const gradeStr = s.grade || "Grade 12";
      let math = 600;
      let ebrw = 580;
      let target = 1450;
      
      if (gradeStr.includes("9")) {
        target = 1350;
        math = 530;
        ebrw = 520;
      } else if (gradeStr.includes("10")) {
        target = 1400;
        math = 580;
        ebrw = 570;
      } else if (gradeStr.includes("11")) {
        target = 1450;
        math = 630;
        ebrw = 620;
      } else {
        target = 1500;
        math = 680;
        ebrw = 670;
      }

      // Filter active custom schedule
      const sched = s.schedule || { english: "", math: "", science: "", socialStudies: "", other: "" };
      const activeCourses = [
        sched.english,
        sched.math,
        sched.science,
        sched.socialStudies,
        sched.other
      ].filter(Boolean);

      const clubs = ["SDC", "Robotics", "Sports", "Chess", "Running", "Debate"];
      const charCodeSum = s.name.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0);
      const club = clubs[charCodeSum % clubs.length];

      return {
        name: s.name,
        lastName: s.lastName,
        firstName: s.firstName,
        grade: gradeStr,
        target,
        current: math + ebrw,
        math,
        ebrw,
        courses: activeCourses.length > 0 ? activeCourses : ['English Language & Composition', 'AP Calculus AB', 'Conceptual Physics', 'Economics 1'],
        club,
        gender: s.gender || "M"
      };
    });

    if (currentUser && currentUser.displayName) {
      const exists = list.some(s => s.name.toLowerCase() === currentUser.displayName.toLowerCase());
      if (!exists) {
        list.push({
          name: currentUser.displayName,
          lastName: currentUser.displayName.split(" ")[1] || "",
          firstName: currentUser.displayName.split(" ")[0] || "",
          grade: "Grade 12",
          target: 1515,
          current: 1395,
          math: 710,
          ebrw: 685,
          courses: courses.map(c => c.name).slice(0, 4) || ['English Language and Composition', 'AP Calculus AB', 'Conceptual Physics', 'Economics 1'],
          club: 'SDC',
          gender: 'M'
        });
      }
    }
    return list;
  };

  const [seniors, setSeniors] = useState<any[]>(() => {
    const saved = localStorage.getItem("jpa_seniors_sat_scores");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {}
    }
    return getSeniorsList();
  });

  const [selectedGradeFilter, setSelectedGradeFilter] = useState<string>("All");

  // Sync state if currentUser changes preserving modified diagnostics and targets
  React.useEffect(() => {
    const freshList = getSeniorsList();
    setSeniors(prev => {
      if (!prev || prev.length === 0) return freshList;
      return freshList.map(item => {
        const match = prev.find(p => p.name.toLowerCase() === item.name.toLowerCase());
        if (match) {
          return {
            ...item,
            math: match.math,
            ebrw: match.ebrw,
            current: match.current,
            target: match.target
          };
        }
        return item;
      });
    });
  }, [currentUser, courses]);

  // Authorized list of names for making changes to Progress Insights
  const canEditProgress = React.useMemo(() => {
    if (!currentUser?.displayName) return false;
    const cleanName = currentUser.displayName.toLowerCase().replace(/[^a-z0-9]/g, "").trim();
    const authorizedAdminsAndTitles = [
      "ryanahlers",
      "naomilane",
      "stevemccambridge",
      "songsophannarith",
      "sophannarithsong",
      "sophanarithsong",
      "songsophanarith",
      "sothchenda",
      "chendasoth",
      "eaksangha",
      "kongsokthearoath",
      "chhayleangeng",
      "cheabunthai",
      "chouchsreyvong",
      "kaypheaktra",
      "sousreynuth",
      "chekchantrea"
    ];
    return authorizedAdminsAndTitles.includes(cleanName);
  }, [currentUser]);

  // Who can select other student profiles: Teachers OR the 13 authorized administrator members
  const canSelectAll = isTeacher || canEditProgress;

  const saveSeniors = (updatedSeniors: any[]) => {
    if (!canEditProgress) {
      alert("Permission Denied: Only authorized Leadership & Administration members can modify SAT prep scores.");
      return;
    }
    setSeniors(updatedSeniors);
    localStorage.setItem("jpa_seniors_sat_scores", JSON.stringify(updatedSeniors));
  };

  // If a student is logged in, restrict the selection and active profile strictly to their own name
  const defaultSelected = (!canSelectAll && currentUser?.displayName) ? currentUser.displayName : 'Malik Bora';
  const [selectedStudentName, setSelectedStudentName] = useState(defaultSelected);
  const [showFlashMsg, setShowFlashMsg] = useState<string | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [pasteText, setPasteText] = useState("");

  // Sync selection based on grade filter
  React.useEffect(() => {
    if (canSelectAll && selectedGradeFilter !== "All") {
      const currentGradeOfSelected = seniors.find(s => s.name.toLowerCase() === selectedStudentName.toLowerCase())?.grade;
      if (currentGradeOfSelected !== selectedGradeFilter) {
        const firstOfGrade = seniors.find(s => s.grade === selectedGradeFilter);
        if (firstOfGrade) {
          setSelectedStudentName(firstOfGrade.name);
        }
      }
    }
  }, [selectedGradeFilter, seniors, selectedStudentName, canSelectAll]);

  // Sync state if currentUser changes
  React.useEffect(() => {
    if (!canSelectAll && currentUser?.displayName) {
      setSelectedStudentName(currentUser.displayName);
    }
  }, [currentUser, canSelectAll]);

  const activeStudentName = (!canSelectAll && currentUser?.displayName) ? currentUser.displayName : selectedStudentName;

  // Active student details
  const currentStudent = seniors.find(s => s.name.toLowerCase() === activeStudentName.toLowerCase()) || seniors[0] || getSeniorsList()[0];

  // Specific or generated timeline
  const activeTimeline = diagnosticTimelineData[currentStudent.name] || generateTimelineData(currentStudent.math, currentStudent.ebrw);

  // Quick action: update current SAT diagnostic score
  const handleScoreUpdate = (field: 'math' | 'ebrw', value: number) => {
    if (!canEditProgress) {
      alert("Permission Denied: Only authorized Leadership & Administration members can modify SAT prep scores.");
      return;
    }
    if (value < 200 || value > 800) return;
    const updated = seniors.map(s => {
      if (s.name.toLowerCase() === currentStudent.name.toLowerCase()) {
        const item = { ...s, [field]: value };
        item.current = item.math + item.ebrw;
        return item;
      }
      return s;
    });
    saveSeniors(updated);
    setShowFlashMsg(`Updated SAT diagnostic scores for ${currentStudent.name}!`);
    setTimeout(() => setShowFlashMsg(null), 3000);
  };

  // Tolerant CSV / Google Sheet copy-paste tab-separated (TSV) parser
  const parseAndApplyScores = (textData: string) => {
    if (!canEditProgress) {
      alert("Permission Denied: Only authorized Leadership & Administration members can modify SAT prep scores.");
      return false;
    }
    const rows = textData.split(/\r?\n/).map(row => row.trim()).filter(Boolean);
    let matchedCount = 0;
    let fallbackUpdated = [...seniors];

    // Helper to detect correct cell separator for the batch
    const detectSeparator = (textLines: string[]): string => {
      // Sample first 5 lines
      const sample = textLines.slice(0, 5).join("\n");
      const tabCount = (sample.match(/\t/g) || []).length;
      const commaCount = (sample.match(/,/g) || []).length;
      const semiCount = (sample.match(/;/g) || []).length;
      if (tabCount > 0 && tabCount >= commaCount) return "\t";
      if (semiCount > commaCount) return ";";
      return ",";
    };

    // Parse standard CSV columns respecting quotes
    const parseCSVLine = (line: string, separator: string): string[] => {
      const result: string[] = [];
      let current = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"' || char === "'") {
          inQuotes = !inQuotes;
        } else if (char === separator && !inQuotes) {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
      result.push(current.trim());
      return result;
    };

    const cleanCell = (c: string) => c.trim().replace(/^["']|["']$/g, "").trim();

    const separator = detectSeparator(rows);

    let nameColIdx = -1;
    let firstNameColIdx = -1;
    let lastNameColIdx = -1;
    let mathColIdx = -1;
    let ebrwColIdx = -1;
    let targetColIdx = -1;

    rows.forEach((row, rowIdx) => {
      const rawCells = parseCSVLine(row, separator).map(cleanCell);
      if (rawCells.every(c => c === "")) return; // empty line
      const cells = rawCells;

      // Classify if this is a header row (helps map explicitly if column headers are provided)
      const isHeader = cells.some(c => {
        const lower = c.trim().toLowerCase();
        return lower === "student" || lower === "student name" || lower === "first name" || 
               lower === "last name" || lower === "math" || lower === "score" || 
               lower === "ebrw" || lower === "reading" || lower === "sat score";
      });

      if (isHeader) {
        cells.forEach((cell, idx) => {
          const l = cell.toLowerCase().trim();
          if (l.includes("student name") || l === "name" || l === "student" || l === "full name") nameColIdx = idx;
          else if (l.includes("first name") || l.includes("firstname") || l === "first") firstNameColIdx = idx;
          else if (l.includes("last name") || l.includes("lastname") || l === "last") lastNameColIdx = idx;
          else if (l.includes("math") || l === "m") mathColIdx = idx;
          else if (l.includes("ebrw") || l.includes("reading") || l.includes("writing") || l === "r" || l === "e") ebrwColIdx = idx;
          else if (l.includes("target") || l === "t" || l === "goal" || l.includes("expected")) targetColIdx = idx;
        });
        return; // Skip parsing header row as scores data
      }

      // Read values
      let studentNameStr = "";
      let mathVal = NaN;
      let ebrwVal = NaN;
      let targetVal = NaN;

      if (nameColIdx !== -1 || (firstNameColIdx !== -1 && lastNameColIdx !== -1)) {
        // Headers mapped! Use the precise column indices
        if (nameColIdx !== -1 && cells[nameColIdx]) {
          studentNameStr = cells[nameColIdx];
        } else {
          const fName = firstNameColIdx !== -1 && cells[firstNameColIdx] ? cells[firstNameColIdx] : "";
          const lName = lastNameColIdx !== -1 && cells[lastNameColIdx] ? cells[lastNameColIdx] : "";
          studentNameStr = `${fName} ${lName}`.trim();
        }

        if (mathColIdx !== -1 && cells[mathColIdx]) {
          mathVal = parseInt(cells[mathColIdx], 10);
        }
        if (ebrwColIdx !== -1 && cells[ebrwColIdx]) {
          ebrwVal = parseInt(cells[ebrwColIdx], 10);
        }
        if (targetColIdx !== -1 && cells[targetColIdx]) {
          targetVal = parseInt(cells[targetColIdx], 10);
        }
      } else {
        // Fallback to highly flexible cell heuristics (No headers defined / typical export)
        const numbers: { val: number; originalIdx: number }[] = [];
        const strings: { val: string; originalIdx: number }[] = [];

        cells.forEach((cell, idx) => {
          if (!cell.trim()) return;
          const cleanVal = cell.replace(/[,]/g, "").trim(); // strip comma separator inside digits like 1,450
          const num = parseInt(cleanVal, 10);
          if (!isNaN(num) && /^\d+$/.test(cleanVal)) {
            numbers.push({ val: num, originalIdx: idx });
          } else {
            strings.push({ val: cell, originalIdx: idx });
          }
        });

        // The name is typically the concatenation of all leading non-numeric values
        if (strings.length > 0) {
          studentNameStr = strings.map(s => s.val).join(" ");
        }

        // SAT section scores reside strictly between 200 and 800 inclusive
        const possibleSectionScores = numbers.filter(n => n.val >= 200 && n.val <= 800);
        const possibleComposites = numbers.filter(n => n.val > 800 && n.val <= 1600);

        if (possibleSectionScores.length >= 2) {
          // Assume Math is first, EBRW is second
          mathVal = possibleSectionScores[0].val;
          ebrwVal = possibleSectionScores[1].val;
        } else if (numbers.length >= 2) {
          // Fallback to any two parsed digits
          mathVal = numbers[0].val;
          ebrwVal = numbers[1].val;
        }

        if (possibleComposites.length > 0) {
          targetVal = possibleComposites[0].val;
        } else if (numbers.length >= 3) {
          targetVal = numbers[2].val;
        }
      }

      // Process and find high-overlap fuzzy match in the students roster list representation
      if (studentNameStr && studentNameStr.trim().length > 0) {
        const normalizeWords = (nm: string) => {
          return nm.toLowerCase()
            .replace(/[^a-z0-9\s]/g, "")
            .split(/\s+/)
            .filter(Boolean);
        };

        const getSortedWordString = (nm: string) => {
          return normalizeWords(nm).sort().join("");
        };

        const targetWords = normalizeWords(studentNameStr);
        const targetSortedWordStr = getSortedWordString(studentNameStr);

        const matchIndex = fallbackUpdated.findIndex(s => {
          const studentWords = normalizeWords(s.name);
          const studentSortedWordStr = getSortedWordString(s.name);

          // Case 1: Perfect match
          if (s.name.toLowerCase() === studentNameStr.toLowerCase()) return true;

          // Case 2: Clean/Normalized exact match (handles commas/slashes)
          if (studentSortedWordStr === targetSortedWordStr) return true;

          // Case 3: Commutative full names (e.g. "Ae Mitona" and "Mitona Ae")
          if (studentWords.length === 2 && targetWords.length === 2) {
            if (studentWords.includes(targetWords[0]) && studentWords.includes(targetWords[1])) {
              return true;
            }
          }

          // Case 4: Mutual inclusive word sets
          const hasAllRosterWords = studentWords.length > 0 && studentWords.every(w => targetWords.includes(w));
          const hasAllTargetWords = targetWords.length > 0 && targetWords.every(w => studentWords.includes(w));
          if (hasAllRosterWords || hasAllTargetWords) return true;

          // Case 5: Word-level sub-matching (for middle names, initials e.g. "Sanny Siep" and "Sanny A. Siep")
          const commonWords = studentWords.filter(w => targetWords.includes(w));
          if (commonWords.length >= 2) return true;

          return false;
        });

        if (matchIndex !== -1) {
          const matchedStudent = fallbackUpdated[matchIndex];
          const finalMath = !isNaN(mathVal) ? Math.max(200, Math.min(800, mathVal)) : matchedStudent.math;
          const finalEbrw = !isNaN(ebrwVal) ? Math.max(200, Math.min(800, ebrwVal)) : matchedStudent.ebrw;
          const finalTarget = !isNaN(targetVal) ? Math.max(400, Math.min(1600, targetVal)) : matchedStudent.target;

          fallbackUpdated[matchIndex] = {
            ...matchedStudent,
            math: finalMath,
            ebrw: finalEbrw,
            target: finalTarget,
            current: finalMath + finalEbrw
          };
          matchedCount++;
        }
      }
    });

    if (matchedCount > 0) {
      saveSeniors(fallbackUpdated);
      setShowFlashMsg(`Successfully imported and updated SAT scores for ${matchedCount} matching student profiles!`);
      setTimeout(() => setShowFlashMsg(null), 4000);
      return true;
    } else {
      alert("No matching student profile names were found in the provided sheet data. Please ensure the first column lists valid registered student names (e.g. Malik Bora or Mitona Ae), followed by Math and EBRW scores.");
      return false;
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const success = parseAndApplyScores(text);
        if (success) {
          setIsImportModalOpen(false);
        }
      }
    };
    reader.readAsText(file);
  };

  const handlePasteSubmit = () => {
    if (!pasteText.trim()) return;
    const success = parseAndApplyScores(pasteText);
    if (success) {
      setPasteText("");
      setIsImportModalOpen(false);
    }
  };

  const filteredSeniors = selectedGradeFilter === "All"
    ? seniors
    : seniors.filter(s => s.grade === selectedGradeFilter);

  return (
    <div className="space-y-8 flex-1 flex flex-col h-full bg-slate-50/20 max-w-6xl mx-auto w-full">
      {showFlashMsg && (
        <div id="sat-notification-toast" className="fixed top-24 right-6 z-50 bg-slate-900 border border-slate-700 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-semibold animate-pulse">
          <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0" />
          <span>{showFlashMsg}</span>
        </div>
      )}

      {/* Premium Header Segment */}
      <div className="flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-5 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="flex items-center gap-3">
          <img
            src={jpaLogo}
            alt="JPA Logo"
            className="w-12 h-12 rounded-xl shadow-xs shrink-0 object-contain bg-[#3b6cb3] p-1 border border-slate-100 dark:border-slate-800"
          />
          <div>
            <h2 className="text-xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2 flex-wrap sm:flex-nowrap">
              JPA SAT Prep & Analytics
              {canEditProgress ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-black uppercase tracking-wider">
                  ● Leadership Mode
                </span>
              ) : isTeacher ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-black uppercase tracking-wider">
                  ● Faculty (View-Only)
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-50 text-slate-600 border border-slate-200 text-[10px] font-black uppercase tracking-wider">
                  ● Student (View-Only)
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500 mt-1 font-medium max-w-lg leading-relaxed">
              Diagnostic tracking, practice benchmarks, and testing timelines for JPA Students (Grades 9-12).
            </p>
          </div>
        </div>

        {/* Student selector / display depending on teacher/student role */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 justify-end flex-wrap">
          {canSelectAll && (
            <div className="flex flex-wrap items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
              {["All", "Grade 9", "Grade 10", "Grade 11", "Grade 12"].map((g) => (
                <button
                  key={g}
                  onClick={() => setSelectedGradeFilter(g)}
                  className={`px-3 py-1 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${
                    selectedGradeFilter === g
                      ? "bg-white text-indigo-600 shadow-xs"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  {g === "All" ? "All Grades" : g}
                </button>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2.5 flex-wrap">
            {canSelectAll ? (
              <>
                <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider hidden md:inline">Active Profile</span>
                <select
                  id="sat-analytics-student-select"
                  value={selectedStudentName}
                  onChange={(e) => setSelectedStudentName(e.target.value)}
                  className="bg-white border border-slate-200 hover:border-slate-300 text-slate-700 py-1.5 px-3 rounded-xl text-xs font-bold shadow-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition cursor-pointer max-w-[180px]"
                >
                  {filteredSeniors.map((s) => (
                    <option key={s.name} value={s.name}>
                      {s.name} ({s.grade})
                    </option>
                  ))}
                </select>

                {canEditProgress && (
                  <button
                    type="button"
                    onClick={() => setIsImportModalOpen(true)}
                    className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs shrink-0 cursor-pointer"
                    title="Import student scores via CSV file or copy-paste spreadsheet"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Import Scores</span>
                  </button>
                )}
              </>
            ) : (
              <div className="flex flex-col items-end">
                <div className="flex items-center gap-2 bg-indigo-50/70 border border-indigo-150 px-3.5 py-1.5 rounded-xl">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-pulse" />
                  <span className="text-xs font-extrabold text-indigo-700">{currentStudent.name}</span>
                </div>
                <span className="text-[10px] font-bold text-slate-400 mr-2 mt-0.5 uppercase tracking-wider">{currentStudent.grade || "Grade 12"}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* High-Level SAT Key Metrics Indicators */}
      <div id="sat-metrics-deck" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Composite Diagnostic */}
        <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">SAT Composite</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 border border-indigo-100/50">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-slate-800 mt-3">{currentStudent.current}</p>
          <div className="text-[10px] text-slate-500 mt-2 font-semibold flex items-center gap-1">
            <span className="text-indigo-600 font-bold">Target: {currentStudent.target}</span> • Progress: {Math.round((currentStudent.current / currentStudent.target) * 100)}%
          </div>
          {/* Progress Bar */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2.5 overflow-hidden">
            <div 
              className="bg-indigo-600 h-full rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, Math.round((currentStudent.current / currentStudent.target) * 100))}%` }}
            />
          </div>
        </div>

        {/* Section Score EBRW */}
        <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">EBRW Score</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 border border-emerald-100/50">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-slate-800 mt-3">{currentStudent.ebrw}</p>
          {canEditProgress ? (
            <>
              <div className="mt-2.5 flex items-center gap-2">
                <input 
                  type="range" 
                  min="200" 
                  max="800" 
                  step="10"
                  value={currentStudent.ebrw}
                  onChange={(e) => handleScoreUpdate('ebrw', parseInt(e.target.value, 10))}
                  className="w-full h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
              </div>
              <span className="text-[9px] text-emerald-600 font-extrabold mt-1 block tracking-tight">Drag slider to adjust diagnostics</span>
            </>
          ) : (
            <>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.round(((currentStudent.ebrw - 200) / 600) * 100)}%` }}
                />
              </div>
              <span className="text-[9px] text-slate-400 font-bold mt-1 block">Diagnostics official report score (View Only)</span>
            </>
          )}
        </div>

        {/* Section Score Math */}
        <div className="bg-white rounded-xl border border-slate-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">Math Score</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600 border border-amber-100/50">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-slate-800 mt-3">{currentStudent.math}</p>
          {canEditProgress ? (
            <>
              <div className="mt-2.5 flex items-center gap-2">
                <input 
                  type="range" 
                  min="200" 
                  max="800" 
                  step="10"
                  value={currentStudent.math}
                  onChange={(e) => handleScoreUpdate('math', parseInt(e.target.value, 10))}
                  className="w-full h-1 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-amber-600"
                />
              </div>
              <span className="text-[9px] text-amber-600 font-extrabold mt-1 block tracking-tight">Drag slider to adjust diagnostics</span>
            </>
          ) : (
            <>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                <div 
                  className="bg-amber-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.round(((currentStudent.math - 200) / 600) * 100)}%` }}
                />
              </div>
              <span className="text-[9px] text-slate-400 font-bold mt-1 block">Diagnostics official report score (View Only)</span>
            </>
          )}
        </div>

        {/* Next Official Registration Deadline */}
        <div className="bg-gradient-to-br from-indigo-900 to-slate-900 border border-slate-800 rounded-xl p-5 shadow-xs text-white">
          <div className="flex items-center justify-between text-indigo-300">
            <span className="text-[10px] font-extrabold uppercase tracking-wide">Next Official SAT</span>
            <Calendar className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-xl font-black mt-2">Oct 10, 2026</p>
          <p className="text-[11px] text-white/70 font-medium">Standard Registration open.</p>
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-bold text-[9px] mt-2 border border-indigo-400/20">
            JPA Testing Center
          </div>
        </div>
      </div>

      {/* Middle Interactive Grid: Timeline Scoring Line Chart & Skill Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scoring progress over time line chart */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 md:p-6 shadow-xs lg:col-span-2 flex flex-col">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-6">
            <div>
              <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-500" />
                Diagnostic Growth Progression
              </h3>
              <p className="text-[11px] text-slate-400 font-medium mt-0.5">Scoring records trajectory from baseline (Diag 1) to final check</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-500">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Math
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-500">
                <span className="w-2 h-2 rounded-full bg-violet-500" /> EBRW
              </span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={activeTimeline} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="week" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} domain={[300, 800]} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderRadius: "12px", border: "none", color: "#fff" }}
                  labelStyle={{ fontSize: "11px", fontWeight: "extrabold", color: "#a5b4fc" }}
                  itemStyle={{ fontSize: "11.5px" }}
                />
                <Line
                  type="monotone"
                  dataKey="math"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ r: 4, stroke: "#10b981", strokeWidth: 2, fill: "#fff" }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="ebrw"
                  stroke="#8b5cf6"
                  strokeWidth={3}
                  dot={{ r: 4, stroke: "#8b5cf6", strokeWidth: 2, fill: "#fff" }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* SAT Masteries Sub-domain Tracker */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 md:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-indigo-500" />
              Subtopic Strengths & Focus areas
            </h3>
            <p className="text-[11px] text-slate-400 font-medium mt-0.5">Mastery percentage levels across SAT topics</p>
          </div>

          <div className="h-56 my-3 relative flex items-center justify-center">
            {/* Radar representation of mastery focus points */}
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={mathMasteries}>
                <PolarGrid stroke="#e2e8f0" />
                <PolarAngleAxis dataKey="subject" stroke="#64748b" fontSize={9} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#cbd5e1" fontSize={8} />
                <Radar name="Scoring Profile" dataKey="score" stroke="#4f46e5" fill="#818cf8" fillOpacity={0.4} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
            <span className="text-[10px] font-extrabold text-indigo-700 tracking-wider uppercase block">Focus recommendation</span>
            <p className="text-[11px] text-slate-600 font-medium mt-1">
              Maximize practice on <strong className="text-slate-700">Words in Context</strong> and <strong className="text-slate-700">Advanced Math</strong> to accelerate past the target score ceiling.
            </p>
          </div>
        </div>
      </div>

      {/* Teacher Score Import Dialog Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" 
            onClick={() => setIsImportModalOpen(false)}
          />

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-150">
              <div className="flex items-center gap-2">
                <span className="p-2 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
                  <FileSpreadsheet className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-800">Import Students SAT Scores</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Teacher Console</p>
                </div>
              </div>
              <button 
                onClick={() => setIsImportModalOpen(false)}
                className="p-1 px-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition duration-150 cursor-pointer text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-5">
              <div className="text-xs text-slate-500 leading-relaxed font-semibold">
                Match scorecard columns easily with comma-separated (<code className="bg-slate-50 border border-slate-100 px-1 py-0.5 rounded text-indigo-600">.csv</code>) text or tab-separated inputs from <strong className="text-slate-700">Google Sheets/Excel</strong> copy-pasting. 
              </div>

              {/* Sample Instructions */}
              <div className="bg-slate-50 border border-slate-100/95 rounded-xl p-3.5 space-y-1.5">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">Expected format (Order: Name, Math, EBRW, [Optional] Target)</span>
                <div className="font-mono text-[10px] text-slate-500 space-y-0.5 select-none leading-relaxed">
                  <div>Mitona Ae, 770, 715</div>
                  <div>Malik Bora, 750, 690, 1510</div>
                  <div>Sophea Heam, 660, 650</div>
                </div>
              </div>

              {/* Option A: Upload File */}
              <div className="space-y-2">
                <label className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block">Option A: Upload .csv or .txt scorecard</label>
                <div className="relative border-2 border-dashed border-slate-250 hover:border-slate-350 rounded-xl p-6 text-center cursor-pointer transition bg-slate-50/25 flex flex-col items-center justify-center group">
                  <input 
                    type="file" 
                    accept=".csv,.txt"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 w-full h-full cursor-pointer" 
                  />
                  <Upload className="w-8 h-8 text-slate-400 group-hover:text-indigo-600 transition duration-200 mb-2" />
                  <span className="text-xs font-bold text-slate-600">Choose CSV File</span>
                  <span className="text-[10px] text-slate-400 mt-1 font-semibold">Drag & drop spreadsheet or click to scan</span>
                </div>
              </div>

              {/* Option B: Copy Paste Area */}
              <div className="space-y-2">
                <label className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block">Option B: Paste directly from Google Sheets / Excel</label>
                <textarea
                  rows={4}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  placeholder="Paste table columns from spreadsheet here...&#10;e.g. Soklyly Chea	720	680"
                  className="w-full bg-slate-50 border border-slate-200 focus:bg-white focus:ring-2 focus:ring-indigo-500 rounded-xl p-3 text-xs font-medium font-mono text-slate-700 placeholder:text-slate-400 outline-none transition"
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-150 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setIsImportModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-700 hover:bg-slate-200/50 rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handlePasteSubmit}
                disabled={!pasteText.trim()}
                className={`px-4 py-2 text-xs font-bold text-white rounded-xl shadow-xs transition cursor-pointer ${
                  pasteText.trim()
                    ? "bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800"
                    : "bg-slate-300 cursor-not-allowed"
                }`}
              >
                Import Sheet Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
