import React, { useState } from "react";
import {
  LayoutDashboard,
  BookOpen,
  BarChart3,
  Bell,
  Settings,
  GraduationCap,
  Users,
  Compass,
  FileSpreadsheet,
  LogOut,
  FolderSync,
  ClipboardCheck,
  Globe,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

const jpaLogo = "https://apps.jpa.org.kh/images/JPA-Logo.png";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  notificationsCount: number;
  userRole?: string;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  notificationsCount,
  userRole,
}: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    { id: "dashboard", label: "Assignments Hub", icon: LayoutDashboard },
    ...(userRole === "teacher"
      ? [{ id: "student-roster", label: "Student Roster (Admin)", icon: FolderSync }]
      : []
    ),
    { id: "homework-sheet", label: "Shared Homework Sheet", icon: FileSpreadsheet },
    { id: "courses", label: "Classrooms", icon: BookOpen },
    { id: "snacks", label: "Class Rotations", icon: ClipboardCheck },
    { id: "contacts", label: "Contacts & Teachers", icon: Users },
    { id: "globe", label: "Alumni Globe", icon: Globe },
    { id: "analytics", label: "Progress Insights", icon: BarChart3 },
    { id: "notifications", label: "Notifications", icon: Bell, badge: notificationsCount },
    { id: "settings", label: "Settings & Setup", icon: Settings },
  ];

  return (
    <aside id="app-sidebar" className={`${isCollapsed ? 'w-20' : 'w-64'} bg-white border-r border-slate-200 flex flex-col shrink-0 relative z-40 transition-all duration-300 ease-in-out`}>
      {/* Top Brand Block */}
      <div id="sidebar-brand-name" className={`flex items-center p-5 border-b border-slate-100 relative ${isCollapsed ? 'justify-center' : 'gap-3'}`}>
        <img
          src={jpaLogo}
          alt="JPA Logo"
          className="w-10 h-10 rounded-xl shadow-md shrink-0 object-contain bg-[#3b6cb3] p-1 border border-slate-100 dark:border-slate-800"
        />
        
        {!isCollapsed && (
          <div className="overflow-hidden pr-6">
            <h1 className="font-bold text-slate-800 text-[13px] tracking-tight leading-snug truncate">JPA Quick Access Portal</h1>
            <span className="text-[9px] text-indigo-600 font-bold tracking-wider uppercase block truncate font-mono">Assignment Engine</span>
          </div>
        )}

        <button 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={`absolute ${isCollapsed ? '-right-3 top-6' : 'right-4 top-1/2 -translate-y-1/2'} w-6 h-6 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 shadow-sm z-50 transition-colors`}
        >
          {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Main Navigation Menu */}
      <nav id="sidebar-navigation" className={`flex-1 overflow-y-auto no-scrollbar py-4 ${isCollapsed ? 'px-2' : 'px-3'} space-y-1`}>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full text-left group rounded-xl transition-all duration-200 ease-out flex items-center relative ${
                isActive
                  ? "bg-indigo-50 text-indigo-700 font-bold"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900 font-semibold"
              } ${isCollapsed ? 'px-0 py-3 justify-center' : 'px-3 py-2.5'}`}
              title={isCollapsed ? item.label : undefined}
            >
              <Icon className={`w-4.5 h-4.5 shrink-0 ${!isCollapsed ? 'mr-3' : ''} ${isActive ? "text-indigo-600" : "text-slate-400 group-hover:text-slate-600"}`} />
              
              {!isCollapsed && (
                <>
                  <span className="text-xs truncate flex-1 md:whitespace-normal leading-tight">
                    {item.label}
                  </span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="h-4 px-1.5 min-w-4 rounded-full bg-rose-500 border border-white text-white font-bold text-[9px] flex items-center justify-center shrink-0 shadow-sm ml-2">
                      {item.badge}
                    </span>
                  )}
                </>
              )}

              {isCollapsed && item.badge !== undefined && item.badge > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-rose-500 border border-white flex items-center justify-center shrink-0 shadow-sm"></span>
              )}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
