import React, { useState } from "react";
import { Calendar, Award, CheckCircle2, AlertTriangle, Clock, ArrowRight, ExternalLink, ChevronDown, ChevronUp } from "lucide-react";
import { UnifiedAssignment } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface AssignmentCardProps {
  assignment: UnifiedAssignment;
  isLiveMode: boolean;
  onTurnIn?: (id: string) => void;
}

const AssignmentCard: React.FC<AssignmentCardProps> = ({
  assignment,
  isLiveMode,
  onTurnIn,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Format Due Date
  const getDueDateDisplay = () => {
    if (!assignment.dueDate) return { text: "No due date", color: "text-slate-500 bg-slate-50 border-slate-200" };

    const now = new Date();
    const due = new Date(assignment.dueDate);
    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    // Express as hour details if due today
    if (Math.abs(diffTime) < 86400000) {
      const isOverdue = diffTime < 0;
      const opts: Intl.DateTimeFormatOptions = { hour: "2-digit", minute: "2-digit" };
      const timeStr = due.toLocaleTimeString([], opts);
      if (isOverdue) {
        return { text: `Overdue (Due today at ${timeStr})`, color: "text-rose-600 bg-rose-50 border-rose-150" };
      }
      return { text: `Due today at ${timeStr}`, color: "text-amber-600 bg-amber-50 border-amber-150 animate-pulse" };
    }

    if (diffDays < 0) {
      const positiveDays = Math.abs(diffDays);
      return {
        text: `Overdue by ${positiveDays} day${positiveDays > 1 ? "s" : ""}`,
        color: "text-rose-600 bg-rose-50 border-rose-200"
      };
    }

    if (diffDays === 1) {
      return { text: "Due tomorrow", color: "text-amber-600 bg-amber-50 border-amber-200" };
    }

    if (diffDays <= 3) {
      return { text: `Due in ${diffDays} days`, color: "text-indigo-600 bg-indigo-50 border-indigo-150" };
    }

    return {
      text: due.toLocaleDateString([], { month: "short", day: "numeric", weekday: "short" }),
      color: "text-slate-600 bg-slate-50 border-slate-150"
    };
  };

  const dueDisplay = getDueDateDisplay();

  // Mode based visual colors
  const courseColors: Record<string, { badge: string; border: string; bar: string }> = {
    indigo: { badge: "bg-indigo-50 text-indigo-700", border: "border-indigo-100", bar: "bg-indigo-600" },
    emerald: { badge: "bg-emerald-50 text-emerald-700", border: "border-emerald-100", bar: "bg-emerald-600" },
    amber: { badge: "bg-amber-50 text-amber-700", border: "border-amber-100", bar: "bg-amber-600" },
    rose: { badge: "bg-rose-50 text-rose-700", border: "border-rose-100", bar: "bg-rose-600" },
    violet: { badge: "bg-violet-50 text-violet-700", border: "border-violet-100", bar: "bg-violet-600" },
    sky: { badge: "bg-sky-50 text-sky-700", border: "border-sky-100", bar: "bg-sky-600" },
  };

  const cColor = courseColors[assignment.courseColor] || courseColors.indigo;

  // Status Badge Rendering
  const renderStatusBadge = () => {
    switch (assignment.state) {
      case "graded":
        return (
          <div className="flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-150 px-2.5 py-1 rounded-full text-xs font-bold leading-none">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Graded: {assignment.grade} / {assignment.maxPoints}
          </div>
        );
      case "submitted":
        return (
          <div className="flex items-center gap-1 bg-blue-50 text-blue-700 border border-blue-150 px-2.5 py-1 rounded-full text-xs font-bold leading-none">
            <Clock className="w-3.5 h-3.5" />
            Turned in
          </div>
        );
      case "missing":
        return (
          <div className="flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-150 px-2.5 py-1 rounded-full text-xs font-bold leading-none">
            <AlertTriangle className="w-3.5 h-3.5 animate-bounce" />
            Missing
          </div>
        );
      case "assigned":
      default:
        return (
          <div className="flex items-center gap-1 bg-indigo-50 text-indigo-700 border border-indigo-150 px-2.5 py-1 rounded-full text-xs font-bold leading-none">
            <Calendar className="w-3.5 h-3.5" />
            Assigned
          </div>
        );
    }
  };

  return (
    <div
      id={`assignment-card-${assignment.id}`}
      className="bg-white rounded-xl border border-slate-100 hover:border-slate-300 shadow-xs hover:shadow-sm overflow-hidden transition-all duration-200"
    >
      <div className="flex">
        {/* Course code accent block */}
        <div className={`w-1.5 shrink-0 ${cColor.bar}`} />

        <div className="p-5 flex-1 select-none">
          {/* Tag & Status Row */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 mb-3">
            <span className={`text-[10px] px-2.5 py-0.5 rounded-md font-bold tracking-wide uppercase ${cColor.badge} border ${cColor.border}`}>
              {assignment.courseName}
            </span>
            {renderStatusBadge()}
          </div>

          {/* Title and Expansion Action */}
          <div
            onClick={() => setIsExpanded(!isExpanded)}
            className="cursor-pointer group flex items-start justify-between gap-4"
          >
            <h4 className="font-bold text-slate-800 text-sm md:text-base leading-tight group-hover:text-indigo-600 transition-colors">
              {assignment.title}
            </h4>
            <button
              id={`btn-expand-${assignment.id}`}
              className="text-slate-400 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 p-1 rounded-md shrink-0 transition"
            >
              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>

          {/* Core Info Footnotes */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 mt-3 text-xs text-slate-500 font-medium">
            <div className={`flex items-center gap-1 px-2 py-0.5 border rounded-md ${dueDisplay.color}`}>
              <Calendar className="w-3.5 h-3.5" />
              <span>{dueDisplay.text}</span>
            </div>

            {assignment.maxPoints !== undefined && (
              <div className="flex items-center gap-1 text-slate-500">
                <Award className="w-3.5 h-3.5" />
                <span>{assignment.maxPoints} points</span>
              </div>
            )}
          </div>

          {/* Expandable description body */}
          <AnimatePresence initial={false}>
            {isExpanded && (
              <motion.div
                key="content"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <div id="description-drawer" className="mt-4 pt-4 border-t border-slate-50 text-slate-600 text-xs md:text-sm whitespace-pre-line leading-relaxed">
                  {assignment.description ? (
                    <p>{assignment.description}</p>
                  ) : (
                    <em className="text-slate-400">No coursework description instructions provided.</em>
                  )}

                  {/* Actions Area */}
                  <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-4 border-t border-slate-50">
                    <div className="text-[10px] text-slate-400">
                      ID: {assignment.id}
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Submit Demo Button */}
                      {!isLiveMode && (assignment.state === "assigned" || assignment.state === "missing") && onTurnIn && (
                        <button
                          id={`btn-turn-in-${assignment.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onTurnIn(assignment.id);
                          }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold rounded-lg text-xs leading-none transition"
                        >
                          Mark as Turned In
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* External Classroom Link */}
                      <a
                        id={`link-google-classroom-${assignment.id}`}
                        href={assignment.alternateLink || "https://classroom.google.com"}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="flex items-center gap-1 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold border border-slate-200 rounded-lg text-xs leading-none transition"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Open in GC
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default AssignmentCard;
