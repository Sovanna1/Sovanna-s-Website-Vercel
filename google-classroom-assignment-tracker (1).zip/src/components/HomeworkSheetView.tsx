import React, { useState } from "react";
import { SharedHomework, Course } from "../types";
import {
  FileSpreadsheet,
  Plus,
  Trash2,
  Edit3,
  Calendar,
  Layers,
  Search,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  GraduationCap,
  Lock
} from "lucide-react";

interface HomeworkSheetViewProps {
  homeworkList: SharedHomework[];
  courses: Course[];
  currentGrade?: string;
  currentUserId?: string;
  currentUserName?: string;
  onSaveHomework: (item: SharedHomework) => void;
  onDeleteHomework: (id: string) => void;
}

const PREDEFINED_COURSES = [
  { name: "English Language & Composition", color: "indigo" },
  { name: "World Literature & Composition", color: "indigo" },
  { name: "Foundations of Lang & Lit", color: "indigo" },
  { name: "English 1", color: "indigo" },
  { name: "AP Calculus AB", color: "violet" },
  { name: "AP Precalculus", color: "violet" },
  { name: "Algebra 2", color: "violet" },
  { name: "College Algebra", color: "violet" },
  { name: "AP Chemistry", color: "emerald" },
  { name: "Conceptual Physics", color: "emerald" },
  { name: "AP Biology", color: "emerald" },
  { name: "Chemistry", color: "emerald" },
  { name: "AP Comparative Government", color: "rose" },
  { name: "Economics 1", color: "rose" },
  { name: "AP Human Geography", color: "rose" },
  { name: "AP Computer Science A (AP CSA)", color: "amber" },
  { name: "AP CSP", color: "amber" }
];

export default function HomeworkSheetView({
  homeworkList,
  courses,
  currentGrade = "All Grades",
  currentUserId = "",
  currentUserName = "Student",
  onSaveHomework,
  onDeleteHomework,
}: HomeworkSheetViewProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [gradeFilter, setGradeFilter] = useState<string>(currentGrade);

  // Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formTitle, setFormTitle] = useState("");
  const [formDesc, setFormDesc] = useState("");
  const [formCourseName, setFormCourseName] = useState("");
  const [formCourseColor, setFormCourseColor] = useState("indigo");
  const [formGradeLevel, setFormGradeLevel] = useState(currentGrade === "All Grades" ? "Grade 9" : currentGrade);
  const [formDueDate, setFormDueDate] = useState("");
  const [formMaxPoints, setFormMaxPoints] = useState<number>(100);

  // Prepopulate form for adding or editing
  const handleOpenAdd = () => {
    setEditingId(null);
    setFormTitle("");
    setFormDesc("");
    const matched = PREDEFINED_COURSES[0];
    setFormCourseName(matched.name);
    setFormCourseColor(matched.color);
    setFormGradeLevel(currentGrade === "All Grades" ? "Grade 9" : currentGrade);
    
    // Set due date to tomorrow at 5 PM local
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setFormDueDate(tomorrow.toISOString().split("T")[0]);
    setFormMaxPoints(100);
    setShowAddForm(true);
  };

  const handleOpenEdit = (item: SharedHomework) => {
    const isAllowedToUpdate = currentGrade === "All Grades" || item.gradeLevel === currentGrade;
    if (!isAllowedToUpdate) {
      alert(`Access Denied: You are signed in as a ${currentGrade} student. You are only permitted to update the ${currentGrade} Shared Homework Sheet.`);
      return;
    }
    setEditingId(item.id);
    setFormTitle(item.title);
    setFormDesc(item.description || "");
    setFormCourseName(item.courseName);
    setFormCourseColor(item.courseColor);
    setFormGradeLevel(item.gradeLevel);
    setFormDueDate(item.dueDate ? item.dueDate.split("T")[0] : "");
    setFormMaxPoints(item.maxPoints || 100);
    setShowAddForm(true);
  };

  const handleSelectCoursePreset = (name: string) => {
    setFormCourseName(name);
    const preset = PREDEFINED_COURSES.find(p => p.name === name);
    if (preset) {
      setFormCourseColor(preset.color);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formCourseName.trim()) return;

    // Enforce target grade level scope based on currentGrade
    const targetGrade = currentGrade !== "All Grades" ? currentGrade : formGradeLevel;

    const homeworkId = editingId || `shared-hw-${Date.now()}`;
    const newHw: SharedHomework = {
      id: homeworkId,
      courseId: editingId ? (homeworkList.find(h => h.id === editingId)?.courseId || `course-${Date.now()}`) : `course-${Date.now()}`,
      courseName: formCourseName.trim(),
      courseColor: formCourseColor,
      title: formTitle.trim(),
      description: formDesc.trim() || undefined,
      dueDate: formDueDate ? new Date(formDueDate).toISOString() : null,
      maxPoints: formMaxPoints || undefined,
      createdBy: editingId ? (homeworkList.find(h => h.id === editingId)?.createdBy || currentUserName) : currentUserName,
      createdById: editingId ? (homeworkList.find(h => h.id === editingId)?.createdById || currentUserId) : currentUserId,
      gradeLevel: targetGrade,
      updatedAt: new Date().toISOString()
    };

    onSaveHomework(newHw);
    setShowAddForm(false);
    setEditingId(null);
  };

  const handleDelete = (id: string, title: string) => {
    const item = homeworkList.find(h => h.id === id);
    if (!item) return;
    const isAllowedToUpdate = currentGrade === "All Grades" || item.gradeLevel === currentGrade;
    if (!isAllowedToUpdate) {
      alert(`Access Denied: You are signed in as a ${currentGrade} student. You are only permitted to delete assignments belonging to ${currentGrade}.`);
      return;
    }
    if (confirm(`Are you sure you want to delete "${title}"? This will remove it from every student's assignment sheet.`)) {
      onDeleteHomework(id);
    }
  };

  // Filter homework list - restrict specific grade students from accessing other grades
  const visibleHomework = currentGrade === "All Grades"
    ? homeworkList
    : homeworkList.filter((hw) => hw.gradeLevel === currentGrade || hw.gradeLevel === "All Grades");

  const filteredHomework = visibleHomework.filter((hw) => {
    const matchesSearch =
      hw.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hw.courseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (hw.description && hw.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      hw.createdBy.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesGrade = gradeFilter === "All Grades" || hw.gradeLevel === gradeFilter || hw.gradeLevel === "All Grades";

    return matchesSearch && matchesGrade;
  });

  return (
    <div className="space-y-6">
      {/* Banner & Control bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-base font-black text-slate-850 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
            Shared Homework Sheet
          </h2>
          <p className="text-[11px] text-slate-400 mt-1 font-medium leading-relaxed">
            Collaborative academic whiteboard. Assignments added here instantly pop up on the Assignments Hub of all target students.
          </p>
        </div>

        <button
          id="btn-add-homework-trigger"
          onClick={handleOpenAdd}
          className="flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Post New Homework
        </button>
      </div>

      {/* Pop up form (collapsible panel) */}
      {showAddForm && (
        <form
          id="form-add-homework"
          onSubmit={handleSubmit}
          className="p-5 md:p-6 bg-white border-2 border-emerald-100 rounded-2xl shadow-lg space-y-4 animate-fade-in"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" />
              <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">
                {editingId ? "Edit Shared Homework Entry" : "Post A New Shared Homework Assignment"}
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-xs text-slate-400 hover:text-slate-600 font-bold px-2 py-1 rounded-md hover:bg-slate-50 transition"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Title */}
            <div className="space-y-1.5 col-span-1 md:col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Homework Title *
              </label>
              <input
                id="input-homework-title"
                type="text"
                required
                placeholder="e.g. Chapter 4 Integration & Optimization exercise"
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition bg-slate-50/30"
              />
            </div>

            {/* Predefined Course Presets OR custom input */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Select Subject / Class Preset
              </label>
              <div className="flex gap-2">
                <select
                  id="select-course-presets"
                  value={formCourseName}
                  onChange={(e) => handleSelectCoursePreset(e.target.value)}
                  className="flex-1 text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
                >
                  {PREDEFINED_COURSES.map((c) => (
                    <option key={c.name} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                  <option value="">-- Type Custom Class Below --</option>
                </select>
              </div>
            </div>

            {/* Custom Class Name */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Subject Name (Custom)
              </label>
              <input
                id="input-custom-subject"
                type="text"
                placeholder="e.g. Chemistry AP 102"
                value={formCourseName}
                onChange={(e) => setFormCourseName(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition bg-slate-50/30"
              />
            </div>

            {/* Grade level scope */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Target Grade Level Scope *
              </label>
              <select
                id="select-homework-grade"
                value={formGradeLevel}
                onChange={(e) => setFormGradeLevel(e.target.value)}
                disabled={currentGrade !== "All Grades"}
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white disabled:bg-slate-55 disabled:text-slate-500 cursor-not-allowed"
              >
                {currentGrade !== "All Grades" ? (
                  <option value={currentGrade}>{currentGrade} Students (Your Registered Grade)</option>
                ) : (
                  <>
                    <option value="Grade 9">Grade 9 Students</option>
                    <option value="Grade 10">Grade 10 Students</option>
                    <option value="Grade 11">Grade 11 Students</option>
                    <option value="Grade 12">Grade 12 Students</option>
                    <option value="All Grades">All Grades (Global)</option>
                  </>
                )}
              </select>
              {currentGrade !== "All Grades" && (
                <p className="text-[10px] text-indigo-600 font-bold flex items-center gap-1 mt-1">
                  <Lock className="w-3 h-3 shrink-0" />
                  <span>Locked to {currentGrade} scope as registered on roster.</span>
                </p>
              )}
            </div>

            {/* Due date */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Due Date
              </label>
              <input
                id="input-homework-duedate"
                type="date"
                required
                value={formDueDate}
                onChange={(e) => setFormDueDate(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 bg-white"
              />
            </div>

            {/* Max Points */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Max Points / Weight Score
              </label>
              <input
                id="input-homework-points"
                type="number"
                min="0"
                max="1000"
                value={formMaxPoints}
                onChange={(e) => setFormMaxPoints(parseInt(e.target.value) || 0)}
                className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 transition bg-slate-50/30"
              />
            </div>

            {/* Description */}
            <div className="col-span-1 md:col-span-2 space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Detailed Assignment Guidelines & Syllabus coordinates
              </label>
              <textarea
                id="input-homework-desc"
                placeholder="List problems numbers, helpful YouTube links, readings chapter references, or expectations..."
                value={formDesc}
                onChange={(e) => setFormDesc(e.target.value)}
                className="w-full text-xs font-semibold p-2.5 bg-slate-50/30 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-emerald-500 min-h-20"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-50">
            <button
              id="btn-cancel-add-hw"
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-slate-105 hover:bg-slate-200/50 text-slate-700 rounded-xl text-xs font-bold transition"
            >
              Cancel
            </button>
            <button
              id="btn-save-homework"
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition shadow-sm"
            >
              {editingId ? "Update Homework" : "Publish to Board"}
            </button>
          </div>
        </form>
      )}

      {/* Main Filter & Search Grid */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Search */}
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="search-homework-input"
            type="text"
            placeholder="Search homework items, subjects, contributors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-xs pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-emerald-150 transition"
          />
        </div>

        {/* Grade Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 shrink-0">
          {(currentGrade === "All Grades"
            ? ["All Grades", "Grade 9", "Grade 10", "Grade 11", "Grade 12"]
            : ["All Grades", currentGrade])
            .map((grade) => (
              <button
                id={`filter-grade-btn-${grade.replace(" ", "-")}`}
                key={grade}
                onClick={() => setGradeFilter(grade)}
                className={`px-3 py-1.5 text-[11px] font-black rounded-lg transition shrink-0 uppercase tracking-tight ${
                  gradeFilter === grade
                    ? "bg-slate-850 text-white shadow-xs"
                    : "bg-slate-50 hover:bg-slate-100 text-slate-600"
                }`}
              >
                {grade}
              </button>
            ))}
        </div>
      </div>

      {/* Spreadsheet grid of Homework Sheets */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
        {filteredHomework.length === 0 ? (
          <div id="hw-empty-state" className="p-12 text-center flex flex-col items-center justify-center space-y-4">
            <div className="w-14 h-14 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">No Shared Homework Listed For {gradeFilter}</h3>
              <p className="text-xs text-slate-450 max-w-sm leading-relaxed mx-auto">
                No class tasks have been written yet on the communal bulletin. Click "Post New Homework" above to list a homework sheet.
              </p>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full table-auto text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/75 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider">
                  <th className="py-4 px-5">Class / Color</th>
                  <th className="py-4 px-5">Target Scope</th>
                  <th className="py-4 px-5">Homework Task Title</th>
                  <th className="py-4 px-5">Due Date</th>
                  <th className="py-4 px-5 text-center">Max Points</th>
                  <th className="py-4 px-5">Contributor</th>
                  <th className="py-4 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredHomework.map((hw) => {
                  const isCreator = hw.createdById === currentUserId;
                  const dateText = hw.dueDate
                    ? new Date(hw.dueDate).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric"
                      })
                    : "No Due Date";

                  // Color Map
                  const colorBgs: Record<string, string> = {
                    indigo: "bg-indigo-50 text-indigo-700 border-indigo-100",
                    violet: "bg-violet-50 text-violet-700 border-violet-100",
                    rose: "bg-rose-50 text-rose-700 border-rose-100",
                    amber: "bg-amber-50 text-amber-700 border-amber-100",
                    emerald: "bg-emerald-50 text-emerald-700 border-emerald-100",
                    sky: "bg-sky-50 text-sky-700 border-sky-100",
                    teal: "bg-teal-50 text-teal-700 border-teal-100",
                    fuchsia: "bg-fuchsia-50 text-fuchsia-700 border-fuchsia-100",
                    slate: "bg-slate-50 text-slate-700 border-slate-100"
                  };
                  const colorClass = colorBgs[hw.courseColor] || colorBgs["indigo"];

                  return (
                    <tr
                      id={`hw-tr-${hw.id}`}
                      key={hw.id}
                      className="hover:bg-slate-50/50 transition-colors group text-xs font-semibold text-slate-750"
                    >
                      {/* Course */}
                      <td className="py-3.5 px-5 select-none font-bold">
                        <span className={`inline-block py-1 px-2.5 text-[10px] font-black uppercase tracking-wider rounded-lg border ${colorClass}`}>
                          {hw.courseName}
                        </span>
                      </td>

                      {/* Grade Scope */}
                      <td className="py-3.5 px-5">
                        <span className="inline-flex items-center gap-1.5 py-0.5 px-2 bg-slate-100 text-slate-700 rounded-md text-[10px] font-black uppercase tracking-tight">
                          <GraduationCap className="w-3 h-3 text-slate-500" />
                          {hw.gradeLevel}
                        </span>
                      </td>

                      {/* Title & Description preview */}
                      <td className="py-3.5 px-5 max-w-xs md:max-w-sm">
                        <div className="space-y-1">
                          <div className="text-slate-800 font-extrabold text-[12px] leading-snug group-hover:text-emerald-700 transition-colors">
                            {hw.title}
                          </div>
                          {hw.description && (
                            <div className="text-[10px] text-slate-400 font-medium line-clamp-2 leading-relaxed">
                              {hw.description}
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Due */}
                      <td className="py-3.5 px-5 text-slate-500 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-550">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          {dateText}
                        </div>
                      </td>

                      {/* Points */}
                      <td className="py-3.5 px-5 text-center font-black text-slate-800">
                        {hw.maxPoints ? `${hw.maxPoints} pts` : "N/A"}
                      </td>

                      {/* Creator */}
                      <td className="py-3.5 px-5">
                        <div className="flex items-center gap-1.5 text-slate-600">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          <span className="truncate">{hw.createdBy}</span>
                          {isCreator && (
                            <span className="text-[8px] font-extrabold uppercase px-1 py-0.5 bg-indigo-50 text-indigo-600 rounded">You</span>
                          )}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-5 text-right whitespace-nowrap select-none">
                        {(() => {
                          const isAllowedToUpdate = currentGrade === "All Grades" || hw.gradeLevel === currentGrade;
                          if (isAllowedToUpdate) {
                            return (
                              <div className="flex justify-end items-center gap-1.5">
                                <button
                                  id={`btn-hw-edit-${hw.id}`}
                                  onClick={() => handleOpenEdit(hw)}
                                  title="Edit this entry"
                                  className="p-1 px-2 border border-slate-150 bg-white hover:bg-slate-50 text-slate-600 rounded-lg text-[10px] font-black uppercase flex items-center gap-1"
                                >
                                  <Edit3 className="w-3 h-3" />
                                  Edit
                                </button>
                                <button
                                  id={`btn-hw-delete-${hw.id}`}
                                  onClick={() => handleDelete(hw.id, hw.title)}
                                  title="Delete this entry"
                                  className="p-1.5 border border-rose-100 hover:border-rose-200 bg-rose-50 hover:bg-rose-100/50 text-rose-600 rounded-lg"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          } else {
                            return (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-400 bg-slate-100/75 px-2.5 py-1.5 rounded-lg border border-slate-150 select-none">
                                <Lock className="w-3 h-3 text-slate-400" />
                                <span>Read-Only</span>
                              </span>
                            );
                          }
                        })()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Explanation notice details */}
      <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4 flex gap-3 text-slate-500 text-[11px] font-medium leading-relaxed">
        <Clock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5 animate-pulse" />
        <div>
          <span className="font-bold text-slate-800">Communal Sync Engine active:</span> Changing, deleting, or authoring coursework inside this tab will dynamically update the real-time databases and "pop up" immediately on the main <span className="font-bold text-slate-800">Assignments Hub</span> tab of every student registered under that targeted academic grade portfolio.
        </div>
      </div>
    </div>
  );
}
