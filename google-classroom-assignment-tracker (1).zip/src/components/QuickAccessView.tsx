import React, { useState } from "react";
import { Search, ExternalLink, Calendar, BookOpen, Layers, Globe, FileText, BarChart, Presentation, HelpCircle } from "lucide-react";

interface QuickLinkItem {
  id: string;
  title: string;
  url: string;
  category: "schedules" | "academic" | "workspace";
  iconUrl: string;
  description: string;
  accentClass: string;
  badgeText?: string;
}

export default function QuickAccessView() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<"all" | "schedules" | "academic" | "workspace">("all");

  const quickLinks: QuickLinkItem[] = [
    {
      id: "elem-schedule",
      title: "Elementary School Timetable",
      url: "https://docs.google.com/spreadsheets/d/19wr-tQvdn35ebO28m0SWaFyntqWRzl2k9OXUkxpklUM/edit?gid=1653366028#gid=1653366028",
      category: "schedules",
      iconUrl: "https://apps.jpa.org.kh/uploads/icons/682c160e6ff45.png",
      description: "Access the elementary division classroom timetable, sections, and structural hourly rotations.",
      accentClass: "border-emerald-100 hover:border-emerald-300 bg-emerald-50/10 text-emerald-700",
      badgeText: "Elementary"
    },
    {
      id: "hs-schedule",
      title: "High School Timetable",
      url: "https://docs.google.com/spreadsheets/d/1W1Jbc6kOq8OGl1lIJOx0lpwIgFxTgGIqoXa9PJ-i2T0/edit?gid=1819299485#gid=1819299485",
      category: "schedules",
      iconUrl: "https://apps.jpa.org.kh/uploads/icons/682c160e6ff45.png",
      description: "Navigate high school timetable periods, assigned subject locations, and classroom rotations.",
      accentClass: "border-indigo-100 hover:border-indigo-300 bg-indigo-50/10 text-indigo-700",
      badgeText: "High School"
    },
    {
      id: "hs-enrollment",
      title: "High School Enrollment",
      url: "https://www.schoolmint.com",
      category: "academic",
      iconUrl: "https://apps.jpa.org.kh/uploads/icons/682c160e6ff45.png",
      description: "Manage applications, registrar requirements, and enrollment portfolios via SchoolMint portal.",
      accentClass: "border-sky-100 hover:border-sky-300 bg-sky-50/10 text-sky-700",
      badgeText: "SchoolMint"
    },
    {
      id: "hs-tutoring",
      title: "High School Tutoring Schedule",
      url: "https://calendar.google.com",
      category: "schedules",
      iconUrl: "https://apps.jpa.org.kh/uploads/icons/682c160e6ff45.png",
      description: "Coordinate tutoring reservations, student study circles, and peer mentor office hours.",
      accentClass: "border-amber-100 hover:border-amber-300 bg-amber-50/10 text-amber-700",
      badgeText: "Calendar"
    },
    {
      id: "g-drive",
      title: "Google Drive",
      url: "https://drive.google.com",
      category: "workspace",
      iconUrl: "https://www.google.com/s2/favicons?sz=64&domain_url=https://drive.google.com",
      description: "Manage document storages, shared assignments directories, syllabus files, and grade sheets.",
      accentClass: "border-blue-100 hover:border-blue-300 bg-blue-50/10 text-blue-700",
      badgeText: "Drive"
    },
    {
      id: "g-docs",
      title: "Google Docs",
      url: "https://docs.google.com",
      category: "workspace",
      iconUrl: "https://ssl.gstatic.com/docs/doclist/images/mediatype/icon_1_document_x16.png",
      description: "Author assignments, design essay drafts, compose reports, and organize class notes.",
      accentClass: "border-indigo-100 hover:border-indigo-300 bg-indigo-50/10 text-indigo-700",
      badgeText: "Docs"
    },
    {
      id: "g-sheets",
      title: "Google Sheets",
      url: "https://docs.google.com/spreadsheets",
      category: "workspace",
      iconUrl: "https://ssl.gstatic.com/docs/doclist/images/mediatype/icon_1_spreadsheet_x16.png",
      description: "Maintain scorebooks, log tracking sheets, analyze research math, and list schedules.",
      accentClass: "border-emerald-100 hover:border-emerald-300 bg-emerald-50/10 text-emerald-700",
      badgeText: "Sheets"
    },
    {
      id: "g-slides",
      title: "Google Slides",
      url: "https://docs.google.com/presentation",
      category: "workspace",
      iconUrl: "https://ssl.gstatic.com/docs/doclist/images/mediatype/icon_1_presentation_x16.png",
      description: "Design presentation decks, structure classroom lesson materials, and construct reports.",
      accentClass: "border-amber-100 hover:border-amber-300 bg-amber-50/10 text-amber-700",
      badgeText: "Slides"
    },
    {
      id: "student-handbook",
      title: "Student Handbook",
      url: "https://docs.google.com/document/d/17u13-GJ0AiSwX9UB_-twxx9ulSBAnUUzt-3aC-mGFcI/edit?tab=t.0",
      category: "academic",
      iconUrl: "https://apps.jpa.org.kh/uploads/icons/68943c8a39f2e.png",
      description: "Consult community rules, honor code, exam guidelines, and campus dress regulations.",
      accentClass: "border-rose-100 hover:border-rose-300 bg-rose-50/10 text-rose-700",
      badgeText: "Handbook"
    }
  ];

  // Map generic fallback icons in case custom image icons fail
  const getFallbackIcon = (category: string, title?: string) => {
    const t = (title || "").toLowerCase();
    if (t.includes("sheet") || t.includes("timetable")) return <BarChart className="w-5 h-5 text-emerald-500" />;
    if (t.includes("doc") || t.includes("handbook")) return <FileText className="w-5 h-5 text-indigo-500" />;
    if (t.includes("presentation") || t.includes("slide")) return <Presentation className="w-5 h-5 text-amber-500" />;
    if (t.includes("calendar") || t.includes("tutoring")) return <Calendar className="w-5 h-5 text-blue-500" />;
    
    switch (category) {
      case "schedules":
        return <Calendar className="w-5 h-5 text-indigo-500" />;
      case "academic":
        return <BookOpen className="w-5 h-5 text-rose-500" />;
      default:
        return <Globe className="w-5 h-5 text-slate-500" />;
    }
  };

  const filteredLinks = quickLinks.filter((link) => {
    const matchesSearch =
      link.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      link.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      link.url.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = activeCategory === "all" || link.category === activeCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="search-links-input"
            type="text"
            placeholder="Search resources, timetables, or documents..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-xs pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0 shrink-0">
          {(["all", "schedules", "academic", "workspace"] as const).map((cat) => (
            <button
              id={`filter-links-btn-${cat}`}
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition shrink-0 ${
                activeCategory === cat
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-100"
                  : "bg-slate-50 hover:bg-slate-100 text-slate-600"
              }`}
            >
              {cat === "all"
                ? "All Links"
                : cat === "schedules"
                ? "Timetables & Cycles"
                : cat === "academic"
                ? "Admissions & Guidelines"
                : "Workspace Suites"}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid View */}
      {filteredLinks.length === 0 ? (
        <div id="quick-links-empty" className="bg-white rounded-2xl border border-slate-100 p-12 text-center shadow-xs">
          <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400 mb-4">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-sm mb-1">No resource matched</h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Try adjusting your search criteria or switch resource category tabs.
          </p>
        </div>
      ) : (
        <div id="quick-access-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredLinks.map((link) => (
            <a
              id={`quick-link-card-${link.id}`}
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`group bg-white rounded-2xl border ${link.accentClass} p-5 shadow-xs hover:shadow-md hover:scale-[1.01] transition-all duration-200 flex flex-col justify-between`}
            >
              <div className="space-y-3.5">
                {/* Header: Icon & Category badge */}
                <div className="flex items-center justify-between">
                  <div className="w-11 h-11 bg-slate-50 rounded-xl flex items-center justify-center border border-slate-100 relative overflow-hidden p-2 group-hover:bg-white transition-colors duration-150">
                    <img
                      src={link.iconUrl}
                      alt={link.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain object-center z-10"
                      onError={(e) => {
                        // If icon fails to load, gracefully hide img and show fallback
                        e.currentTarget.style.display = "none";
                      }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-slate-50 select-none group-hover:bg-white transition-colors duration-150">
                      {getFallbackIcon(link.category, link.title)}
                    </div>
                  </div>

                  {link.badgeText && (
                    <span className="text-[10px] font-extrabold tracking-wider uppercase text-slate-400 group-hover:text-indigo-600 transition-colors duration-150 px-2 py-1 bg-slate-50 rounded-lg">
                      {link.badgeText}
                    </span>
                  )}
                </div>

                {/* Info Text */}
                <div>
                  <h4 className="font-extrabold text-slate-800 text-xs md:text-sm leading-tight flex items-center gap-1.5 group-hover:text-indigo-600 transition">
                    {link.title}
                  </h4>
                  <p className="text-[11px] text-slate-450 font-medium leading-relaxed mt-2 line-clamp-3">
                    {link.description}
                  </p>
                </div>
              </div>

              {/* Bottom anchor row */}
              <div className="flex items-center justify-between border-t border-slate-50 pt-4 mt-4 text-[10px] font-black tracking-wider uppercase text-slate-400 group-hover:text-indigo-600 transition-colors duration-150">
                <span>Navigate Portal</span>
                <ExternalLink className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
