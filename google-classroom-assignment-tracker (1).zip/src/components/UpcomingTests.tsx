import React, { useState, useEffect } from "react";
import { CalendarClock, Plus, FileText, CalendarDays, X, Trash2 } from "lucide-react";

interface TestItem {
  id: string;
  title: string;
  course: string;
  grade: string;
  date: string;
  creator: string;
}

export default function UpcomingTests({ 
  currentUser,
  onAddTestNotification
}: { 
  currentUser: any;
  onAddTestNotification?: (test: TestItem, creatorRole: string) => void;
}) {
  const [tests, setTests] = useState<TestItem[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTest, setNewTest] = useState({ title: "", course: "", grade: currentUser?.grade || "Grade 9", date: "" });
  const [confirmingDeleteId, setConfirmingDeleteId] = useState<string | null>(null);

  const isTeacher = currentUser?.role === "teacher" || currentUser?.role === "admin";
  const userGrade = currentUser?.grade;

  const handleConfirmDelete = (id: string) => {
    const updated = tests.filter(test => test.id !== id);
    setTests(updated);
    localStorage.setItem("upcoming_tests", JSON.stringify(updated));
    setConfirmingDeleteId(null);
  };

  useEffect(() => {
    // Reset grade if user changes (e.g. login/logout)
    setNewTest(prev => ({ ...prev, grade: currentUser?.grade || "Grade 9" }));
    
    const saved = localStorage.getItem("upcoming_tests");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const migrated = parsed.map((t: any) => {
          if (t.creator === "But Sreyoun") {
            return { ...t, creator: "Chheng Yorng Chhieng" };
          }
          return t;
        });
        setTests(migrated);
      } catch (err) {
        setTests([]);
      }
    } else {
      const defaultTests: TestItem[] = [
        {
          id: "test-apcsa-1",
          title: "Unit 5: Polymorphism & Inheritance Exam",
          course: "AP CSA",
          grade: "Grade 11",
          date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Chheng Yorng Chhieng"
        },
        {
          id: "test-apcalc-1",
          title: "Unit 4: Optimization & Related Rates Test",
          course: "AP Calculus AB",
          grade: "Grade 12",
          date: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Hang Sokcha"
        },
        {
          id: "test-lit-1",
          title: "Oedipus Rex Plot Construction Assessment",
          course: "World Literature & Composition",
          grade: "Grade 9",
          date: new Date(Date.now() + 1.5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Walker Hedgepath"
        },
        {
          id: "test-bio-1",
          title: "Photosynthesis & Cellular Processes Quiz",
          course: "AP Biology",
          grade: "Grade 10",
          date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          creator: "Helga Joshua"
        }
      ];
      setTests(defaultTests);
      localStorage.setItem("upcoming_tests", JSON.stringify(defaultTests));
    }
  }, [currentUser]);

  const handleAddTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTest.title || !newTest.course || !newTest.date) return;
    
    const newItem: TestItem = {
      id: Math.random().toString(36).substr(2, 9),
      title: newTest.title,
      course: newTest.course,
      grade: newTest.grade,
      date: newTest.date,
      creator: currentUser?.displayName || currentUser?.userName || "User",
    };
    
    const updated = [...tests, newItem];
    setTests(updated);
    localStorage.setItem("upcoming_tests", JSON.stringify(updated));

    if (onAddTestNotification) {
      const creatorRole = isTeacher ? "teacher" : "student";
      onAddTestNotification(newItem, creatorRole);
    }

    setShowAddForm(false);
    setNewTest({ title: "", course: "", grade: currentUser?.grade || "Grade 9", date: "" });
  };

  const filteredTests = tests.filter(test => {
    if (isTeacher) return true;
    if (userGrade) return test.grade === userGrade;
    return false;
  }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm flex flex-col overflow-hidden max-h-[800px] transition-all hover:shadow-md">
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/30 shrink-0">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
          <CalendarClock className="w-5 h-5 text-indigo-500" />
          Upcoming Tests
        </h3>
        {currentUser && (
           <button 
              onClick={() => setShowAddForm(true)}
              className="p-1.5 text-[10px] bg-indigo-50 text-indigo-600 font-extrabold uppercase tracking-tight rounded-lg hover:bg-indigo-100 transition-colors flex items-center gap-1 shadow-xs"
              title="Post Upcoming Test"
            >
             <Plus className="w-3.5 h-3.5" />
             POST
           </button>
        )}
      </div>

      <div className="p-4 space-y-4 flex-1 overflow-y-auto relative">
        {showAddForm ? (
          <form onSubmit={handleAddTest} className="bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-sm space-y-3 mb-2 animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">New Test Reminder</h4>
              <button type="button" onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <input 
              required
              placeholder="Test Title (e.g. Midterm)"
              value={newTest.title}
              onChange={(e) => setNewTest({...newTest, title: e.target.value})}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-100 placeholder:text-slate-400"
            />
            
            <div className="grid grid-cols-2 gap-2">
              <input 
                required
                placeholder="Course"
                value={newTest.course}
                onChange={(e) => setNewTest({...newTest, course: e.target.value})}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-100 placeholder:text-slate-400"
              />
              <select
                value={newTest.grade}
                disabled={!isTeacher}
                onChange={(e) => setNewTest({...newTest, grade: e.target.value})}
                className={`w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-100 bg-white ${!isTeacher ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                <option value="Grade 5">Grade 5</option>
                <option value="Grade 6">Grade 6</option>
                <option value="Grade 7">Grade 7</option>
                <option value="Grade 8">Grade 8</option>
                <option value="Grade 9">Grade 9</option>
                <option value="Grade 10">Grade 10</option>
                <option value="Grade 11">Grade 11</option>
                <option value="Grade 12">Grade 12</option>
              </select>
            </div>
            
            <input 
              required
              type="date"
              value={newTest.date}
              onChange={(e) => setNewTest({...newTest, date: e.target.value})}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-100"
            />
            
            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2.5 rounded-lg transition-all shadow-md active:scale-95">
              Confirm Post
            </button>
          </form>
        ) : null}

        {filteredTests.map(test => {
          const isConfirming = confirmingDeleteId === test.id;
          return (
            <div key={test.id} className="p-3.5 bg-white border border-slate-100 rounded-xl relative hover:border-indigo-200 transition-all shadow-xs group overflow-hidden">
              {/* 2-Step Verification Overlay */}
              {isConfirming && (
                <div className="absolute inset-0 bg-white/95 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center p-3 text-center animate-in fade-in zoom-in-95 duration-150">
                  <span className="text-[11px] font-extrabold text-rose-600 uppercase tracking-wider mb-2 flex items-center gap-1">
                    ⚠️ Delete this test?
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleConfirmDelete(test.id)}
                      className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-lg text-[10px] uppercase tracking-wider transition-all cursor-pointer shadow-xs"
                    >
                      Yes, Delete
                    </button>
                    <button
                      onClick={() => setConfirmingDeleteId(null)}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 font-extrabold rounded-lg text-[10px] uppercase tracking-wider transition-all cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-all flex items-center gap-1.5 duration-150">
                <button
                  onClick={() => setConfirmingDeleteId(test.id)}
                  title="Remove test"
                  className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse shrink-0" />
              </div>
              
              <h4 className="font-bold text-slate-800 text-sm mb-2 pr-6 group-hover:text-indigo-600 transition-colors break-words">{test.title}</h4>
              <div className="flex flex-col gap-2 text-xs text-slate-500">
                <span className="flex items-center gap-2 font-semibold">
                    <FileText className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-slate-700">{test.course}</span>
                    <span className="px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded text-[9px] uppercase font-bold tracking-tight">{test.grade}</span>
                </span>
                <span className="flex items-center gap-2 font-bold">
                    <CalendarDays className="w-3.5 h-3.5 text-rose-400" />
                    <span className="text-rose-600 px-2 py-0.5 bg-rose-50 rounded-lg">{test.date}</span>
                </span>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-50 flex justify-between items-center text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                <span>By {test.creator}</span>
              </div>
            </div>
          );
        })}

        {!showAddForm && filteredTests.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mb-3">
              <CalendarClock className="w-6 h-6 text-slate-200" />
            </div>
            <p className="text-slate-400 text-xs font-semibold">No upcoming tests</p>
            <p className="text-slate-300 text-[10px] mt-1 italic">Click POST to add one</p>
          </div>
        )}
      </div>
    </div>
  )
}
