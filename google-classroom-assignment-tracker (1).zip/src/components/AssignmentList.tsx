import React, { useState } from "react";
import { Search, Filter, BookOpen, Layers, CheckCircle2, AlertTriangle, ListFilter, ClipboardCheck } from "lucide-react";
import { Course, UnifiedAssignment } from "../types";
import AssignmentCard from "./AssignmentCard";

interface AssignmentListProps {
  assignments: UnifiedAssignment[];
  courses: Course[];
  isLiveMode: boolean;
  onTurnIn?: (id: string) => void;
}

export default function AssignmentList({
  assignments,
  courses,
  isLiveMode,
  onTurnIn,
}: AssignmentListProps) {
  const [selectedCourse, setSelectedCourse] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("assigned");
  // Filter calculations
  const filteredAssignments = assignments
    .filter((a) => {
      const matchCourse = selectedCourse === "all" || a.courseId === selectedCourse;
      const matchStatus = selectedStatus === "all" || a.state === selectedStatus;
      return matchCourse && matchStatus;
    })
    .sort((a, b) => {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate.getTime() - b.dueDate.getTime();
    });

  // Calculate stats for overview tags
  const statusCounts = {
    all: assignments.length,
    assigned: assignments.filter((a) => a.state === "assigned").length,
    submitted: assignments.filter((a) => a.state === "submitted").length,
    missing: assignments.filter((a) => a.state === "missing").length,
    graded: assignments.filter((a) => a.state === "graded").length,
  };

  return (
    <div className="space-y-6">
      {/* Classroom Quick Select Bubble Ribbon */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
          <BookOpen className="w-3.5 h-3.5 text-indigo-500" />
          Filter by Class
        </h3>
        <div id="classroom-ribbon" className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            id="filter-class-all"
            onClick={() => setSelectedCourse("all")}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold border shrink-0 transition flex items-center gap-2 shadow-xs ${
              selectedCourse === "all"
                ? "bg-indigo-600 text-white border-indigo-600 font-extrabold"
                : "bg-white text-slate-600 border-slate-150 hover:bg-slate-50 hover:text-slate-800"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            All Classrooms
          </button>
          {courses.map((course) => (
            <button
              id={`filter-class-${course.id}`}
              key={course.id}
              onClick={() => setSelectedCourse(course.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold border shrink-0 transition flex items-center gap-2 shadow-xs ${
                selectedCourse === course.id
                  ? "bg-slate-800 text-white border-slate-800 font-extrabold"
                  : "bg-white text-slate-600 border-slate-150 hover:bg-slate-50 hover:text-slate-800"
              }`}
            >
              <div className={`w-2.5 h-2.5 rounded-full bg-${course.color || "indigo"}-500 shrink-0`} />
              {course.name}
            </button>
          ))}
        </div>
      </div>

      {/* Status Segment Switcher Tabs */}
      <div className="flex items-center border-b border-slate-100 pb-px">
        <button
          id="tab-status-assigned"
          onClick={() => setSelectedStatus("assigned")}
          className={`px-4 py-3.5 -mb-px text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            selectedStatus === "assigned"
              ? "border-indigo-600 text-indigo-600 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-200"
          }`}
        >
          Assigned
          <span className="bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold">
            {statusCounts.assigned}
          </span>
        </button>
        <button
          id="tab-status-submitted"
          onClick={() => setSelectedStatus("submitted")}
          className={`px-4 py-3.5 -mb-px text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            selectedStatus === "submitted"
              ? "border-blue-600 text-blue-600 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-200"
          }`}
        >
          Turned In
          <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold">
            {statusCounts.submitted}
          </span>
        </button>
        <button
          id="tab-status-missing"
          onClick={() => setSelectedStatus("missing")}
          className={`px-4 py-3.5 -mb-px text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            selectedStatus === "missing"
              ? "border-rose-600 text-rose-600 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-200"
          }`}
        >
          Missing
          <span className="bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold">
            {statusCounts.missing}
          </span>
        </button>
        <button
          id="tab-status-graded"
          onClick={() => setSelectedStatus("graded")}
          className={`px-4 py-3.5 -mb-px text-xs font-bold border-b-2 transition flex items-center gap-2 ${
            selectedStatus === "graded"
              ? "border-emerald-600 text-emerald-600 font-extrabold"
              : "border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-200"
          }`}
        >
          Graded
          <span className="bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded-md text-[10px] font-bold">
            {statusCounts.graded}
          </span>
        </button>
      </div>

      {/* Main Assignment Coursework Block */}
      <div id="assignment-grid" className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAssignments.length > 0 ? (
          filteredAssignments.map((assignment) => (
            <AssignmentCard
              key={assignment.id}
              assignment={assignment}
              isLiveMode={isLiveMode}
              onTurnIn={onTurnIn}
            />
          ))
        ) : (
          <div className="col-span-1 md:col-span-2 bg-slate-50 border border-dashed border-slate-200 rounded-2xl py-16 px-4 text-center">
            <ClipboardCheck className="w-12 h-12 text-slate-350 mx-auto mb-3" />
            <h4 id="empty-state-title" className="font-bold text-slate-700 text-sm md:text-base">No Assignments Found</h4>
            <p id="empty-state-subtitle" className="text-slate-500 text-xs mt-1 max-w-sm mx-auto leading-relaxed">
              We couldn't find any coursework matching your search filter options. Try selecting another course category, or reset the filters.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
