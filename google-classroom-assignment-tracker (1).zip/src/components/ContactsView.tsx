import React, { useState, useMemo } from "react";
import {
  Search,
  Mail,
  Phone,
  RefreshCw,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  GraduationCap,
} from "lucide-react";
import { Contact } from "../types";
import { studentsList, StudentUser, updatePersistedStudents } from "../studentsData";
import {
  Plus,
  Trash2,
  UserPlus,
  X,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

const getTeacherBadge = (title: string = "") => {
  const t = title.toLowerCase();
  
  if (t.includes("director")) {
    return { label: "Director", classes: "text-red-700 bg-red-50 border-red-100" };
  }
  if (t.includes("manager") || t.includes("controller") || t.includes("accounting") || t.includes("admin")) {
    return { label: "Admin", classes: "text-orange-700 bg-orange-50 border-orange-100" };
  }
  if (t.includes("advisor") || t.includes("services")) {
    return { label: "Staff", classes: "text-slate-700 bg-slate-50 border-slate-100" };
  }
  if (t.includes("support") || t.includes("it ")) {
    return { label: "IT Support", classes: "text-slate-700 bg-slate-50 border-slate-100" };
  }
  if (t.includes("intern")) {
    return { label: "Intern", classes: "text-purple-700 bg-purple-50 border-purple-100" };
  }
  if (t.includes("assistant")) {
    return { label: "Assistant", classes: "text-blue-700 bg-blue-50 border-blue-100" };
  }
  if (t.includes("coordinator")) {
    return { label: "Coordinator", classes: "text-emerald-700 bg-emerald-50 border-emerald-100" };
  }
  if (t.includes("lead") || t.includes("teacher") || t.includes("homeroom")) {
    return { label: "Teacher", classes: "text-amber-700 bg-amber-50 border-amber-100" };
  }
  if (t.includes("librarian")) {
    return { label: "Librarian", classes: "text-rose-700 bg-rose-50 border-rose-100" };
  }
  if (t.includes("coach") || t.includes("pe ")) {
    return { label: "Coach", classes: "text-teal-700 bg-teal-50 border-teal-100" };
  }
  return { label: "Teacher", classes: "text-amber-700 bg-amber-50 border-amber-100" };
};

interface CourseGroup {
  id: string;
  name: string;
  email: string;
  studentCount: number;
  students: { name: string; email: string }[];
}

interface ContactsViewProps {
  contacts: Contact[];
  isSyncing: boolean;
  onRefresh: () => void;
  currentUser?: { displayName: string; role: string; [key: string]: any } | null;
}

function CourseGroupCard({
  group,
  isTeacher,
  allStudents,
  onRemoveStudentFromCourse,
  onAddStudentToCourse,
}: {
  group: CourseGroup;
  isTeacher: boolean;
  allStudents: StudentUser[];
  onRemoveStudentFromCourse?: (studentName: string, courseName: string) => void;
  onAddStudentToCourse?: (studentName: string, courseName: string) => void;
  key?: string;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [studentToUnenroll, setStudentToUnenroll] = useState<string | null>(null);
  const [studentToEnroll, setStudentToEnroll] = useState<string | null>(null);

  const handleCopy = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(group.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const recipientEmails = group.students.map((s) => s.email).join(",");
  const mailtoString = `mailto:${recipientEmails}?subject=${encodeURIComponent(
    `[JPA] Course Notice: ${group.name}`
  )}`;

  // Find eligible students for enrollment
  const enrolledStudentNames = useMemo(() => new Set(group.students.map((s) => s.name.toLowerCase())), [group.students]);
  const eligibleStudents = useMemo(() => allStudents.filter((s) => !enrolledStudentNames.has(s.name.toLowerCase())), [allStudents, enrolledStudentNames]);

  return (
    <div
      id={`course-card-${group.id}`}
      className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs hover:shadow-md hover:border-slate-200 transition duration-250 flex flex-col justify-between"
    >
      <div>
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shadow-inner shrink-0">
              <BookOpen className="w-5 h-5 text-indigo-600" />
            </div>
            <div className="min-w-0">
              <h4 className="font-bold text-slate-800 text-xs truncate max-w-[130px] sm:max-w-none" title={group.name}>
                {group.name}
              </h4>
              <span className="inline-flex text-[9px] font-black tracking-wider uppercase text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded-md shrink-0 border border-indigo-100 mt-1">
                Class Group
              </span>
            </div>
          </div>
          <span className="text-[10px] font-extrabold text-slate-400 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-100 shrink-0">
            {group.studentCount} students
          </span>
        </div>

        {/* Email Field with copy trigger */}
        <div className="mt-4 bg-slate-50 border border-slate-150 rounded-xl p-2.5 flex items-center justify-between gap-2">
          <div className="min-w-0 flex items-center gap-2">
            <Mail className="w-3.5 h-3.5 text-slate-450 shrink-0" />
            <span className="text-[11px] font-mono text-slate-600 font-medium truncate" title={group.email}>
              {group.email}
            </span>
          </div>
          <button
            onClick={handleCopy}
            className="p-1.5 bg-white hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg border border-slate-200 transition flex items-center justify-center cursor-pointer shrink-0"
            title="Copy Group Email"
          >
            {copied ? (
              <Check className="w-3 h-3 text-emerald-500" />
            ) : (
              <Copy className="w-3 h-3 text-slate-500" />
            )}
          </button>
        </div>

        {/* Expandable student roster */}
        <div className="mt-4 border-t border-slate-100 pt-3">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="w-full flex items-center justify-between py-1 text-[11px] font-extrabold text-slate-500 hover:text-slate-850 cursor-pointer text-left transition"
          >
            <span className="flex items-center gap-1">
              <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
              {isOpen ? "Hide Student Roster" : "View Student Roster"}
            </span>
            {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {isOpen && (
            <div className="mt-2.5 max-h-48 overflow-y-auto border border-slate-100 rounded-xl bg-slate-50/50 p-2.5 divide-y divide-slate-100/70">
              {group.students.length === 0 ? (
                <div className="py-3 text-center text-[10px] text-slate-400 font-medium">
                  No students currently enrolled
                </div>
              ) : (
                group.students.map((student, idx) => (
                  <div key={idx} className="py-1.5 flex items-center justify-between gap-2.5 first:pt-0 last:pb-0">
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] font-bold text-slate-700 block truncate">{student.name}</span>
                      <span className="text-[9px] font-mono text-slate-400 select-all truncate block">{student.email}</span>
                    </div>
                    {studentToUnenroll === student.name ? (
                      <div className="flex items-center gap-1 shrink-0 animate-fadeIn bg-red-50 p-1 rounded-lg border border-red-100">
                        <span className="text-[9px] font-bold text-red-750">Remove?</span>
                        <button
                          id={`unenroll-confirm-${student.name.replace(/\s+/g, "-").toLowerCase()}`}
                          onClick={() => {
                            onRemoveStudentFromCourse?.(student.name, group.name);
                            setStudentToUnenroll(null);
                          }}
                          className="px-1.5 py-0.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-[8px] rounded-md transition cursor-pointer"
                        >
                          Yes
                        </button>
                        <button
                          id={`unenroll-cancel-${student.name.replace(/\s+/g, "-").toLowerCase()}`}
                          onClick={() => setStudentToUnenroll(null)}
                          className="px-1.5 py-0.5 bg-white hover:bg-slate-100 text-slate-600 font-extrabold text-[8px] rounded-md border border-slate-205 transition cursor-pointer"
                        >
                          No
                        </button>
                      </div>
                    ) : (
                      isTeacher && onRemoveStudentFromCourse && (
                        <button
                          id={`unenroll-btn-${student.name.replace(/\s+/g, "-").toLowerCase()}`}
                          onClick={() => setStudentToUnenroll(student.name)}
                          className="p-1 hover:bg-red-50 text-red-550 hover:text-red-700 rounded-lg transition shrink-0 cursor-pointer"
                          title={`Remove ${student.name} from ${group.name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {isOpen && isTeacher && (
            <div className="mt-3 pt-2 border-t border-slate-100 flex flex-col gap-1.5 animate-fadeIn">
              <span className="text-[8px] font-black tracking-widest text-slate-400 uppercase">
                Enroll Student in Class
              </span>
              
              {studentToEnroll ? (
                <div className="bg-indigo-50/70 border border-indigo-150 rounded-xl p-2.5 flex flex-col gap-2 animate-fadeIn text-[10px]">
                  <p className="font-semibold text-slate-700">
                    Enroll <span className="font-extrabold text-indigo-700">{studentToEnroll}</span> into {group.name}?
                  </p>
                  <div className="flex items-center gap-1.5">
                    <button
                      id={`enroll-confirm-${studentToEnroll.replace(/\s+/g, "-").toLowerCase()}`}
                      onClick={() => {
                        onAddStudentToCourse?.(studentToEnroll, group.name);
                        setStudentToEnroll(null);
                      }}
                      className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 font-extrabold text-[9px] text-white rounded-lg cursor-pointer transition shrink-0 shadow-sm"
                    >
                      Confirm
                    </button>
                    <button
                      id={`enroll-cancel-${studentToEnroll.replace(/\s+/g, "-").toLowerCase()}`}
                      onClick={() => setStudentToEnroll(null)}
                      className="px-2.5 py-1 bg-white hover:bg-slate-100 font-bold text-[9px] text-slate-600 rounded-lg border border-slate-250 cursor-pointer transition shrink-0"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : eligibleStudents.length > 0 && onAddStudentToCourse ? (
                <select
                  id={`enroll-select-${group.id}`}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val) {
                      setStudentToEnroll(val);
                      e.target.value = "";
                    }
                  }}
                  defaultValue=""
                  className="w-full bg-white border border-slate-200 rounded-lg py-1.5 px-2 text-[10px] font-semibold text-slate-700 focus:outline-hidden transition cursor-pointer"
                >
                  <option value="">+ Choose Student...</option>
                  {eligibleStudents.sort((a,b) => a.name.localeCompare(b.name)).map(s => (
                    <option key={s.name} value={s.name}>{s.name} ({s.grade})</option>
                  ))}
                </select>
              ) : (
                <div className="text-[9px] text-slate-400 font-medium italic">
                  All active roster students are currently enrolled
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-slate-50 pt-4 mt-4">
        <a
          id={`mailto-link-${group.id}`}
          href={mailtoString}
          className="w-full flex items-center justify-center gap-2 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-xs text-white font-bold rounded-xl transition duration-200 shadow-sm hover:shadow-md cursor-pointer"
        >
          <Mail className="w-3.5 h-3.5" />
          Email Class
        </a>
      </div>
    </div>
  );
}

export default function ContactsView({
  contacts,
  isSyncing,
  onRefresh,
  currentUser,
}: ContactsViewProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState<"all" | "teacher" | "students" | "courses" | "other">("all");
  const [students, setStudents] = useState<StudentUser[]>(() => [...studentsList]);
  
  // Add Student modal/riddle state
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
  const [newStudent, setNewStudent] = useState({
    firstName: "",
    lastName: "",
    gender: "F" as "F" | "M",
    grade: "Grade 9",
    english: "",
    math: "",
    science: "",
    socialStudies: "",
    other: "",
  });
  const [passwordHint, setPasswordHint] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const [showSuccessToast, setShowSuccessToast] = useState<string | null>(null);
  const [confirmDeleteName, setConfirmDeleteName] = useState<string | null>(null);

  const isTeacher = currentUser?.role === "teacher" || currentUser?.role === "admin";

  const generatePassword = () => {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let pwd = "";
    for (let i = 0; i < 8; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pwd;
  };

  const handleAddStudent = (student: StudentUser) => {
    const updated = [...students, student];
    setStudents(updated);
    updatePersistedStudents(updated);
  };

  const handleRemoveStudentFromCourse = (studentName: string, courseName: string) => {
    const updated = students.map((s) => {
      if (s.name !== studentName) return s;
      const copy = { ...s, schedule: { ...s.schedule } };
      if (copy.schedule.english === courseName) copy.schedule.english = "";
      if (copy.schedule.math === courseName) copy.schedule.math = "";
      if (copy.schedule.science === courseName) copy.schedule.science = "";
      if (copy.schedule.socialStudies === courseName) copy.schedule.socialStudies = "";
      if (copy.schedule.other === courseName) copy.schedule.other = "";
      return copy;
    });
    setStudents(updated);
    updatePersistedStudents(updated);
  };

  const handleAddStudentToCourse = (studentName: string, courseName: string) => {
    const updated = students.map((s) => {
      if (s.name !== studentName) return s;
      const copy = { ...s, schedule: { ...s.schedule } };
      if (!copy.schedule.english) copy.schedule.english = courseName;
      else if (!copy.schedule.math) copy.schedule.math = courseName;
      else if (!copy.schedule.science) copy.schedule.science = courseName;
      else if (!copy.schedule.socialStudies) copy.schedule.socialStudies = courseName;
      else copy.schedule.other = courseName;
      return copy;
    });
    setStudents(updated);
    updatePersistedStudents(updated);
  };

  // 1. Filtered General Contacts (Teachers and Google Contacts)
  const filteredContacts = useMemo(() => {
    return contacts.filter((c) => {
      const matchesSearch =
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (c.email && c.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (c.phone && c.phone.includes(searchTerm));

      const matchesFilter = activeFilter === "all" || c.role === activeFilter;

      return matchesSearch && matchesFilter;
    });
  }, [contacts, searchTerm, activeFilter]);

  // 2. Extracted and Filtered course group emails
  const courseGroups = useMemo(() => {
    const courseMap = new Map<string, { name: string; students: { name: string; email: string }[] }>();

    students.forEach((student) => {
      // Create student email in standard JPA format
      const firstName = student.firstName || student.name.split(" ")[0] || "student";
      const lastName = student.lastName || student.name.split(" ").slice(1).join("") || "";
      const cleanFirst = firstName.toLowerCase().replace(/[^a-z0-9]/g, "");
      const cleanLast = lastName.toLowerCase().replace(/[^a-z0-9]/g, "");
      const email = `${cleanFirst}${cleanLast}@jpa.org.kh`;

      const schedules = [
        student.schedule.english,
        student.schedule.math,
        student.schedule.science,
        student.schedule.socialStudies,
        student.schedule.other,
      ];

      schedules.forEach((course) => {
        if (!course || !course.trim()) return;
        const trimmedCourse = course.trim();
        const lowerKey = trimmedCourse.toLowerCase();

        if (!courseMap.has(lowerKey)) {
          courseMap.set(lowerKey, {
            name: trimmedCourse,
            students: [],
          });
        }
        
        const courseObj = courseMap.get(lowerKey)!;
        if (!courseObj.students.some((s) => s.email === email)) {
          courseObj.students.push({
            name: student.name,
            email: email,
          });
        }
      });
    });

    return Array.from(courseMap.entries())
      .map(([key, value]) => {
        const cleanPrefix = value.name.toLowerCase().replace(/[^a-z0-9]/g, "");
        return {
          id: `course-group-${cleanPrefix}`,
          name: value.name,
          email: `${cleanPrefix}@jpa.org.kh`,
          role: "course" as const,
          studentCount: value.students.length,
          students: value.students,
        };
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [students]);

  const filteredCourseGroups = useMemo(() => {
    if (activeFilter !== "all" && activeFilter !== "courses") return [];

    return courseGroups.filter((cg) => {
      const matchesSearch =
        cg.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cg.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        cg.students.some((st) => st.name.toLowerCase().includes(searchTerm.toLowerCase()));

      return matchesSearch;
    });
  }, [courseGroups, searchTerm, activeFilter]);

  const filteredStudents = useMemo(() => {
    if (activeFilter !== "all" && activeFilter !== "students") return [];
    
    return students.filter((s) => {
      const firstName = s.firstName || s.name.split(" ")[0] || "student";
      const lastName = s.lastName || s.name.split(" ").slice(1).join("") || "";
      const cleanFirst = firstName.toLowerCase().replace(/[^a-z0-9]/g, "");
      const cleanLast = lastName.toLowerCase().replace(/[^a-z0-9]/g, "");
      const email = `${cleanFirst}${cleanLast}@jpa.org.kh`;

      const matchesSearch =
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.grade.toLowerCase().includes(searchTerm.toLowerCase()) ||
        [
          s.schedule?.english,
          s.schedule?.math,
          s.schedule?.science,
          s.schedule?.socialStudies,
          s.schedule?.other,
        ].some((c) => c && c.toLowerCase().includes(searchTerm.toLowerCase()));

      return matchesSearch;
    });
  }, [students, searchTerm, activeFilter]);

  return (
    <div className="space-y-6">
      {/* Search and Filters Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="search-contacts-input"
            type="text"
            placeholder="Search contacts, courses, or class students..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-xs pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 xl:pb-0 shrink-0">
          {(["all", "teacher", "students", "courses", "other"] as const).map((filter) => (
            <button
              id={`filter-contacts-btn-${filter}`}
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition shrink-0 cursor-pointer ${
                activeFilter === filter
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-100"
                  : "bg-slate-50 hover:bg-slate-100 text-slate-600"
              }`}
            >
              {filter === "all"
                ? "All Directory"
                : filter === "teacher"
                ? "Teachers"
                : filter === "students"
                ? "Student Roster"
                : filter === "courses"
                ? "Course Groups"
                : "Google Contacts"}
            </button>
          ))}

          <button
            id="btn-sync-contacts"
            onClick={onRefresh}
            disabled={isSyncing}
            className="p-2.5 bg-slate-50 hover:bg-slate-100 scroll-p-2 rounded-xl border border-slate-200 text-slate-600 transition flex items-center justify-center shrink-0 disabled:opacity-50 cursor-pointer"
            title="Sync Contacts"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? "animate-spin text-indigo-500" : ""}`} />
          </button>
        </div>
      </div>

      {/* Grid or Empty State rendering */}
      {filteredContacts.length === 0 && filteredCourseGroups.length === 0 && filteredStudents.length === 0 ? (
        <div id="contacts-empty-state" className="bg-white rounded-2xl border border-slate-100 p-12 text-center shadow-xs">
          <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400 mb-4">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-sm mb-1">No contacts, courses, or students found</h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto">
            Try adjusting your search criteria or change the directory filters.
          </p>
        </div>
      ) : (
        <div className="space-y-8 animate-fadeIn">
          {/* Section: Student Roster Option Bar */}
          {activeFilter === "students" && isTeacher && (
            <div className="flex justify-end mb-2">
              <button
                id="btn-add-student-roster"
                onClick={() => {
                  setFormError(null);
                  setPasswordHint(generatePassword());
                  setIsAddMenuOpen(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-100 transition cursor-pointer animate-fadeIn"
              >
                <Plus className="w-4 h-4" />
                Add New Student
              </button>
            </div>
          )}

          {/* Section: Student Roster Cards */}
          {filteredStudents.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                  Student Roster ({filteredStudents.length})
                </h3>
                <div className="flex-1 h-px bg-slate-100"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 animate-fadeIn">
                {filteredStudents.map((student) => {
                  const firstName = student.firstName || student.name.split(" ")[0] || "Student";
                  const lastName = student.lastName || student.name.split(" ").slice(1).join("") || "";
                  const cleanFirst = firstName.toLowerCase().replace(/[^a-z0-9]/g, "");
                  const cleanLast = lastName.toLowerCase().replace(/[^a-z0-9]/g, "");
                  const email = `${cleanFirst}${cleanLast}@jpa.org.kh`;
                  const isConfirming = confirmDeleteName === student.name;

                  return (
                    <div
                      id={`student-card-${student.name.replace(/\s+/g, "-").toLowerCase()}`}
                      key={student.name}
                      className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs hover:shadow-md hover:border-slate-200 transition duration-250 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 rounded-full flex items-center justify-center font-extrabold shadow-inner bg-indigo-50 text-indigo-600 shrink-0">
                            {student.name.charAt(0).toUpperCase()}
                          </div>
                          
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h4 className="font-bold text-slate-800 text-xs truncate max-w-[130px] sm:max-w-none" title={student.name}>
                                {student.name}
                              </h4>
                              <span className="text-[9px] font-black tracking-wider uppercase px-1.5 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-100">
                                {student.grade}
                              </span>
                            </div>
                            
                            <p className="text-[11px] text-slate-500 font-medium truncate mt-1 flex items-center gap-1">
                              <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                              <span className="truncate">{email}</span>
                            </p>
                            
                            <div className="mt-2 text-[10px] flex items-center gap-2 flex-wrap">
                              <span className="text-[9px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100">
                                {student.gender === "M" ? "Male" : "Female"}
                              </span>
                              <span className="text-[9px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100">
                                Pass: <code className="font-mono bg-slate-100 px-1 py-0.2 rounded" title="Student Password">{student.password}</code>
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-4 pt-3 border-t border-slate-100">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block mb-2">
                            Class Schedule
                          </span>
                          <div className="grid grid-cols-2 gap-1.5 text-[9px]">
                            {student.schedule.english && (
                              <div className="bg-slate-50/50 border border-slate-100 rounded-lg p-1.5 px-2 truncate" title={`English: ${student.schedule.english}`}>
                                <span className="text-slate-400 font-bold block text-[8px] uppercase">English</span>
                                <span className="text-slate-600 font-semibold truncate block">{student.schedule.english}</span>
                              </div>
                            )}
                            {student.schedule.math && (
                              <div className="bg-slate-50/50 border border-slate-100 rounded-lg p-1.5 px-2 truncate" title={`Math: ${student.schedule.math}`}>
                                <span className="text-slate-400 font-bold block text-[8px] uppercase">Math</span>
                                <span className="text-slate-600 font-semibold truncate block">{student.schedule.math}</span>
                              </div>
                            )}
                            {student.schedule.science && (
                              <div className="bg-slate-50/50 border border-slate-100 rounded-lg p-1.5 px-2 truncate" title={`Science: ${student.schedule.science}`}>
                                <span className="text-slate-400 font-bold block text-[8px] uppercase">Science</span>
                                <span className="text-slate-600 font-semibold truncate block">{student.schedule.science}</span>
                              </div>
                            )}
                            {student.schedule.socialStudies && (
                              <div className="bg-slate-50/50 border border-slate-100 rounded-lg p-1.5 px-2 truncate" title={`Social Studies: ${student.schedule.socialStudies}`}>
                                <span className="text-slate-400 font-bold block text-[8px] uppercase">Social S.</span>
                                <span className="text-slate-600 font-semibold truncate block">{student.schedule.socialStudies}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Section: Course Email Groups */}
          {filteredCourseGroups.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                  Course Email Groups ({filteredCourseGroups.length})
                </h3>
                <div className="flex-1 h-px bg-slate-100"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 items-start">
                {filteredCourseGroups.map((group) => (
                  <CourseGroupCard
                    key={group.id}
                    group={group}
                    isTeacher={isTeacher}
                    allStudents={students}
                    onRemoveStudentFromCourse={handleRemoveStudentFromCourse}
                    onAddStudentToCourse={handleAddStudentToCourse}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Section: Standard Contacts (Teachers & Staff) */}
          {filteredContacts.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                  {activeFilter === "all"
                    ? `Teachers & Google Contacts (${filteredContacts.length})`
                    : `Staff / Directory (${filteredContacts.length})`}
                </h3>
                <div className="flex-1 h-px bg-slate-100"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredContacts.map((contact) => (
                  <div
                    id={`contact-card-${contact.id}`}
                    key={contact.id}
                    className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs hover:shadow-md hover:border-slate-200 transition duration-250 flex flex-col justify-between"
                  >
                    <div className="flex items-start gap-4">
                      {/* Photo or Icon */}
                      {contact.photoUrl ? (
                        <img
                          src={contact.photoUrl}
                          alt={contact.name}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-full object-cover border border-slate-100 shrink-0"
                        />
                      ) : (
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center font-extrabold shadow-inner shrink-0 ${
                            contact.role === "teacher"
                              ? "bg-amber-50 text-amber-600"
                              : contact.role === "classmate"
                              ? "bg-indigo-50 text-indigo-600"
                              : "bg-slate-50 text-slate-600"
                          }`}
                        >
                          {contact.name.charAt(0).toUpperCase()}
                        </div>
                      )}

                      {/* Details */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="font-bold text-slate-800 text-xs truncate max-w-[125px] sm:max-w-none" title={contact.name}>
                            {contact.name}
                          </h4>
                          {contact.role === "teacher" && (() => {
                            const badge = getTeacherBadge(contact.title || "");
                            return (
                              <span className={`text-[9px] font-black tracking-wider uppercase px-1.5 py-0.5 rounded-md shrink-0 border ${badge.classes}`}>
                                {badge.label}
                              </span>
                            );
                          })()}
                        </div>

                        {contact.title && (
                          <div className="text-[10px] text-indigo-600 font-extrabold tracking-tight mt-1 max-w-full truncate" title={contact.title}>
                            {contact.title}
                          </div>
                        )}

                        <div className="space-y-1 mt-2">
                          {contact.email && (
                            <p className="text-[11px] text-slate-500 font-medium truncate flex items-center gap-1.5 leading-4">
                              <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span className="truncate">{contact.email}</span>
                            </p>
                          )}
                          {contact.phone && (
                            <p className="text-[11px] text-slate-500 font-medium truncate flex items-center gap-1.5 leading-4">
                              <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span>{contact.phone}</span>
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 border-t border-slate-50 pt-4 mt-4">
                      {contact.email && (
                        <a
                          id={`contact-action-email-${contact.id}`}
                          href={`mailto:${contact.email}`}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-slate-50 hover:bg-slate-100 text-xs text-slate-700 font-bold rounded-xl transition duration-200 border border-slate-100 cursor-pointer"
                        >
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          Email
                        </a>
                      )}
                      {contact.phone && (
                        <a
                          id={`contact-action-call-${contact.id}`}
                          href={`tel:${contact.phone}`}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-slate-50 hover:bg-slate-100 text-xs text-slate-700 font-bold rounded-xl transition duration-200 border border-slate-100 cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          Call
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Dynamic Overlay Modal for Teacher 'Add Student' tool */}
      {isAddMenuOpen && (
        <div id="add-student-modal-overlay" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-55 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-lg w-full shadow-2xl p-6 relative flex flex-col max-h-[90vh] overflow-hidden">
            {/* Header branding */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-inner">
                  <UserPlus className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 text-sm">Add Student to Roster</h3>
                  <span className="text-[10px] text-slate-500 font-medium font-sans">Create and register a student account</span>
                </div>
              </div>
              <button
                id="close-add-student-modal-btn"
                onClick={() => setIsAddMenuOpen(false)}
                className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Error alerts */}
            {formError && (
              <div className="mb-4 bg-red-50 border border-red-100 rounded-xl p-3 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-red-650 mt-0.5 shrink-0" />
                <span className="text-[11px] text-red-700 font-medium leading-4">{formError}</span>
              </div>
            )}

            {/* Scrollable form */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1.5">
                    First Name <span className="text-red-550">*</span>
                  </label>
                  <input
                    id="add-student-firstname-input"
                    type="text"
                    required
                    placeholder="e.g. Soklyly"
                    value={newStudent.firstName}
                    onChange={(e) => setNewStudent({...newStudent, firstName: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1.5">
                    Last Name <span className="text-red-550">*</span>
                  </label>
                  <input
                    id="add-student-lastname-input"
                    type="text"
                    required
                    placeholder="e.g. Chea"
                    value={newStudent.lastName}
                    onChange={(e) => setNewStudent({...newStudent, lastName: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1.5">
                    Grade Level <span className="text-red-550">*</span>
                  </label>
                  <select
                    id="add-student-grade-select"
                    value={newStudent.grade}
                    onChange={(e) => setNewStudent({...newStudent, grade: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition cursor-pointer"
                  >
                    <option value="Grade 9">Grade 9</option>
                    <option value="Grade 10">Grade 10</option>
                    <option value="Grade 11">Grade 11</option>
                    <option value="Grade 12">Grade 12</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-1.5">
                    Gender <span className="text-red-550">*</span>
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setNewStudent({...newStudent, gender: "F"})}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border transition cursor-pointer text-center ${
                        newStudent.gender === "F"
                          ? "bg-indigo-50 border-indigo-200 text-indigo-700 font-extrabold shadow-xs"
                          : "bg-slate-50 border-slate-205 text-slate-600 hover:bg-slate-100"
                      }`}
                    >
                      Female (F)
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewStudent({...newStudent, gender: "M"})}
                      className={`py-2 px-3 text-xs font-bold rounded-xl border transition cursor-pointer text-center ${
                        newStudent.gender === "M"
                          ? "bg-indigo-50 border-indigo-200 text-indigo-700 font-extrabold shadow-xs"
                          : "bg-slate-50 border-slate-205 text-slate-600 hover:bg-slate-100"
                      }`}
                    >
                      Male (M)
                    </button>
                  </div>
                </div>
              </div>

              {/* Password auto display */}
              <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-3 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <span className="block text-[8px] font-black uppercase tracking-wider text-amber-500 mb-0.5">Auto-generated Password</span>
                  <code id="generated-password-code" className="font-mono text-xs font-black text-amber-700 tracking-wide select-all">{passwordHint}</code>
                </div>
                <button
                  type="button"
                  onClick={() => setPasswordHint(generatePassword())}
                  className="px-2.5 py-1 text-[10px] font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition cursor-pointer shrink-0"
                >
                  Regenerate
                </button>
              </div>

              {/* Course Schedules (Optional Inputs) */}
              <div className="border-t border-slate-100 pt-4">
                <span className="block text-[10px] uppercase font-black text-slate-400 tracking-wider mb-2.5">
                  Subjects & Schedule Enrollment
                </span>
                <div className="space-y-3">
                  <div>
                    <label className="block text-[9px] text-slate-500 font-bold mb-1">English Course</label>
                    <input
                      id="schedule-english-input"
                      type="text"
                      placeholder="e.g. English 1"
                      value={newStudent.english}
                      onChange={(e) => setNewStudent({...newStudent, english: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden transition"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-slate-500 font-bold mb-1">Math Course</label>
                    <input
                      id="schedule-math-input"
                      type="text"
                      placeholder="e.g. Algebra 2"
                      value={newStudent.math}
                      onChange={(e) => setNewStudent({...newStudent, math: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden transition"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-slate-500 font-bold mb-1">Science Course</label>
                    <input
                      id="schedule-science-input"
                      type="text"
                      placeholder="e.g. Chemistry"
                      value={newStudent.science}
                      onChange={(e) => setNewStudent({...newStudent, science: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden transition"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-slate-500 font-bold mb-1">Social Studies Course</label>
                    <input
                      id="schedule-socialstudies-input"
                      type="text"
                      placeholder="e.g. AP Human Geography"
                      value={newStudent.socialStudies}
                      onChange={(e) => setNewStudent({...newStudent, socialStudies: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden transition"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] text-slate-500 font-bold mb-1">Other Course</label>
                    <input
                      id="schedule-other-input"
                      type="text"
                      placeholder="e.g. AP CSP"
                      value={newStudent.other}
                      onChange={(e) => setNewStudent({...newStudent, other: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-850 focus:outline-hidden transition"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Submit layout */}
            <div className="border-t border-slate-100 pt-4 mt-4 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsAddMenuOpen(false)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="btn-submit-add-student"
                type="button"
                onClick={() => {
                  if (!newStudent.firstName.trim() || !newStudent.lastName.trim()) {
                    setFormError("Both student First Name and Last Name are required.");
                    return;
                  }
                  
                  const fullName = `${newStudent.firstName.trim()} ${newStudent.lastName.trim()}`;
                  if (students.some(s => s.name.toLowerCase() === fullName.toLowerCase())) {
                    setFormError(`A student named "${fullName}" already exists in the roster.`);
                    return;
                  }

                  const studentRecord: StudentUser = {
                    name: fullName,
                    lastName: newStudent.lastName.trim(),
                    firstName: newStudent.firstName.trim(),
                    gender: newStudent.gender,
                    password: passwordHint || "student123",
                    grade: newStudent.grade,
                    schedule: {
                      english: newStudent.english.trim(),
                      math: newStudent.math.trim(),
                      science: newStudent.science.trim(),
                      socialStudies: newStudent.socialStudies.trim(),
                      other: newStudent.other.trim(),
                    },
                    toBeReviewed: false,
                  };

                  handleAddStudent(studentRecord);
                  setShowSuccessToast(`Successfully added ${fullName} to the roster!`);
                  setIsAddMenuOpen(false);
                  
                  setNewStudent({
                    firstName: "",
                    lastName: "",
                    gender: "F",
                    grade: "Grade 9",
                    english: "",
                    math: "",
                    science: "",
                    socialStudies: "",
                    other: "",
                  });
                  setTimeout(() => setShowSuccessToast(null), 4000);
                }}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-md shadow-indigo-100"
              >
                Add Student
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating success toast */}
      {showSuccessToast && (
        <div id="toast-success-add" className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-850 text-white rounded-2xl shadow-xl px-5 py-3.5 z-55 flex items-center gap-2.5 animate-fadeIn">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-bold font-sans">{showSuccessToast}</span>
        </div>
      )}
    </div>
  );
}
