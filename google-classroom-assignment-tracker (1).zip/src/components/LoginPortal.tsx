import React, { useState } from "react";
import { GraduationCap, ArrowRight, User, Lock, AlertCircle, Info, ShieldCheck, Eye, EyeOff } from "lucide-react";
import { studentsList } from "../studentsData";
import { teachersList } from "../teachersData";

const jpaLogo = "https://apps.jpa.org.kh/images/JPA-Logo.png";

interface LoginPortalProps {
  isSyncing: boolean;
  errorAlert: string | null;
  onClearError: () => void;
  onCustomStudentLogin: (name: string, gradeLevel: string, passwordText: string) => Promise<void>;
  onTeacherLogin: (teacherId: string, name: string, title: string, email: string) => Promise<void>;
  onGoogleSignIn?: () => void;
}

export default function LoginPortal({
  isSyncing,
  errorAlert,
  onClearError,
  onCustomStudentLogin,
  onTeacherLogin,
  onGoogleSignIn,
}: LoginPortalProps) {
  // Switcher state: "student" or "teacher"
  const [activeRole, setActiveRole] = useState<"student" | "teacher">("student");

  // Custom Student Credentials State
  const [studentSearchInput, setStudentSearchInput] = useState("");
  const [studentPassword, setStudentPassword] = useState("");
  const [showStudentPassword, setShowStudentPassword] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Teacher Credentials State
  const [teacherSearchInput, setTeacherSearchInput] = useState("");
  const [teacherPassword, setTeacherPassword] = useState("");
  const [showTeacherPassword, setShowTeacherPassword] = useState(false);
  const [showTeacherSuggestions, setShowTeacherSuggestions] = useState(false);

  const [localError, setLocalError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Filter student name suggestions as they type
  const suggestions = studentSearchInput.trim()
    ? studentsList.filter((s) =>
        s.name.toLowerCase().includes(studentSearchInput.toLowerCase())
      )
    : [];

  // Filter teacher name/title suggestions as they type
  const teacherSuggestions = teacherSearchInput.trim()
    ? teachersList.filter((t) =>
        t.name.toLowerCase().includes(teacherSearchInput.toLowerCase()) ||
        t.title.toLowerCase().includes(teacherSearchInput.toLowerCase())
      )
    : [];

  const handleSelectStudentSuggestion = (name: string) => {
    setStudentSearchInput(name);
    setShowSuggestions(false);
    setLocalError(null);
  };

  const handleSelectTeacherSuggestion = (name: string) => {
    setTeacherSearchInput(name);
    setShowTeacherSuggestions(false);
    setLocalError(null);
  };

  const handleStudentLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    const trimmedName = studentSearchInput.trim();
    const trimmedPassword = studentPassword.trim();

    if (!trimmedName || !trimmedPassword) {
      setLocalError("Please enter your name and password.");
      return;
    }

    const matchedStudent = studentsList.find(
      (s) => s.name.toLowerCase() === trimmedName.toLowerCase()
    );

    if (!matchedStudent) {
      setLocalError("Spelling error: Student name not found in Grade 9-12 registries.");
      return;
    }

    const storedStudentPassword = localStorage.getItem(`student_pwd_${matchedStudent.name}`) || matchedStudent.password;

    if (storedStudentPassword !== trimmedPassword) {
      setLocalError("Access denied: Incorrect password for this student.");
      return;
    }

    setIsLoggingIn(true);
    try {
      await onCustomStudentLogin(matchedStudent.name, matchedStudent.grade, matchedStudent.password);
    } catch (err: any) {
      console.error(err);
      setLocalError(err?.message || "An authentication error occurred.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleTeacherLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    const trimmedName = teacherSearchInput.trim();
    const trimmedPassword = teacherPassword.trim();

    if (!trimmedName || !trimmedPassword) {
      setLocalError("Please select a teacher/staff name and enter your password.");
      return;
    }

    const matchedTeacher = teachersList.find(
      (t) => t.name.toLowerCase() === trimmedName.toLowerCase()
    );

    if (!matchedTeacher) {
      setLocalError("Spelling error: Teacher/Staff name not found in active roll listings.");
      return;
    }

    // Passwords can be changed later, check localStorage fallback to '12345'
    const storedPassword = localStorage.getItem(`teacher_pwd_${matchedTeacher.id}`) || "12345";

    if (storedPassword !== trimmedPassword) {
      setLocalError("Access denied: Incorrect password for this Teacher or Staff member.");
      return;
    }

    setIsLoggingIn(true);
    try {
      await onTeacherLogin(matchedTeacher.id, matchedTeacher.name, matchedTeacher.title, matchedTeacher.email);
    } catch (err: any) {
      console.error(err);
      setLocalError(err?.message || "An authentication error occurred.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleTabSwitch = (role: "student" | "teacher") => {
    setActiveRole(role);
    setLocalError(null);
    onClearError();
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 md:p-6 font-sans animate-fade-in">
      <div className="w-full max-w-md bg-white rounded-3xl border border-slate-100 shadow-xl shadow-slate-100 overflow-hidden flex flex-col p-6 md:p-8 space-y-6">
        
        {/* Top Header branding */}
        <div className="text-center space-y-3">
          <img
            src={jpaLogo}
            alt="JPA Logo"
            className="mx-auto w-14 h-14 rounded-2xl shadow-lg shadow-indigo-150/20 transform transition duration-300 hover:rotate-6 object-contain bg-[#3b6cb3] p-1.5 border border-slate-100 dark:border-slate-800"
          />
          <div className="space-y-1">
            <h1 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight leading-none">Classroom Portal</h1>
            <p className="text-[11px] text-indigo-600 font-bold uppercase tracking-widest">School System & Assignment Hub</p>
          </div>
        </div>

        {/* Custom Segmented Tab Switcher */}
        <div className="flex bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
          <button
            id="tab-student"
            type="button"
            onClick={() => handleTabSwitch("student")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition duration-200 flex items-center justify-center gap-1.5 ${
              activeRole === "student"
                ? "bg-white text-slate-800 shadow-sm"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Student Sign-In</span>
          </button>
          <button
            id="tab-teacher"
            type="button"
            onClick={() => handleTabSwitch("teacher")}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition duration-200 flex items-center justify-center gap-1.5 ${
              activeRole === "teacher"
                ? "bg-indigo-600 text-white shadow-sm shadow-indigo-100"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Teacher & Staff</span>
          </button>
        </div>

        {/* Info card describing layout */}
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex gap-2.5 items-start">
          <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
          {activeRole === "student" ? (
            <p className="text-[11px] text-slate-600 leading-relaxed font-semibold">
              To sign in, pick any registered student from Grade 1 to 12 rosters (e.g., <strong className="text-slate-800">Soklyly Chea</strong> or <strong className="text-slate-800">Mitona Ae</strong>) and type their registered password.
            </p>
          ) : (
            <p className="text-[11px] text-slate-600 leading-relaxed font-semibold">
              To sign in as faculty or staff, choose your name (e.g., <strong className="text-slate-800">Hom Sa Oum</strong> or <strong className="text-slate-800">Yeng Chhaily</strong>). The default password is <strong className="text-slate-800">12345</strong> (can be changed later in Settings).
            </p>
          )}
        </div>

        {/* Dynamic Errors inside portal */}
        {(localError || errorAlert) && (
          <div id="local-login-error" className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex gap-2.5 items-start">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5 animate-pulse">
              <h4 className="text-xs font-extrabold text-rose-800 uppercase tracking-wide">Authentication Denied</h4>
              <p className="text-[11px] text-rose-700 leading-normal font-semibold">
                {localError || errorAlert}
              </p>
            </div>
          </div>
        )}

        {activeRole === "student" ? (
          <form id="student-login-form" onSubmit={handleStudentLoginSubmit} className="space-y-4">
            {/* Student Name */}
            <div className="space-y-1.5 relative">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Student Full Name
              </label>
              <div className="relative">
                <input
                  id="student-name-input"
                  type="text"
                  placeholder="e.g. Soklyly Chea"
                  value={studentSearchInput}
                  onChange={(e) => {
                    setStudentSearchInput(e.target.value);
                    setShowSuggestions(true);
                    setLocalError(null);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                  className="w-full text-xs font-semibold p-3.5 pl-10 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition bg-slate-50/20"
                  required
                />
                <User className="absolute left-3.5 top-4 w-4 h-4 text-slate-400" />
              </div>

              {/* Suggestions dropdown */}
              {showSuggestions && suggestions.length > 0 && (
                <div className="absolute z-50 left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-slate-150 rounded-2xl shadow-lg divide-y divide-slate-50">
                  {suggestions.slice(0, 6).map((item) => (
                    <button
                      key={item.name}
                      type="button"
                      onClick={() => handleSelectStudentSuggestion(item.name)}
                      className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-slate-50 transition flex items-center justify-between text-slate-700"
                    >
                      <span>{item.name}</span>
                      <span className="text-[9px] font-black uppercase text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">{item.grade}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Student Password */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Assigned Portal Password
              </label>
              <div className="relative">
                <input
                  id="student-password-input"
                  type={showStudentPassword ? "text" : "password"}
                  placeholder="Enter student password"
                  value={studentPassword}
                  onChange={(e) => {
                    setStudentPassword(e.target.value);
                    setLocalError(null);
                  }}
                  className="w-full text-xs font-mono p-3.5 pl-10 pr-10 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition bg-slate-50/20"
                  required
                />
                <Lock className="absolute left-3.5 top-4 w-4 h-4 text-slate-400" />
                <button
                  id="btn-toggle-student-login-password"
                  type="button"
                  onClick={() => setShowStudentPassword(!showStudentPassword)}
                  className="absolute right-3.5 top-4 text-slate-400 hover:text-slate-600 transition focus:outline-hidden"
                >
                  {showStudentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              id="student-login-submit-btn"
              type="submit"
              disabled={isLoggingIn}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-60 text-white font-extrabold rounded-2xl text-xs shadow-lg shadow-indigo-100 transition-all duration-200"
            >
              {isLoggingIn ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Entering classroom...</span>
                </>
              ) : (
                <>
                  <span>Sign In Student Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        ) : (
          <form id="teacher-login-form" onSubmit={handleTeacherLoginSubmit} className="space-y-4">
            {/* Teacher Name */}
            <div className="space-y-1.5 relative">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Search Teacher / Staff Name
              </label>
              <div className="relative">
                <input
                  id="teacher-name-input"
                  type="text"
                  placeholder="e.g. Hom Sa Oum"
                  value={teacherSearchInput}
                  onChange={(e) => {
                    setTeacherSearchInput(e.target.value);
                    setShowTeacherSuggestions(true);
                    setLocalError(null);
                  }}
                  onFocus={() => setShowTeacherSuggestions(true)}
                  className="w-full text-xs font-semibold p-3.5 pl-10 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition bg-slate-50/20"
                  required
                />
                <User className="absolute left-3.5 top-4 w-4 h-4 text-slate-400" />
              </div>

              {/* Suggestions dropdown */}
              {showTeacherSuggestions && teacherSuggestions.length > 0 && (
                <div className="absolute z-50 left-0 right-0 mt-1 max-h-48 overflow-y-auto bg-white border border-slate-150 rounded-2xl shadow-lg divide-y divide-slate-50">
                  {teacherSuggestions.slice(0, 8).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectTeacherSuggestion(item.name)}
                      className="w-full text-left px-4 py-2.5 text-xs font-semibold hover:bg-slate-50 transition flex flex-col gap-0.5 text-slate-700"
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="font-bold">{item.name}</span>
                        <span className="text-[8px] font-extrabold uppercase text-indigo-600 bg-indigo-50 px-1 py-0.5 rounded">Faculty</span>
                      </div>
                      <span className="text-[9px] text-slate-400 font-medium truncate w-11/12">{item.title}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Teacher Password */}
            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                Portal Password (Default is 12345)
              </label>
              <div className="relative">
                <input
                  id="teacher-password-input"
                  type={showTeacherPassword ? "text" : "password"}
                  placeholder="Enter staff password"
                  value={teacherPassword}
                  onChange={(e) => {
                    setTeacherPassword(e.target.value);
                    setLocalError(null);
                  }}
                  className="w-full text-xs font-mono p-3.5 pl-10 pr-10 rounded-2xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 transition bg-slate-50/20"
                  required
                />
                <Lock className="absolute left-3.5 top-4 w-4 h-4 text-slate-400" />
                <button
                  id="btn-toggle-teacher-login-password"
                  type="button"
                  onClick={() => setShowTeacherPassword(!showTeacherPassword)}
                  className="absolute right-3.5 top-4 text-slate-400 hover:text-slate-600 transition focus:outline-hidden"
                >
                  {showTeacherPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              id="teacher-login-submit-btn"
              type="submit"
              disabled={isLoggingIn}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-60 text-white font-extrabold rounded-2xl text-xs shadow-lg shadow-indigo-100 transition-all duration-200"
            >
              {isLoggingIn ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Entering staff console...</span>
                </>
              ) : (
                <>
                  <span>Sign In Faculty Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {onGoogleSignIn && (
          <div className="space-y-4">
            <div className="flex items-center my-1 pt-2">
              <div className="flex-grow border-t border-slate-100"></div>
              <span className="flex-shrink mx-4 text-[9px] text-slate-400 font-bold uppercase tracking-wider">Or Connect Academic Workspace</span>
              <div className="flex-grow border-t border-slate-100"></div>
            </div>

            <button
              id="google-classroom-login-btn"
              type="button"
              onClick={onGoogleSignIn}
              disabled={isSyncing}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white hover:bg-slate-50 active:bg-slate-100 disabled:opacity-60 text-slate-700 font-extrabold border border-slate-200 rounded-2xl text-xs shadow-xs hover:border-slate-300 transition-all duration-200"
            >
              <svg className="w-4.5 h-4.5 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              <span>Sign In with Google Classroom</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
