import React, { useState } from "react";
import { Course, UnifiedAssignment } from "../types";
import { 
  BookOpen, ExternalLink, Calendar, Users, FolderCheck, Trash2, Plus, X, Sparkles, ClipboardPlus,
  Check, Filter, Search, GraduationCap, Mail, CheckCircle, HelpCircle, Shield, AlertTriangle
} from "lucide-react";
import { studentsList, StudentUser } from "../studentsData";

interface ClassroomExplorerProps {
  courses: Course[];
  assignments: UnifiedAssignment[];
  onDeleteCourse?: (id: string) => void;
  onAddCourse?: (course: Course) => void;
  onAddAssignment?: (assignment: UnifiedAssignment) => void;
  initialTab?: "courses" | "roster";
  currentUser?: { displayName: string; role: string; [key: string]: any } | null;
}

export default function ClassroomExplorer({
  courses,
  assignments,
  onDeleteCourse,
  onAddCourse,
  onAddAssignment,
  initialTab,
  currentUser,
}: ClassroomExplorerProps) {
  // Add Course State
  const [showAddForm, setShowAddForm] = useState(false);
  
  // Dual explorer view tab switcher
  const [explorerTab, setExplorerTab] = useState<"courses" | "roster">(initialTab || "courses");

  React.useEffect(() => {
    if (initialTab) {
      setExplorerTab(initialTab);
    }
  }, [initialTab]);

  // Roster Filter Elements & Search Query
  const [rosterSearch, setRosterSearch] = useState("");
  const [rosterClass, setRosterClass] = useState("All");

  // Dynamically extract all unique class names across the entire student body schedules
  const uniqueClassesList = React.useMemo(() => {
    const classes = new Set<string>();
    studentsList.forEach((s) => {
      if (s.schedule) {
        Object.values(s.schedule).forEach((val) => {
          const trimmed = val ? String(val).trim() : "";
          if (trimmed) {
            classes.add(trimmed);
          }
        });
      }
    });
    return ["All", ...Array.from(classes).sort()];
  }, []);

  const [rosterGender, setRosterGender] = useState("All");
  const [rosterReview, setRosterReview] = useState("All");

  // Selected Date for communal daily Attendance
  const [attendanceDate, setAttendanceDate] = useState(() => {
    return new Date().toISOString().split("T")[0];
  });

  // Local Storage State: Attendance logging
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, Record<string, string>>>(() => {
    const saved = localStorage.getItem("com_attendance_records_store_v1");
    if (saved) return JSON.parse(saved);
    // Seed some general default attendance values to display real-life content
    return {};
  });

  // Local Storage State: Q2 W4 Review Overrides so they can toggle review status live
  const [reviewOverrides, setReviewOverrides] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem("roster_review_overrides_store_v1");
    return saved ? JSON.parse(saved) : {};
  });

  const handleToggleAttendance = (studentName: string, status: "Present" | "Absent" | "Late" | "Excused") => {
    setAttendanceRecords((prev) => {
      const dayRecord = prev[attendanceDate] || {};
      const updatedDay = { ...dayRecord, [studentName]: status };
      const nextRecords = { ...prev, [attendanceDate]: updatedDay };
      localStorage.setItem("com_attendance_records_store_v1", JSON.stringify(nextRecords));
      return nextRecords;
    });
  };

  const handleToggleReviewOverride = (studentName: string, originalToBeReviewed: boolean) => {
    const isCurrentlyReviewed = reviewOverrides[studentName] !== undefined
      ? reviewOverrides[studentName]
      : originalToBeReviewed;

    const nextOverrides = {
      ...reviewOverrides,
      [studentName]: !isCurrentlyReviewed
    };
    setReviewOverrides(nextOverrides);
    localStorage.setItem("roster_review_overrides_store_v1", JSON.stringify(nextOverrides));
  };
  const [newClassName, setNewClassName] = useState("");
  const [newClassSection, setNewClassSection] = useState("");
  const [newClassDescHeading, setNewClassDescHeading] = useState("");
  const [newClassDesc, setNewClassDesc] = useState("");
  const [newClassColor, setNewClassColor] = useState("indigo");

  // Add Assignment State
  const [expandedCourseIdForAssign, setExpandedCourseIdForAssign] = useState<string | null>(null);
  const [assignTitle, setAssignTitle] = useState("");
  const [assignDesc, setAssignDesc] = useState("");
  const [assignMaxPoints, setAssignMaxPoints] = useState("100");
  const [assignDueDate, setAssignDueDate] = useState("");
  const [assignState, setAssignState] = useState<"assigned" | "submitted" | "missing" | "graded">("assigned");
  const [assignGrade, setAssignGrade] = useState("");

  const handleAddAssignmentSubmit = (e: React.FormEvent, course: Course) => {
    e.preventDefault();
    if (!assignTitle.trim()) return;

    if (onAddAssignment) {
      onAddAssignment({
        id: `work-${Date.now()}`,
        courseId: course.id,
        courseName: course.name,
        courseColor: course.color || "indigo",
        title: assignTitle.trim(),
        description: assignDesc.trim() || undefined,
        maxPoints: assignMaxPoints ? Number(assignMaxPoints) : undefined,
        dueDate: assignDueDate ? new Date(assignDueDate) : null,
        state: assignState,
        grade: assignState === "graded" && assignGrade ? Number(assignGrade) : undefined,
        alternateLink: `https://classroom.google.com`,
        updateTime: new Date().toISOString()
      });
    }

    setExpandedCourseIdForAssign(null);
    setAssignTitle("");
    setAssignDesc("");
    setAssignMaxPoints("100");
    setAssignDueDate("");
    setAssignState("assigned");
    setAssignGrade("");
  };
  // Color mappings
  const bgColors: Record<string, string> = {
    indigo: "bg-indigo-50 border-indigo-100 text-indigo-700",
    emerald: "bg-emerald-50 border-emerald-100 text-emerald-700",
    amber: "bg-amber-50 border-amber-100 text-amber-700",
    rose: "bg-rose-50 border-rose-100 text-rose-700",
    violet: "bg-violet-50 border-violet-100 text-violet-700",
    sky: "bg-sky-50 border-sky-100 text-sky-700"
  };

  const hoverColors: Record<string, string> = {
    indigo: "hover:border-indigo-300",
    emerald: "hover:border-emerald-300",
    amber: "hover:border-amber-300",
    rose: "hover:border-rose-300",
    violet: "hover:border-violet-300",
    sky: "hover:border-sky-300"
  };

  const badgeColors: Record<string, string> = {
    indigo: "bg-indigo-500",
    emerald: "bg-emerald-500",
    amber: "bg-amber-500",
    rose: "bg-rose-500",
    violet: "bg-violet-500",
    sky: "bg-sky-500"
  };

  const colorOptions = ["indigo", "emerald", "amber", "rose", "violet", "sky"];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;

    if (onAddCourse) {
      onAddCourse({
        id: `course-${Date.now()}`,
        name: newClassName.trim(),
        section: newClassSection.trim() || undefined,
        descriptionHeading: newClassDescHeading.trim() || undefined,
        description: newClassDesc.trim() || undefined,
        alternateLink: `https://classroom.google.com`,
        color: newClassColor
      });
    }

    setNewClassName("");
    setNewClassSection("");
    setNewClassDescHeading("");
    setNewClassDesc("");
    setNewClassColor("indigo");
    setShowAddForm(false);
  };

  const isTeacher = currentUser?.role === "teacher";
  const actualTab = (!isTeacher && explorerTab === "roster") ? "courses" : explorerTab;

  return (
    <div className="space-y-6">
      {actualTab === "courses" ? (
        <div className="space-y-6">
          {/* Top Banner & Control Area */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-xs">
            <div>
              <h2 className="text-base font-black text-slate-800 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                Classroom Registry
              </h2>
              <p className="text-[11px] text-slate-400 mt-1 font-medium leading-relaxed">
                Log into academic classrooms, examine coursework load, and manage custom syllabi.
              </p>
            </div>

            {onAddCourse && (
              <button
                id="btn-toggle-add-class"
                onClick={() => setShowAddForm(!showAddForm)}
                className="flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm self-start sm:self-auto"
              >
                {showAddForm ? (
                  <>
                    <X className="w-4 h-4" />
                    Cancel
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    Add Custom Course
                  </>
                )}
              </button>
            )}
          </div>

          {/* Inline Form to Add Course */}
          {showAddForm && (
            <form
              id="form-add-class"
              onSubmit={handleSubmit}
              className="p-5 md:p-6 bg-white border border-slate-100 rounded-2xl shadow-md space-y-4 animate-fade-in"
            >
              <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <h3 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider">New Academic Classroom Information (Syllabus Seed)</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Course Name *
                  </label>
                  <input
                    id="input-new-course-name"
                    type="text"
                    required
                    placeholder="e.g. Calculus AP 101"
                    value={newClassName}
                    onChange={(e) => setNewClassName(e.target.value)}
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition bg-slate-50/50 hover:bg-slate-50/30"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Section (Optional)
                  </label>
                  <input
                    id="input-new-course-section"
                    type="text"
                    placeholder="e.g. Grade 11"
                    value={newClassSection}
                    onChange={(e) => setNewClassSection(e.target.value)}
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition bg-slate-50/50 hover:bg-slate-50/30"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Description Heading
                  </label>
                  <input
                    id="input-new-course-heading"
                    type="text"
                    placeholder="e.g. Fundamental Calculus and Analytic geometry proofs"
                    value={newClassDescHeading}
                    onChange={(e) => setNewClassDescHeading(e.target.value)}
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition bg-slate-50/50 hover:bg-slate-50/30"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Course Theme Color
                  </label>
                  <div className="flex items-center gap-2 pt-1 h-9">
                    {colorOptions.map((color) => {
                      const isSelected = newClassColor === color;
                      const bgMap: Record<string, string> = {
                        indigo: "bg-indigo-500",
                        emerald: "bg-emerald-500",
                        amber: "bg-amber-500",
                        rose: "bg-rose-500",
                        violet: "bg-violet-500",
                        sky: "bg-sky-500"
                      };
                      return (
                        <button
                          key={color}
                          id={`btn-color-pick-${color}`}
                          type="button"
                          onClick={() => setNewClassColor(color)}
                          className={`w-6 h-6 rounded-full ${bgMap[color]} transition-all duration-150 relative ${
                            isSelected ? "ring-2 ring-slate-800 ring-offset-2 scale-110" : "opacity-85 hover:opacity-100 hover:scale-105"
                          }`}
                          title={color}
                        />
                      );
                    })}
                  </div>
                </div>

                <div className="col-span-1 md:col-span-2 space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Extended Syllabus / Details Description (Optional)
                  </label>
                  <textarea
                    id="input-new-course-desc"
                    placeholder="Enter coursework syllabus coordinates..."
                    value={newClassDesc}
                    onChange={(e) => setNewClassDesc(e.target.value)}
                    className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition min-h-16 bg-slate-50/50 hover:bg-slate-50/30"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-50">
                <button
                  id="btn-cancel-add-class"
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Cancel
                </button>
                <button
                  id="btn-save-new-class"
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition shadow-sm"
                >
                  Save Classroom
                </button>
              </div>
            </form>
          )}

          {/* Classroom Grid */}
          {courses.length === 0 ? (
            <div id="classroom-empty-state" className="flex flex-col items-center justify-center text-center p-12 bg-white rounded-2xl border border-slate-100 shadow-xs space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <BookOpen className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-slate-800 text-base">No Classrooms Available</h3>
                <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
                  You do not have any registered academic courses on your dashboard yet. Custom seeding will load your student schedule details.
                </p>
              </div>
            </div>
          ) : (
            <div id="classroom-grid" className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {courses.map((course) => {
                const courseAssignments = assignments.filter(
                  (a) => a.courseId === course.id || (a.courseName && a.courseName.toLowerCase() === course.name.toLowerCase())
                );
                const pendingAssignments = courseAssignments.filter((a) => a.state === "assigned" || a.state === "missing");
                const completedAssignments = courseAssignments.filter((a) => a.state === "graded" || a.state === "submitted");

                const colorClasses = bgColors[course.color || "indigo"];
                const hoverBorderClass = hoverColors[course.color || "indigo"];
                const badgeBg = badgeColors[course.color || "indigo"];

                return (
                  <div
                    id={`classroom-card-${course.id}`}
                    key={course.id}
                    className={`bg-white rounded-2xl border border-slate-100 ${hoverBorderClass} shadow-xs p-6 flex flex-col justify-between transition duration-250`}
                  >
                    <div>
                      {/* Header Row */}
                      <div className="flex items-start justify-between gap-4 mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${colorClasses}`}>
                            <BookOpen className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="font-extrabold text-slate-800 text-sm md:text-base leading-tight">
                              {course.name}
                            </h3>
                            {course.section && (
                              <p className="text-[10px] font-extrabold text-slate-400 mt-0.5 tracking-tight uppercase">
                                {course.section}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <a
                            id={`link-ext-gc-${course.id}`}
                            href={course.alternateLink || "https://classroom.google.com"}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 px-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 rounded-lg text-[10px] font-bold flex items-center gap-1 transition"
                          >
                            Classroom
                            <ExternalLink className="w-3 h-3" />
                          </a>
                          {onDeleteCourse && (
                            <button
                              id={`btn-delete-course-${course.id}`}
                              onClick={() => {
                                if (confirm(`Are you sure you want to remove "${course.name}"?`)) {
                                  onDeleteCourse(course.id);
                                }
                              }}
                              title="Remove this class"
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-100 hover:border-rose-200 text-rose-600 rounded-lg transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Description info */}
                      {course.descriptionHeading && (
                        <p className="text-xs text-slate-600 font-semibold mb-1.5 leading-snug">{course.descriptionHeading}</p>
                      )}
                      {course.description && (
                        <p className="text-[11px] text-slate-500 leading-relaxed mb-4">{course.description}</p>
                      )}
                    </div>

                    {/* Counts & Detail Badges */}
                    <div className="pt-4 border-t border-slate-50 grid grid-cols-3 gap-3 text-center">
                      {/* Pending */}
                      <div className="bg-slate-50 rounded-xl p-2.5">
                        <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Pending</span>
                        <span className="text-base font-black text-slate-800 tracking-tight flex items-center justify-center gap-1.5 mt-1 leading-none">
                          <div className={`w-2 h-2 rounded-full ${badgeBg}`} />
                          {pendingAssignments.length}
                        </span>
                      </div>

                      {/* Completed */}
                      <div className="bg-slate-50 rounded-xl p-2.5">
                        <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Completed</span>
                        <span className="text-base font-black text-slate-800 tracking-tight flex items-center justify-center gap-1.5 mt-1 leading-none">
                          <div className="w-2 h-2 rounded-full bg-emerald-500" />
                          {completedAssignments.length}
                        </span>
                      </div>

                      {/* Total */}
                      <div className="bg-slate-50 rounded-xl p-2.5">
                        <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Total Work</span>
                        <span className="text-base font-black text-slate-800 tracking-tight flex items-center justify-center mt-1 leading-none">
                          {courseAssignments.length}
                        </span>
                      </div>
                    </div>

                    {/* Custom Assignment Form */}
                    {onAddAssignment && (
                      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col gap-2">
                        {expandedCourseIdForAssign === course.id ? (
                          <form onSubmit={(e) => handleAddAssignmentSubmit(e, course)} className="space-y-3 bg-slate-50 rounded-xl p-3 border border-slate-200 animate-fade-in text-left">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-1">
                                <ClipboardPlus className="w-3.5 h-3.5 text-indigo-500 animate-pulse" /> Custom Assignment
                              </label>
                              <button
                                type="button"
                                onClick={() => setExpandedCourseIdForAssign(null)}
                                className="p-1 hover:bg-slate-200 rounded-md text-slate-400 hover:text-slate-600 transition"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>

                            <input
                              type="text"
                              required
                              placeholder="Assignment Title (e.g. Calculus Worksheet)"
                              value={assignTitle}
                              onChange={(e) => setAssignTitle(e.target.value)}
                              className="w-full text-xs font-semibold p-2 bg-white rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                            />

                            <textarea
                              placeholder="Short description..."
                              value={assignDesc}
                              onChange={(e) => setAssignDesc(e.target.value)}
                              className="w-full text-xs font-normal p-2 bg-white rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden min-h-[40px]"
                            />

                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Max Points</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={assignMaxPoints}
                                  onChange={(e) => setAssignMaxPoints(e.target.value)}
                                  className="w-full text-xs font-semibold p-1.5 bg-white rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                                />
                              </div>
                              <div>
                                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Due Date</label>
                                <input
                                  type="date"
                                  value={assignDueDate}
                                  onChange={(e) => setAssignDueDate(e.target.value)}
                                  className="w-full text-xs font-semibold p-1.5 bg-white rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Status</label>
                                <select
                                  value={assignState}
                                  onChange={(e: any) => setAssignState(e.target.value)}
                                  className="w-full text-xs font-semibold p-1.5 bg-white rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                                >
                                  <option value="assigned">Assigned</option>
                                  <option value="submitted">Submitted</option>
                                  <option value="missing">Missing</option>
                                  <option value="graded">Graded</option>
                                </select>
                              </div>
                              {assignState === "graded" && (
                                <div>
                                  <label className="block text-[9px] font-bold text-slate-500 uppercase mb-0.5">Grade Obtained</label>
                                  <input
                                    type="number"
                                    min="0"
                                    max={assignMaxPoints}
                                    value={assignGrade}
                                    onChange={(e) => setAssignGrade(e.target.value)}
                                    className="w-full text-xs font-semibold p-1.5 bg-white rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                                  />
                                </div>
                              )}
                            </div>

                            <button
                              type="submit"
                              className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-black transition cursor-pointer shadow-sm"
                            >
                              Publish Assignment
                            </button>
                          </form>
                        ) : (
                          <button
                            onClick={() => {
                              setExpandedCourseIdForAssign(course.id);
                              setAssignTitle("");
                              setAssignDesc("");
                              setAssignMaxPoints("100");
                              setAssignDueDate("");
                              setAssignState("assigned");
                              setAssignGrade("");
                            }}
                            className="py-1.5 border border-dashed border-slate-200 hover:border-indigo-400 bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" /> Post Custom Assignment
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* Roster & Attendance Grid Spreadsheet View */
        <div className="space-y-6 animate-fade-in text-left">
          {/* Banner */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-xs">
            <div>
              <h2 className="text-base font-black text-slate-850 flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                Student Roster & Attendance Registry
              </h2>
              <p className="text-[11px] text-slate-400 mt-1 font-medium leading-relaxed">
                COMMUNAL REGISTRY. Manage class schedules, daily attendance checkmarks, and track <b>Q2 W4 Peer Reviews</b>.
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Attendance Log Date:</span>
              <input
                type="date"
                value={attendanceDate}
                onChange={(e) => setAttendanceDate(e.target.value)}
                className="text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Roster Statistics panel */}
          {(() => {
            // Calculated dynamic states
            const filteredList = studentsList.filter((s) => {
              const matchesSearch =
                s.name.toLowerCase().includes(rosterSearch.toLowerCase()) ||
                s.schedule.english.toLowerCase().includes(rosterSearch.toLowerCase()) ||
                s.schedule.math.toLowerCase().includes(rosterSearch.toLowerCase()) ||
                s.schedule.science.toLowerCase().includes(rosterSearch.toLowerCase()) ||
                s.schedule.socialStudies.toLowerCase().includes(rosterSearch.toLowerCase());

              const matchesClass = rosterClass === "All" || 
                Object.values(s.schedule).some(
                  (val) => val && String(val).trim().toLowerCase() === rosterClass.trim().toLowerCase()
                );
              const matchesGender = rosterGender === "All" || s.gender === rosterGender;

              const isFlaggedForReview = reviewOverrides[s.name] !== undefined
                ? reviewOverrides[s.name]
                : s.toBeReviewed;

              const matchesReview = rosterReview === "All"
                ? true
                : rosterReview === "Needs Review"
                ? isFlaggedForReview
                : !isFlaggedForReview;

              return matchesSearch && matchesClass && matchesGender && matchesReview;
            });

            const total = filteredList.length;
            const females = filteredList.filter(s => s.gender === "F").length;
            const males = filteredList.filter(s => s.gender === "M").length;
            
            const flagged = filteredList.filter(s => {
              return reviewOverrides[s.name] !== undefined ? reviewOverrides[s.name] : s.toBeReviewed;
            }).length;

            const dayRecord = attendanceRecords[attendanceDate] || {};
            const loggedNames = Object.keys(dayRecord);
            const verifiedActiveNames = loggedNames.filter(name => filteredList.some(s => s.name === name));
            const activePresentCount = verifiedActiveNames.filter(n => dayRecord[n] === "Present" || dayRecord[n] === "Late" || dayRecord[n] === "Excused").length;
            
            const attendanceScore = verifiedActiveNames.length > 0
              ? Math.round((activePresentCount / verifiedActiveNames.length) * 100)
              : 95; // realistic academic attendance rate default

            return (
              <>
                {/* Stats row */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-3xs flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Active Registry</span>
                      <span className="text-lg font-black text-slate-800">{total} Students</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">{females} Female / {males} Male</span>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-3xs flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Q2 W4 Peer Reviews</span>
                      <span className="text-lg font-black text-slate-800">{flagged} Flagged</span>
                      <span className="text-[9px] text-rose-500 font-bold block mt-0.5">Needs evaluation review</span>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-3xs flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                      <CheckCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Day Attendance</span>
                      <span className="text-lg font-black text-slate-800">{attendanceScore}% Mapped</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">Checkmarked for {attendanceDate}</span>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-3xs flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Registry Subjects</span>
                      <span className="text-lg font-black text-slate-800">18 Courses</span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">Grades 9-12 curriculum schedules</span>
                    </div>
                  </div>
                </div>

                {/* Filters Row */}
                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-3xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                  {/* Search bar */}
                  <div className="flex-1 max-w-sm relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search by student name or class..."
                      value={rosterSearch}
                      onChange={(e) => setRosterSearch(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition"
                    />
                  </div>

                  {/* Dropdown Filters with wrapping and explicit safe widths */}
                  <div className="flex flex-wrap items-center gap-4 md:gap-3 lg:gap-4 shrink-0 select-none">
                    {/* Class filter */}
                    <div className="flex items-center gap-1.5 whitespace-nowrap shrink-0">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Class:</span>
                      <select
                        value={rosterClass}
                        onChange={(e) => setRosterClass(e.target.value)}
                        className="text-xs font-semibold p-1.5 border border-slate-200 rounded-lg bg-white min-w-[110px] max-w-[180px] focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition cursor-pointer truncate"
                      >
                        {uniqueClassesList.map((cl) => (
                          <option key={cl} value={cl}>
                            {cl === "All" ? "All Classes" : cl}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Gender filter */}
                    <div className="flex items-center gap-1.5 whitespace-nowrap shrink-0">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Gender:</span>
                      <select
                        value={rosterGender}
                        onChange={(e) => setRosterGender(e.target.value)}
                        className="text-xs font-semibold p-1.5 border border-slate-200 rounded-lg bg-white min-w-[100px] focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition cursor-pointer"
                      >
                        <option value="All">All Genders</option>
                        <option value="F">F (Female)</option>
                        <option value="M">M (Male)</option>
                      </select>
                    </div>

                    {/* Review filter */}
                    <div className="flex items-center gap-1.5 whitespace-nowrap shrink-0">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Review:</span>
                      <select
                        value={rosterReview}
                        onChange={(e) => setRosterReview(e.target.value)}
                        className="text-xs font-semibold p-1.5 border border-slate-200 rounded-lg bg-white min-w-[100px] focus:outline-hidden focus:ring-1 focus:ring-indigo-500 transition cursor-pointer"
                      >
                        <option value="All">All Recs</option>
                        <option value="Needs Review">Needs evaluation</option>
                        <option value="Reviewed">Standard Clear</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Spreadsheet Table */}
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm relative z-0">
                  <div className="overflow-visible pb-20">
                    <table className="w-full table-auto border-collapse text-left text-xs font-semibold text-slate-700">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-100 text-[9px] font-black uppercase tracking-wider text-slate-400">
                          <th className="py-3 px-4">Student Full Name</th>
                          <th className="py-3 px-4 text-center">Daily Status Log</th>
                          <th className="py-3 px-4 text-right">Q2 W4 Review Alert</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredList.map((stud) => {
                          const currentDayAttendance = dayRecord[stud.name] || "Present";
                          const isReviewedFlagged = reviewOverrides[stud.name] !== undefined
                            ? reviewOverrides[stud.name]
                            : stud.toBeReviewed;

                          return (
                            <tr key={stud.name} className="hover:bg-slate-50/50 transition">
                              {/* Name with hover popup */}
                              <td className="py-3 px-4 font-black text-slate-800 whitespace-nowrap relative group cursor-pointer">
                                <span>{stud.name}</span>
                                {/* Popup Card */}
                                <div className="absolute left-4 top-full mt-2 w-64 bg-white border border-slate-200 shadow-xl rounded-xl p-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 pointer-events-none">
                                  <div className="flex items-center gap-2 mb-3">
                                    <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                                      stud.gender === "F" ? "bg-rose-50 text-rose-600 border border-rose-100" : "bg-blue-50 text-blue-600 border border-blue-100"
                                    }`}>
                                      {stud.gender}
                                    </span>
                                    <span className="text-xs font-semibold text-slate-500">{stud.grade}</span>
                                  </div>
                                  <div className="space-y-2 text-[10px]">
                                    <div className="flex justify-between">
                                      <span className="text-slate-400 font-bold uppercase tracking-wider">English</span>
                                      <span className="text-slate-700 font-semibold truncate max-w-[120px]" title={stud.schedule.english}>{stud.schedule.english || "-"}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-slate-400 font-bold uppercase tracking-wider">Math</span>
                                      <span className="text-slate-700 font-semibold truncate max-w-[120px]" title={stud.schedule.math}>{stud.schedule.math || "-"}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-slate-400 font-bold uppercase tracking-wider">Science</span>
                                      <span className="text-slate-700 font-semibold truncate max-w-[120px]" title={stud.schedule.science}>{stud.schedule.science || "-"}</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span className="text-slate-400 font-bold uppercase tracking-wider">Social Studies</span>
                                      <span className="text-slate-700 font-semibold truncate max-w-[120px]" title={stud.schedule.socialStudies}>{stud.schedule.socialStudies || "-"}</span>
                                    </div>
                                  </div>
                                </div>
                              </td>

                              {/* Daily Attendance Buttons selector */}
                              <td className="py-3 px-4 whitespace-nowrap text-center">
                                <div className="inline-flex gap-1 bg-slate-50 p-1 border border-slate-200 rounded-lg">
                                  {(["Present", "Absent", "Late", "Excused"] as const).map((status) => {
                                    const isSelected = currentDayAttendance === status;
                                    const colorMap: Record<string, string> = {
                                      Present: isSelected ? "bg-emerald-500 text-white shadow-xs" : "hover:bg-slate-200 text-slate-500",
                                      Absent: isSelected ? "bg-rose-500 text-white shadow-xs" : "hover:bg-slate-200 text-slate-500",
                                      Late: isSelected ? "bg-amber-500 text-white shadow-xs" : "hover:bg-slate-200 text-slate-500",
                                      Excused: isSelected ? "bg-indigo-500 text-white shadow-xs" : "hover:bg-slate-200 text-slate-500"
                                    };
                                    
                                    const symbolMap: Record<string, string> = {
                                      Present: "P",
                                      Absent: "A",
                                      Late: "L",
                                      Excused: "E"
                                    };

                                    return (
                                      <button
                                        key={status}
                                        type="button"
                                        onClick={() => handleToggleAttendance(stud.name, status)}
                                        className={`w-5 h-5 rounded text-[10px] font-black flex items-center justify-center transition cursor-pointer select-none ${colorMap[status]}`}
                                        title={`${status} (Mark checkmark)`}
                                      >
                                        {symbolMap[status]}
                                      </button>
                                    );
                                  })}
                                </div>
                              </td>

                              {/* Review evaluation toggle */}
                              <td className="py-3 px-4 text-right whitespace-nowrap">
                                <button
                                  type="button"
                                  onClick={() => handleToggleReviewOverride(stud.name, stud.toBeReviewed)}
                                  className={`inline-flex items-center gap-1 py-1 px-2 border rounded-lg text-[9px] font-black uppercase transition shrink-0 ${
                                    isReviewedFlagged
                                      ? "bg-rose-50 border-rose-200 text-rose-600 shadow-3xs"
                                      : "bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600"
                                  }`}
                                  title="Toggle Q2 W4 evaluation review status"
                                >
                                  {isReviewedFlagged ? (
                                    <>
                                      <AlertTriangle className="w-2.5 h-2.5 animate-bounce" />
                                      Needs Evaluation
                                    </>
                                  ) : (
                                    <>
                                      <Check className="w-2.5 h-2.5" />
                                      Clear / Reviewed
                                    </>
                                  )}
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {filteredList.length === 0 && (
                    <div className="p-12 text-center text-slate-400 text-xs">
                      No academic students match the chosen class/review/search criteria.
                    </div>
                  )}
                </div>
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
}
