import React, { useState, useEffect } from "react";
import { Calendar, MapPin } from "lucide-react";

export default function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    // Target date: October 10, 2026
    const targetDate = new Date("2026-10-10T08:00:00").getTime();

    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        return {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        };
      }
      return { days: 0, hours: 0, minutes: 0, seconds: 0 };
    };

    // Initial call
    setTimeLeft(calculateTimeLeft());

    // Update every second
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm mb-6 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-bl-full -z-10 transition-transform duration-700 ease-out hover:scale-110"></div>
      
      <div className="flex-1">
        <div className="flex flex-wrap items-center gap-2 mb-2">
          <span className="bg-indigo-100 text-indigo-700 text-xs font-extrabold px-2 py-1 rounded uppercase tracking-wider">
            Next Official SAT
          </span>
          <span className="bg-emerald-100 text-emerald-700 text-xs font-bold px-2 py-1 rounded">
            Standard Registration Open
          </span>
        </div>
        
        <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2 mb-1">
          <Calendar className="w-5 h-5 text-indigo-500" />
          October 10, 2026
        </h3>
        
        <p className="text-sm font-medium text-slate-500 flex items-center gap-1.5">
          <MapPin className="w-4 h-4 text-slate-400" />
          JPA Testing Center
        </p>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <TimeUnit value={timeLeft.days} label="Days" />
        <span className="text-2xl font-bold text-slate-300 mb-5">:</span>
        <TimeUnit value={timeLeft.hours} label="Hours" />
        <span className="text-2xl font-bold text-slate-300 mb-5">:</span>
        <TimeUnit value={timeLeft.minutes} label="Minutes" />
        <span className="text-2xl font-bold text-slate-300 mb-5">:</span>
        <TimeUnit value={timeLeft.seconds} label="Seconds" />
      </div>
    </div>
  );
}

function TimeUnit({ value, label }: { value: number; label: string }) {
  // Pad with 0 if single digit
  const displayValue = value < 10 ? `0${value}` : value;
  
  return (
    <div className="flex flex-col items-center">
      <div className="bg-slate-800 text-white font-mono text-2xl md:text-3xl font-bold w-14 h-14 md:w-16 md:h-16 flex items-center justify-center rounded-xl shadow-inner mb-1.5">
        {displayValue}
      </div>
      <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
        {label}
      </span>
    </div>
  );
}
