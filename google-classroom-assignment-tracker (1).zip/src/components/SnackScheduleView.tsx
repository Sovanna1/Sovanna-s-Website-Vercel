import React, { useState, useEffect } from "react";
import { Coffee, RotateCcw, Utensils, Search, RefreshCw, UserCheck, CheckCircle2, AlertCircle, Pencil } from "lucide-react";
import { Course } from "../types";
import { studentsList } from "../studentsData";

interface SnackScheduleViewProps {
  courses?: Course[];
  isTeacher?: boolean;
  currentUser?: { displayName: string; role: string; [key: string]: any } | null;
}

interface SnackDuty {
  pickUp: string[];
  returnBack: string[];
}

export default function SnackScheduleView({ isTeacher = false, currentUser }: SnackScheduleViewProps) {
  const [customDuties, setCustomDuties] = useState<Record<string, SnackDuty>>({});
  const [customHomeworkDuties, setCustomHomeworkDuties] = useState<Record<string, SnackDuty>>({});
  const [activeSubTab, setActiveSubTab] = useState<"snacks" | "homework">("snacks");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGradeFilter, setSelectedGradeFilter] = useState("all");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Strictly 4 snack schedules for grade 9, 10, 11, and 12
  const sortedClassLevels = ["Grade 9", "Grade 10", "Grade 11", "Grade 12"];

  // Load custom duties from localStorage
  useEffect(() => {
    const key = currentUser ? `snack_duty_assignments_${currentUser.displayName}` : "snack_duty_assignments_general";
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        setCustomDuties(JSON.parse(saved));
      } catch (err) {
        console.error("Error parsing snack duties", err);
      }
    }

    const homeworkKey = currentUser ? `homework_duty_assignments_${currentUser.displayName}` : "homework_duty_assignments_general";
    const savedHomework = localStorage.getItem(homeworkKey);
    if (savedHomework) {
      try {
        setCustomHomeworkDuties(JSON.parse(savedHomework));
      } catch (err) {
        console.error("Error parsing homework duties", err);
      }
    }
  }, [currentUser]);

  // Save custom duties to localStorage
  const saveDuties = (newDuties: Record<string, SnackDuty>) => {
    setCustomDuties(newDuties);
    const key = currentUser ? `snack_duty_assignments_${currentUser.displayName}` : "snack_duty_assignments_general";
    localStorage.setItem(key, JSON.stringify(newDuties));
  };

  const saveHomeworkDuties = (newDuties: Record<string, SnackDuty>) => {
    setCustomHomeworkDuties(newDuties);
    const key = currentUser ? `homework_duty_assignments_${currentUser.displayName}` : "homework_duty_assignments_general";
    localStorage.setItem(key, JSON.stringify(newDuties));
  };

  // Safe list of students matching a class level (e.g. "Grade 9")
  const getStudentsForClassLevel = (classLevel: string) => {
    const lowerLevel = classLevel.toLowerCase();
    
    // Strict match
    let filtered = studentsList.filter((s) => s.grade.toLowerCase() === lowerLevel);
    if (filtered.length >= 4) return filtered;

    // Range match or substring match (e.g., "Grade 10-12" matches Grade 10, Grade 11, or Grade 12 students)
    filtered = studentsList.filter((s) => {
      const sGrade = s.grade.toLowerCase();
      if (lowerLevel.includes(sGrade)) return true;
      return false;
    });

    if (filtered.length >= 4) return filtered;

    // Return any students as a generic fallback to protect against empty grades
    return studentsList;
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Get current assignment for a class level (loaded from custom state or deterministically weekly-seeded)
  const getSnackDutyForClassLevel = (classLevel: string): SnackDuty => {
    if (customDuties[classLevel]) {
      return customDuties[classLevel];
    }

    // Otherwise, generate a deterministic weekly assignment
    const eligible = getStudentsForClassLevel(classLevel);
    const d = new Date();
    const oneJan = new Date(d.getFullYear(), 0, 1);
    const numberOfDays = Math.floor((d.getTime() - oneJan.getTime()) / (24 * 60 * 60 * 24));
    const weekNum = Math.ceil((numberOfDays + oneJan.getDay() + 1) / 7);
    const year = d.getFullYear();

    // Compute a seed from level string plus date info
    const levelSum = classLevel.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const seed = levelSum + weekNum + year;

    // Deterministic shuffle
    const shuffled = [...eligible].sort((a, b) => {
      const hashA = (a.name.charCodeAt(0) * seed) % 97;
      const hashB = (b.name.charCodeAt(0) * seed) % 97;
      return hashA - hashB;
    });

    const p1 = shuffled[0]?.name || "Student 1";
    const p2 = shuffled[1]?.name || "Student 2";
    const r1 = shuffled[2]?.name || shuffled[0]?.name || "Student 3";
    const r2 = shuffled[3]?.name || shuffled[1]?.name || "Student 4";

    return {
      pickUp: [p1, p2],
      returnBack: [r1, r2],
    };
  };

  // Get current assignment for homework duty (deterministically seeded or loaded from custom state)
  const getHomeworkDutyForClassLevel = (classLevel: string): SnackDuty => {
    if (customHomeworkDuties[classLevel]) {
      return customHomeworkDuties[classLevel];
    }

    // Otherwise, generate a deterministic weekly assignment with offset seed to avoid student duplicate assignment
    const eligible = getStudentsForClassLevel(classLevel);
    const d = new Date();
    const oneJan = new Date(d.getFullYear(), 0, 1);
    const numberOfDays = Math.floor((d.getTime() - oneJan.getTime()) / (24 * 60 * 60 * 24));
    const weekNum = Math.ceil((numberOfDays + oneJan.getDay() + 1) / 7);
    const year = d.getFullYear();

    // Compute a seed from level string plus date info + homework shift salt
    const levelSum = classLevel.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const seed = levelSum + weekNum + year + 137;

    // Deterministic shuffle
    const shuffled = [...eligible].sort((a, b) => {
      const hashA = (a.name.charCodeAt(0) * seed) % 97;
      const hashB = (b.name.charCodeAt(0) * seed) % 97;
      return hashA - hashB;
    });

    const p1 = shuffled[0]?.name || "Student 1";
    const p2 = shuffled[1]?.name || "Student 2";
    const r1 = shuffled[2]?.name || shuffled[0]?.name || "Student 3";
    const r2 = shuffled[3]?.name || shuffled[1]?.name || "Student 4";

    return {
      pickUp: [p1, p2],
      returnBack: [r1, r2],
    };
  };

  // Auto/Manual Rotation handler
  const handleRotate = (classLevel: string) => {
    const eligible = getStudentsForClassLevel(classLevel);
    if (eligible.length < 4) {
      showToast(`Not enough students in ${classLevel} to perform rotation cleanly.`);
    }

    // Shuffle randomly
    const shuffled = [...eligible].sort(() => Math.random() - 0.5);
    const p1 = shuffled[0]?.name || "Student 1";
    const p2 = shuffled[1]?.name || "Student 2";
    let r1 = shuffled[2]?.name || "Student 3";
    let r2 = shuffled[3]?.name || "Student 4";

    // Deduplicate gracefully
    if (r1 === p1 || r1 === p2) r1 = shuffled[4]?.name || "Student 3";
    if (r2 === p1 || r2 === p2 || r2 === r1) r2 = shuffled[5]?.name || "Student 4";

    if (activeSubTab === "snacks") {
      const updated = {
        ...customDuties,
        [classLevel]: {
          pickUp: [p1, p2],
          returnBack: [r1, r2]
        }
      };
      saveDuties(updated);
      showToast(`Rotated snack duties for ${classLevel}!`);
    } else {
      const updated = {
        ...customHomeworkDuties,
        [classLevel]: {
          pickUp: [p1, p2],
          returnBack: [r1, r2]
        }
      };
      saveHomeworkDuties(updated);
      showToast(`Rotated homework writer duties for ${classLevel}!`);
    }
  };

  // Individual student reassignment dropdown handler
  const handleAssignIndividual = (
    classLevel: string,
    role: "pickUp" | "returnBack",
    index: number,
    studentName: string
  ) => {
    if (activeSubTab === "snacks") {
      const current = getSnackDutyForClassLevel(classLevel);
      const updatedRoleList = [...current[role]];
      updatedRoleList[index] = studentName;

      const updatedDuty: SnackDuty = {
        ...current,
        [role]: updatedRoleList,
      };

      const updated = {
        ...customDuties,
        [classLevel]: updatedDuty,
      };
      saveDuties(updated);
      showToast(`Assigned ${studentName} to snack ${role === "pickUp" ? "Go Get" : "Return"} duty.`);
    } else {
      const current = getHomeworkDutyForClassLevel(classLevel);
      const updatedRoleList = [...current[role]];
      updatedRoleList[index] = studentName;

      const updatedDuty: SnackDuty = {
        ...current,
        [role]: updatedRoleList,
      };

      const updated = {
        ...customHomeworkDuties,
        [classLevel]: updatedDuty,
      };
      saveHomeworkDuties(updated);
      showToast(`Assigned ${studentName} to homework writer ${role === "pickUp" ? "Log" : "Verify"} duty.`);
    }
  };

  // Reset all duties back to deterministic week schedule
  const handleResetAll = () => {
    if (activeSubTab === "snacks") {
      saveDuties({});
      showToast("Reset all class snack duties to standard weekly rotations.");
    } else {
      saveHomeworkDuties({});
      showToast("Reset all class homework writer duties to standard weekly rotations.");
    }
  };

  const homeroomMapping: Record<string, string> = {
    "yeng chhaily": "Grade 9",
    "helga joshua": "Grade 10",
    "hang sokcha": "Grade 11",
    "walker hedgepath": "Grade 12"
  };

  // Search and selector filters
  const filteredClassLevels = sortedClassLevels.filter((lvl) => {
    if (!isTeacher) {
      const userGrade = currentUser?.grade || "Grade 12";
      return lvl.toLowerCase() === userGrade.toLowerCase();
    }
    
    // Logic for teacher
    const teacherName = currentUser?.displayName?.toLowerCase() || "";
    const assignedGrade = homeroomMapping[teacherName];
    
    // Only show the grade assigned to the homeroom teacher
    if (assignedGrade) {
      if (lvl.toLowerCase() !== assignedGrade.toLowerCase()) {
        return false;
      }
    } else {
      // If they are not a homeroom teacher, they shouldn't see any schedules
      return false;
    }

    const matchesQuery = lvl.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGrade = selectedGradeFilter === "all" || lvl.toLowerCase().includes(selectedGradeFilter.toLowerCase());
    return matchesQuery && matchesGrade;
  });

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50/50">
      {/* Toast alert banner */}
      {toastMessage && (
        <div className="fixed top-24 right-6 z-50 bg-slate-900 border border-slate-700 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-semibold animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="p-6 md:p-8 max-w-6xl mx-auto w-full space-y-8">
        {/* Banner with controls */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div>
            <div className="flex items-center gap-2.5">
              {activeSubTab === "snacks" ? (
                <span className="p-2.5 bg-amber-50 rounded-xl text-amber-600 border border-amber-100">
                  <Coffee className="w-5 h-5" />
                </span>
              ) : (
                <span className="p-2.5 bg-indigo-50 rounded-xl text-indigo-600 border border-indigo-100">
                  <Pencil className="w-5 h-5" />
                </span>
              )}
              <div>
                <h2 className="text-xl font-extrabold text-slate-800 tracking-tight">
                  {activeSubTab === "snacks" ? "Class Snack Rotation Schedule" : "Class Homework Writer Schedule"}
                </h2>
                <p className="text-[12px] text-slate-500 mt-0.5 font-medium leading-relaxed">
                  {activeSubTab === "snacks" ? (
                    "Daily snack schedule assigned by grade level. Each class appoints two students to go get the snacks at the end of the day, and two students to return containers. All four students belong to the same class."
                  ) : (
                    "Daily homework logging schedule assigned by grade level. Each class appoints two homework loggers to write assignments on the board, and two reviewers to verify class instructions."
                  )}
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5 self-stretch md:self-auto justify-end">
            {isTeacher ? (
              <button
                onClick={handleResetAll}
                id="reset-snack-schedule-btn"
                className="px-3.5 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200/80 active:bg-slate-200 border border-slate-200 rounded-xl transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset All
              </button>
            ) : (
              activeSubTab === "snacks" ? (
                <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 px-3.5 py-1.5 rounded-xl shadow-3xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                  <span className="text-xs font-extrabold text-amber-700 uppercase tracking-wider">
                    {currentUser?.grade || "Grade 12"} Dashboard
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2 bg-indigo-50 border border-indigo-200 px-3.5 py-1.5 rounded-xl shadow-3xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
                  <span className="text-xs font-extrabold text-indigo-700 uppercase tracking-wider">
                    {currentUser?.grade || "Grade 12"} Dashboard
                  </span>
                </div>
              )
            )}
          </div>
        </div>

        {/* Navigation Tabs between Snack Duty and Homework Writer Duty */}
        <div id="duty-type-tabs" className="flex border-b border-slate-200 gap-6 bg-white p-4 rounded-xl border border-slate-100 shadow-3xs">
          <button
            onClick={() => setActiveSubTab("snacks")}
            id="subtab-snacks-btn"
            className={`pb-2.5 text-xs font-black uppercase tracking-wider transition relative flex items-center gap-2 cursor-pointer ${
              activeSubTab === "snacks"
                ? "text-amber-600 border-b-2 border-amber-600"
                : "text-slate-400 hover:text-slate-600"
            }`}
          >
            <Coffee className="w-4 h-4" />
            Snack Rotation Duty
          </button>
          <button
            onClick={() => setActiveSubTab("homework")}
            id="subtab-homework-btn"
            className={`pb-2.5 text-xs font-black uppercase tracking-wider transition relative flex items-center gap-2 cursor-pointer ${
              activeSubTab === "homework"
                ? "text-indigo-600 border-b-2 border-indigo-600"
                : "text-slate-400 hover:text-slate-600"
            }`}
          >
            <Pencil className="w-4 h-4" />
            Homework Writer Duty
          </button>
        </div>

        {/* Filters and search bar */}
        {isTeacher && (
          <div className="flex flex-col sm:flex-row gap-3 py-1">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                id="snack-schedule-search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search grade level (e.g. Grade 9, Grade 12)..."
                className={`w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium placeholder:text-slate-400 outline-none text-slate-700 transition focus:ring-2 ${
                  activeSubTab === "snacks" ? "focus:ring-amber-500 focus:border-amber-500" : "focus:ring-indigo-500 focus:border-indigo-500"
                }`}
              />
            </div>

            <div className="flex items-center gap-2 bg-white px-3 py-1.5 border border-slate-200 rounded-xl">
              <span className="text-[10px] text-slate-400 font-extrabold uppercase shrink-0">Grade Level</span>
              <select
                id="snack-grade-filter-select"
                value={selectedGradeFilter}
                onChange={(e) => setSelectedGradeFilter(e.target.value)}
                className="bg-transparent border-none text-xs font-bold text-slate-700 outline-none focus:ring-0 cursor-pointer pr-4"
              >
                <option value="all">All Grades</option>
                <option value="grade 9">Grade 9</option>
                <option value="grade 10">Grade 10</option>
                <option value="grade 11">Grade 11</option>
                <option value="grade 12">Grade 12</option>
              </select>
            </div>
          </div>
        )}

        {/* Dynamic Class Level Duty cards */}
        <div className={`grid gap-6 ${isTeacher ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-2" : "grid-cols-1 max-w-xl mx-auto w-full"}`}>
          {filteredClassLevels.map((classLevel) => {
            const duty = activeSubTab === "snacks" ? getSnackDutyForClassLevel(classLevel) : getHomeworkDutyForClassLevel(classLevel);
            const eligibleStudents = getStudentsForClassLevel(classLevel);

            return (
              <div
                key={classLevel}
                id={`${activeSubTab}-card-${classLevel.toLowerCase().replace(/\s+/g, "-")}`}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col hover:shadow-md transition-all group duration-200"
              >
                {/* Header highlighting class level name */}
                <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center gap-3">
                  <div>
                    <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${activeSubTab === "snacks" ? "bg-amber-500" : "bg-indigo-500"}`} />
                      {classLevel}
                      {!isTeacher && (
                        <span className="ml-2.5 px-2 py-0.5 text-[9px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-full tracking-wider uppercase">
                          My Class
                        </span>
                      )}
                    </h3>
                    <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                      {eligibleStudents.length} Students Available in Class
                    </p>
                  </div>

                  {isTeacher && (
                    <button
                      onClick={() => handleRotate(classLevel)}
                      id={`rotate-${classLevel.toLowerCase().replace(/\s+/g, "-")}-btn`}
                      title={activeSubTab === "snacks" ? "Randomly rotate snack duties" : "Randomly rotate homework writer duties"}
                      className={`p-1.5 border border-transparent rounded-lg transition-all cursor-pointer ${
                        activeSubTab === "snacks"
                          ? "text-slate-400 hover:text-amber-600 hover:bg-amber-50 hover:border-amber-100"
                          : "text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-100"
                      }`}
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="p-5 flex-1 flex flex-col space-y-5">
                  {/* Duties Sections */}
                  <div className="space-y-4 pt-1 flex-1">
                    {/* Primary Duty Section */}
                    {activeSubTab === "snacks" ? (
                      <div className="bg-amber-50/40 border border-amber-100/50 rounded-xl p-3.5 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Utensils className="w-3.5 h-3.5 text-amber-600" />
                            <span className="text-[11px] font-extrabold text-amber-800 uppercase tracking-wider">Go Get Snacks at End of Day (2)</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {duty.pickUp.map((studentName, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <span className="text-[11px] font-bold text-amber-700 bg-amber-100/30 w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                                {i + 1}
                              </span>
                              {isTeacher ? (
                                <select
                                  value={eligibleStudents.some(s => s.name === studentName) ? studentName : ""}
                                  onChange={(e) => handleAssignIndividual(classLevel, "pickUp", i, e.target.value)}
                                  className="w-full bg-white/75 hover:bg-white border border-amber-200/50 hover:border-amber-200 rounded-lg px-2 py-1 text-xs font-semibold text-slate-700 outline-none transition cursor-pointer"
                                >
                                  <option value="" disabled>Select Student...</option>
                                  {eligibleStudents.map((s) => (
                                    <option key={s.name} value={s.name}>
                                      {s.name}
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <div className="w-full bg-white border border-amber-100/55 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-700 flex items-center justify-between">
                                  <span>{studentName}</span>
                                  <span className="text-[9px] text-amber-600 font-extrabold uppercase tracking-wider bg-amber-50 px-1.5 py-0.5 rounded">
                                    Assigned
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="bg-indigo-50/40 border border-indigo-100/50 rounded-xl p-3.5 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Pencil className="w-3.5 h-3.5 text-indigo-600" />
                            <span className="text-[11px] font-extrabold text-indigo-800 uppercase tracking-wider">Primary Homework Loggers (2)</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {duty.pickUp.map((studentName, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <span className="text-[11px] font-bold text-indigo-700 bg-indigo-100/30 w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                                {i + 1}
                              </span>
                              {isTeacher ? (
                                <select
                                  value={eligibleStudents.some(s => s.name === studentName) ? studentName : ""}
                                  onChange={(e) => handleAssignIndividual(classLevel, "pickUp", i, e.target.value)}
                                  className="w-full bg-white/75 hover:bg-white border border-indigo-200/50 hover:border-indigo-200 rounded-lg px-2 py-1 text-xs font-semibold text-slate-700 outline-none transition cursor-pointer"
                                >
                                  <option value="" disabled>Select Student...</option>
                                  {eligibleStudents.map((s) => (
                                    <option key={s.name} value={s.name}>
                                      {s.name}
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <div className="w-full bg-white border border-indigo-100/55 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-700 flex items-center justify-between">
                                  <span>{studentName}</span>
                                  <span className="text-[9px] text-indigo-600 font-extrabold uppercase tracking-wider bg-indigo-50 px-1.5 py-0.5 rounded">
                                    Assigned
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Secondary Duty Section */}
                    {activeSubTab === "snacks" ? (
                      <div className="bg-emerald-50/40 border border-emerald-100/50 rounded-xl p-3.5 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-[11px] font-extrabold text-emerald-800 uppercase tracking-wider">Return Containers Back (2)</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {duty.returnBack.map((studentName, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100/30 w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                                {i + 1}
                              </span>
                              {isTeacher ? (
                                <select
                                  value={eligibleStudents.some(s => s.name === studentName) ? studentName : ""}
                                  onChange={(e) => handleAssignIndividual(classLevel, "returnBack", i, e.target.value)}
                                  className="w-full bg-white/75 hover:bg-white border border-emerald-200/50 hover:border-emerald-200 rounded-lg px-2 py-1 text-xs font-semibold text-slate-700 outline-none transition cursor-pointer"
                                >
                                  <option value="" disabled>Select Student...</option>
                                  {eligibleStudents.map((s) => (
                                    <option key={s.name} value={s.name}>
                                      {s.name}
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <div className="w-full bg-white border border-emerald-100/55 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-700 flex items-center justify-between">
                                  <span>{studentName}</span>
                                  <span className="text-[9px] text-emerald-600 font-extrabold uppercase tracking-wider bg-emerald-50 px-1.5 py-0.5 rounded">
                                    Assigned
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="bg-violet-50/40 border border-violet-100/50 rounded-xl p-3.5 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <UserCheck className="w-3.5 h-3.5 text-violet-600" />
                            <span className="text-[11px] font-extrabold text-violet-800 uppercase tracking-wider">Homework Verify & Review (2)</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {duty.returnBack.map((studentName, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <span className="text-[11px] font-bold text-violet-700 bg-violet-100/30 w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                                {i + 1}
                              </span>
                              {isTeacher ? (
                                <select
                                  value={eligibleStudents.some(s => s.name === studentName) ? studentName : ""}
                                  onChange={(e) => handleAssignIndividual(classLevel, "returnBack", i, e.target.value)}
                                  className="w-full bg-white/75 hover:bg-white border border-violet-200/50 hover:border-violet-200 rounded-lg px-2 py-1 text-xs font-semibold text-slate-700 outline-none transition cursor-pointer"
                                >
                                  <option value="" disabled>Select Student...</option>
                                  {eligibleStudents.map((s) => (
                                    <option key={s.name} value={s.name}>
                                      {s.name}
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <div className="w-full bg-white border border-violet-100/55 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-700 flex items-center justify-between">
                                  <span>{studentName}</span>
                                  <span className="text-[9px] text-violet-600 font-extrabold uppercase tracking-wider bg-violet-50 px-1.5 py-0.5 rounded">
                                    Assigned
                                  </span>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filteredClassLevels.length === 0 && (
          <div className="text-center py-24 bg-white rounded-2xl border border-slate-200 border-dashed">
            <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-sm font-bold text-slate-700">No Class Levels Found</h3>
            <p className="text-xs text-slate-500 mt-1">Try resetting the filters or check your active courses on the sidebar.</p>
          </div>
        )}
      </div>
    </div>
  );
}
