import React from "react";
import { NotificationItem } from "../types";
import { Bell, Calendar, Award, CheckCircle2, AlertTriangle, RefreshCw, Trash2 } from "lucide-react";

interface NotificationsPanelProps {
  notifications: NotificationItem[];
  onClearAll: () => void;
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
}

export default function NotificationsPanel({
  notifications,
  onClearAll,
  onMarkAsRead,
  onMarkAllAsRead,
}: NotificationsPanelProps) {
  // Determine helper icon by type
  const getNotificationIcon = (type: NotificationItem["type"]) => {
    switch (type) {
      case "new":
        return (
          <div className="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
            <Calendar className="w-4.5 h-4.5" />
          </div>
        );
      case "graded":
        return (
          <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
            <Award className="w-4.5 h-4.5 animate-bounce" />
          </div>
        );
      case "due_soon":
        return (
          <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600 shrink-0">
            <AlertTriangle className="w-4.5 h-4.5 animate-pulse" />
          </div>
        );
      case "sync":
      default:
        return (
          <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shrink-0">
            <RefreshCw className="w-4.5 h-4.5" />
          </div>
        );
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-xs max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-50 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-indigo-500" />
          <h3 className="font-bold text-slate-800 text-sm md:text-base">Realtime Activity Feed</h3>
        </div>
        
        <div className="flex items-center gap-2">
          {notifications.some(n => !n.read) && (
            <button
              id="btn-mark-all-read"
              onClick={onMarkAllAsRead}
              className="flex items-center gap-1.5 text-slate-500 hover:text-indigo-600 text-xs font-bold px-2.5 py-1.5 hover:bg-indigo-50/50 rounded-lg transition"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Mark all read
            </button>
          )}

          {notifications.length > 0 && (
            <button
              id="btn-clear-notifications"
              onClick={onClearAll}
              className="flex items-center gap-1 text-slate-500 hover:text-rose-600 text-xs font-bold px-2 py-1.5 hover:bg-slate-50 rounded-lg transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear Feed
            </button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
        {notifications.length > 0 ? (
          notifications.map((notif) => (
            <div
              id={`notification-item-${notif.id}`}
              key={notif.id}
              onClick={() => {
                if (!notif.read) {
                  onMarkAsRead(notif.id);
                }
              }}
              className={`flex items-start gap-4 p-3.5 rounded-xl transition duration-150 relative cursor-pointer ${
                !notif.read
                  ? "bg-slate-50/70 border-l-3 border-indigo-500 pl-3 hover:bg-indigo-50/30"
                  : "hover:bg-slate-50"
              }`}
            >
              {getNotificationIcon(notif.type)}

              <div className="flex-1 min-w-0 pr-4">
                <p className={`text-xs md:text-sm leading-tight pr-4 ${!notif.read ? "text-indigo-950 font-bold" : "text-slate-700 font-semibold"}`}>
                  {notif.message}
                </p>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-[10px] text-slate-400 font-semibold tracking-tight uppercase">
                    Automatic Update
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-350" />
                  <span id={`notif-time-${notif.id}`} className="text-[10px] text-slate-400 font-medium">
                    {formatTime(notif.timestamp)}
                  </span>
                </div>
              </div>

              {!notif.read && (
                <div
                  id={`notif-unread-spot-${notif.id}`}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-rose-500 animate-pulse shrink-0"
                  title="Unread notification"
                />
              )}
            </div>
          ))
        ) : (
          <div className="text-center py-12">
            <Bell className="w-10 h-10 text-slate-350 mx-auto mb-2" />
            <p className="text-slate-600 font-bold text-xs">No Recent Classroom Activity</p>
            <p className="text-[10px] text-slate-450 mt-1 max-w-xs mx-auto leading-relaxed">
              Automatic events, such as posted coursework, homework completions, and assigned scores from Google Classroom, will register alerts in this feed.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
