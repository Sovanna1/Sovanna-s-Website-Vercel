import React, { useState } from "react";
import { Settings, ShieldAlert, Sparkles, RefreshCw, HelpCircle, LogOut, User, Landmark, Trash2, Key, Check, Eye, EyeOff } from "lucide-react";
import { SyncConfig } from "../types";
import { studentsList } from "../studentsData";
import { teachersList } from "../teachersData";

interface SettingsViewProps {
  syncConfig: SyncConfig;
  onUpdateSyncConfig: (config: SyncConfig) => void;
  onLogoutLive?: () => void;
  currentUser?: any;
  googleUser?: any;
  googleToken?: string | null;
  onGoogleSignIn?: () => void;
  onGoogleSignOut?: () => void;
}

export default function SettingsView({
  syncConfig,
  onUpdateSyncConfig,
  onLogoutLive,
  currentUser,
  googleUser,
  googleToken,
  onGoogleSignIn,
  onGoogleSignOut,
}: SettingsViewProps) {
  const [resetStatus, setResetStatus] = useState<"idle" | "resetting" | "done">("idle");
  
  // Custom Google Client ID State
  const [customClientId, setCustomClientId] = useState(() => {
    return localStorage.getItem("custom_google_client_id") || "";
  });
  
  // Password State
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordSuccess, setPasswordSuccess] = useState<string | null>(null);

  const isTeacher = currentUser?.role === "teacher";

  const handleResetData = () => {
    if (!currentUser) return;
    if (confirm("Reset account data? This will restore the default simulated high-school courses and coursework, clearing your custom changes.")) {
      setResetStatus("resetting");
      setTimeout(() => {
        // Clear student-specific localStorage keys and reload the portal
        localStorage.removeItem(`student_courses_${currentUser.email}`);
        localStorage.removeItem(`student_assignments_${currentUser.email}`);
        localStorage.removeItem(`student_notifications_${currentUser.email}`);
        localStorage.removeItem(`student_contacts_${currentUser.email}`);
        localStorage.removeItem(`student_sync_config_${currentUser.email}`);
        if (isTeacher) {
          localStorage.removeItem(`teacher_pwd_${currentUser.uid}`);
        } else {
          localStorage.removeItem(`student_pwd_${currentUser.displayName}`);
        }
        setResetStatus("done");
        window.location.reload();
      }, 800);
    }
  };

  const handlePasswordChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    setPasswordSuccess(null);

    const currTrimmed = currentPassword.trim();
    const newTrimmed = newPassword.trim();

    if (!currTrimmed || !newTrimmed) {
      setPasswordError("Both current and new password fields are required.");
      return;
    }

    if (newTrimmed.length < 4) {
      setPasswordError("New password must be at least 4 characters.");
      return;
    }

    if (isTeacher) {
      const storedPassword = localStorage.getItem(`teacher_pwd_${currentUser.uid}`) || "12345";
      if (storedPassword !== currTrimmed) {
        setPasswordError("Incorrect current password.");
        return;
      }
      localStorage.setItem(`teacher_pwd_${currentUser.uid}`, newTrimmed);
    } else {
      const matchedStudent = studentsList.find(s => s.name.toLowerCase() === currentUser?.displayName?.toLowerCase());
      const defaultPwd = matchedStudent ? matchedStudent.password : "12345";
      const storedPassword = localStorage.getItem(`student_pwd_${currentUser.displayName}`) || defaultPwd;
      if (storedPassword !== currTrimmed) {
        setPasswordError("Incorrect current password.");
        return;
      }
      localStorage.setItem(`student_pwd_${currentUser.displayName}`, newTrimmed);
    }

    setPasswordSuccess("Your portal access password has been updated successfully!");
    setCurrentPassword("");
    setNewPassword("");
  };

  const matchedStudent = studentsList.find(s => s.name.toLowerCase() === currentUser?.displayName?.toLowerCase());
  const matchedTeacher = teachersList.find(t => t.id === currentUser?.uid);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Key Settings Config */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Profile Overview Card */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-xs">
            <h3 className="font-bold text-slate-800 text-sm mb-4 flex items-center gap-2">
              <User className="w-4 h-4 text-indigo-600" />
              {isTeacher ? "Faculty Roster Profile" : "Student Registry Profile"}
            </h3>
            
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 mb-4">
              <div className="space-y-1">
                <p className="text-xs font-black uppercase text-indigo-600 tracking-wider">Currently Logged In</p>
                <h4 className="text-base font-black text-slate-800 leading-tight">{currentUser?.displayName || "User"}</h4>
                <p className="text-[11px] font-mono text-slate-500">{currentUser?.email}</p>
                {isTeacher && matchedTeacher && (
                  <p className="text-xs text-slate-500 font-semibold italic mt-1">{matchedTeacher.title}</p>
                )}
              </div>

              {!isTeacher && matchedStudent && (
                <div className="bg-indigo-100/50 border border-indigo-200 rounded-xl px-3.5 py-1.5 text-center shrink-0">
                  <span className="block text-[8px] font-extrabold uppercase text-indigo-500 tracking-widest">Enrolled Level</span>
                  <span className="text-xs font-black text-indigo-800">{matchedStudent.grade}</span>
                </div>
              )}

              {isTeacher && (
                <div className="bg-emerald-100/50 border border-emerald-200 rounded-xl px-3.5 py-1.5 text-center shrink-0">
                  <span className="block text-[8px] font-extrabold uppercase text-emerald-600 tracking-widest">Portal Role</span>
                  <span className="text-xs font-black text-emerald-800">Faculty/Staff</span>
                </div>
              )}
            </div>

            <p className="text-xs text-slate-500 leading-normal mb-1.5 font-medium">
              You are signed in to the Classroom Portal. Your local completed items and coursework alterations are cached directly inside your browser's persistent sandbox.
            </p>
          </div>

          {/* Google Classroom Connection Card */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-xs">
            <h3 className="font-bold text-slate-800 text-sm mb-1 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-500" />
              Google Classroom Workspace Connection
            </h3>
            <p className="text-[11px] text-slate-500 mb-4 font-semibold">
              Force sync and query actual Classrooms, Coursework assignments, Instructors, and Streams directly on Google's cloud servers!
            </p>

            <div className="space-y-4">
              <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div>
                    <h4 className="font-bold text-slate-700 text-xs">Active Workspace Connection:</h4>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {googleToken ? `Synchronized to Google (${googleUser?.email || "classroom@google.com"})` : "Currently operating in offline Simulated JPA mode."}
                    </p>
                  </div>
                  {googleToken ? (
                    <button
                      id="btn-disconnect-google-settings"
                      type="button"
                      onClick={onGoogleSignOut}
                      className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-extrabold rounded-lg text-xs transition shrink-0"
                    >
                      Disconnect Google Link
                    </button>
                  ) : (
                    <button
                      id="btn-connect-google-settings"
                      type="button"
                      onClick={onGoogleSignIn}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-lg text-xs transition shadow-sm shrink-0"
                    >
                      Connect Google Classroom
                    </button>
                  )}
                </div>

                {googleToken && (
                  <div className="pt-2.5 border-t border-slate-200">
                    <span className="block text-[8px] font-extrabold uppercase text-slate-400 tracking-wider">In-Memory Security Token</span>
                    <p className="text-[10px] font-mono text-emerald-600 font-extrabold truncate mt-0.5">
                      Bearer {googleToken.substring(0, 20)}... [Active Authentication Approved]
                    </p>
                  </div>
                )}
              </div>

              {/* Developer Client ID overrides */}
              <div className="space-y-2">
                <label className="block text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">
                  Override Developer Client ID (OAuth Settings)
                </label>
                <div className="flex gap-2">
                  <input
                    id="custom-client-id-input"
                    type="text"
                    placeholder="e.g. 1234567-abcdefg.apps.googleusercontent.com"
                    value={customClientId}
                    onChange={(e) => {
                      setCustomClientId(e.target.value);
                      localStorage.setItem("custom_google_client_id", e.target.value);
                    }}
                    className="flex-1 text-xs p-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 bg-slate-50/10 font-mono"
                  />
                  {customClientId && (
                    <button
                      id="btn-clear-client-id"
                      type="button"
                      onClick={() => {
                        setCustomClientId("");
                        localStorage.removeItem("custom_google_client_id");
                      }}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-205 text-slate-600 rounded-lg text-xs font-bold shrink-0"
                    >
                      Clear
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 font-semibold leading-normal">
                  Normally, AI Studio's default OAuth settings and allowed redirection endpoints are utilized. If you get credential warnings, override them above.
                </p>
              </div>
            </div>
          </div>

          {/* Change Password Card */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-xs">
            <h3 className="font-bold text-slate-800 text-sm mb-4 flex items-center gap-2">
              <Key className="w-4 h-4 text-slate-500" />
              Change Login Password
            </h3>

            <form onSubmit={handlePasswordChangeSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    Current Password
                  </label>
                  <div className="relative">
                    <input
                      id="input-current-password"
                      type={showCurrentPassword ? "text" : "password"}
                      placeholder="Enter current password"
                      value={currentPassword}
                      onChange={(e) => {
                        setCurrentPassword(e.target.value);
                        setPasswordError(null);
                        setPasswordSuccess(null);
                      }}
                      className="w-full text-xs p-3 pr-10 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 bg-slate-50/10"
                      required
                    />
                    <button
                      id="btn-toggle-current-password"
                      type="button"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600 focus:outline-hidden"
                    >
                      {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                    New Password
                  </label>
                  <div className="relative">
                    <input
                      id="input-new-password"
                      type={showNewPassword ? "text" : "password"}
                      placeholder="Enter new password"
                      value={newPassword}
                      onChange={(e) => {
                        setNewPassword(e.target.value);
                        setPasswordError(null);
                        setPasswordSuccess(null);
                      }}
                      className="w-full text-xs p-3 pr-10 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-150 bg-slate-50/10"
                      required
                    />
                    <button
                      id="btn-toggle-new-password"
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600 focus:outline-hidden"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {passwordError && (
                <p className="text-xs font-bold text-rose-600 bg-rose-50 p-2.5 rounded-lg border border-rose-105">
                  ⚠️ {passwordError}
                </p>
              )}

              {passwordSuccess && (
                <p className="text-xs font-bold text-emerald-700 bg-emerald-50 p-2.5 rounded-lg border border-emerald-105 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{passwordSuccess}</span>
                </p>
              )}

              <button
                id="btn-save-password-settings"
                type="submit"
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-extrabold rounded-xl text-xs transition"
              >
                Update Password
              </button>
            </form>
          </div>

          {/* Sync Preferences Card */}
          <div className="bg-white rounded-xl border border-slate-100 p-5 shadow-xs">
            <h3 className="font-bold text-slate-800 text-sm mb-4 flex items-center gap-2">
              <Settings className="w-4 h-4 text-slate-500" />
              Ecosystem Preferences
            </h3>

            <div className="space-y-4">
              {/* Toggle Auto Sync */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-lg">
                <div>
                  <h4 className="font-bold text-slate-700 text-xs">Simulated Classroom Sync Loop</h4>
                  <p className="text-[10px] text-slate-450 mt-0.5 leading-tight">
                    Periodically request automated grades and homework postings.
                  </p>
                </div>
                <button
                  id="btn-settings-toggle-autosync"
                  onClick={() => onUpdateSyncConfig({ ...syncConfig, autoSync: !syncConfig.autoSync })}
                  className={`w-12 h-6.5 rounded-full p-1 transition duration-250 shrink-0 ${
                    syncConfig.autoSync ? "bg-indigo-600" : "bg-slate-350"
                  }`}
                >
                  <div
                    className={`w-4.5 h-4.5 bg-white rounded-full shadow-md transform transition duration-250 ${
                      syncConfig.autoSync ? "translate-x-5.5" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>

              {/* Set interval */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-lg">
                <div>
                  <h4 className="font-bold text-slate-700 text-xs">Simulated Sync Interval</h4>
                  <p className="text-[10px] text-slate-450 mt-0.5 leading-tight">
                    Frequency for checking mock grade-changes and postings.
                  </p>
                </div>
                <select
                  id="select-settings-interval"
                  value={syncConfig.intervalSec}
                  onChange={(e) => onUpdateSyncConfig({ ...syncConfig, intervalSec: Number(e.target.value) })}
                  className="bg-white border border-slate-200 text-slate-700 text-xs rounded-lg p-2 font-semibold focus:ring-1 focus:ring-indigo-500"
                >
                  <option value={15}>15 seconds</option>
                  <option value={30}>30 seconds</option>
                  <option value={60}>1 minute</option>
                  <option value={300}>5 minutes</option>
                </select>
              </div>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="bg-rose-50/50 border border-rose-100 rounded-xl p-5">
            <h3 className="font-bold text-rose-800 text-sm mb-1.5 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600" />
              Administrative Actions
            </h3>
            <p className="text-xs text-rose-700 mb-4 font-semibold">
              These procedures clear your custom homework board submissions and roster state structures.
            </p>

            <div className="flex flex-wrap gap-3">
              <button
                id="btn-settings-reset-cache-data"
                onClick={handleResetData}
                disabled={resetStatus === "resetting"}
                className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-rose-50 border border-slate-200 text-rose-700 font-bold rounded-lg text-xs transition disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{resetStatus === "resetting" ? "Resetting Data..." : "Reset Sandbox Portfolios"}</span>
              </button>

              {onLogoutLive && (
                <button
                   id="btn-settings-logout"
                  onClick={onLogoutLive}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition shadow-sm"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Log Out Session</span>
                </button>
              )}
            </div>
          </div>

        </div>

        {/* Right column: Info & Notice */}
        <div className="lg:col-span-1">
          <div className="bg-slate-900 text-white rounded-xl p-5 shadow-xs sticky top-4 space-y-4">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Landmark className="w-4 h-4 text-indigo-400" />
              {isTeacher ? "Faculty Hub" : "Student Hub"}
            </h3>

            <div className="space-y-3.5 text-xs font-medium text-slate-300 leading-relaxed">
              <p>
                {isTeacher
                  ? "Welcome to the school faculty dashboard. You represent an essential part of active coordination, grading, and curriculum synchronization."
                  : "Welcome to your offline ecosystem! Your credentials connect securely to your student profile directory:"
                }
              </p>

              <div className="bg-slate-850 p-3.5 rounded-xl border border-slate-800 text-[11px] leading-relaxed space-y-2 text-indigo-300">
                <p>💡 <strong className="text-white">Active Simulation:</strong> The sync timer simulates active teacher behaviors like homework markings, and new assignments postings.</p>
                <p>📝 <strong className="text-white">No External APIs:</strong> Your workspace remains 100% private, with zero remote servers.</p>
              </div>

              <div className="pt-2 border-t border-slate-800 font-bold">
                <span className="text-[10px] text-slate-500 font-extrabold uppercase">Ecosystem Target</span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {isTeacher ? "Multi-Grade Teacher & Staff Console" : "Student Academic Portfolios"}
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
