import React, { useState, useRef, useEffect, useMemo } from 'react';
import Globe from 'react-globe.gl';
import { Search, X, MapPin, GraduationCap, Users, Compass, Laptop, Info, RefreshCw, Sparkles, Globe as GlobeIcon, ListFilter, ArrowLeft, BarChart3, PieChart } from 'lucide-react';
import { schools as fallbackSchools, alumni as fallbackAlumni, School, Alumnus } from '../alumniData';

// Import high-fidelity JPA Blue branding assets
import jpaLogoBlue from '../assets/images/jpa_logo_blue_1782184515408.jpg';
import jpaLogoV2 from '../assets/images/jpa_logo_v2_1782185298497.jpg';

const ALUMNI_API = "https://script.google.com/macros/s/AKfycby7UOEdR38eu4EVQ60PxrqV2X7ooU9IcfRkIQDTenYlr4omGexr4AoQeBT6dPz0Dmp1/exec";
const DESCRIPTION_API = "https://script.google.com/macros/s/AKfycbwvDSsr7K9YddwFv0HUPu_uqiWDzChIPtxz3gbostiWpmDZ47jc4pUefgGsPGsg9tAr/exec";

const generateSchoolId = (name: string): string => {
  const clean = name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

  const SCHOOL_ID_MAP: Record<string, string> = {
    "apiu": "asia-pacific-international-university",
    "auw": "asian-university-for-women",
    "sustech": "southern-university-of-science-and-technology",
    "btec": "battambang-teacher-education-college",
    "rupp": "royal-university-of-phnom-penh",
    "uhs": "university-of-health-sciences",
    "ifl": "institute-of-foreign-languages",
    "cadt": "cambodia-academy-of-digital-technology",
    "npia": "national-polytechnic-institute-of-angkor",
    "itc": "institute-of-technology-of-cambodia",
    "nubb": "national-university-of-battambang",
    "usea": "university-of-south-east-asia",
    "angkor": "angkor",
    "asia-pacific-international": "asia-pacific-international-university",
    "asian-women": "asian-university-for-women",
    "puc": "pannasastra-university-of-cambodia",
    "ute": "university-of-technology-and-entrepreneurship",
    "num": "national-university-of-management",
    "paragon": "paragon-international-university",
    "norton-university": "norton",
    "beloit-college": "beloit",
    "belong-college": "beloit",
    "middlebury": "middlebury-college",
    "colgate": "colgate-university",
    "dartmouth": "dartmouth-college",
    "pearson-college-united-world-college": "pearson-college-uwc",
    "united-world-college-south-east-asia": "uwc-south-east-asia",
    "university-of-health-and-science": "university-of-health-sciences",
    "university-of-health-and-sciences": "university-of-health-sciences",
    "institutes-of-technology-of-cambodia": "institute-of-technology-of-cambodia",
    "institutes-of-technology-of-cambodge": "institute-of-technology-of-cambodia",
    "institute-of-technology-of-cambodge": "institute-of-technology-of-cambodia",
    "elon-university": "elon",
    "diablo-valley-college": "diablo-valley",
    "gettysburg-college": "gettysburg",
    "emma-willard-school": "emma-willard",
    "phillips-academy-andover": "phillips-andover",
    "phillips-exeter-academy": "phillips-exeter",
    "the-bishop-strachan-school": "bishop-strachen",
    "the-bishop-strachen-school": "bishop-strachen",
    "lafayette-college": "lafayette",
    "webster-university": "webster",
    "yale-national-university-of-singapore": "yale-nus",
    "thammasat-university": "thammasat",
    "annie-wright-school": "annie-wright",
    "hollins-university": "hollins",
    "babson-college": "babson",
    "assumption-university": "assumption",
    "culver-university": "culver",
    "culver-academies": "culver",
    "union-university": "union",
    "union-college": "union",
    "st-joseph-s-institution": "sji",
    "united-world-college-changshu": "uwc-changshu",
    "chiang-mai-university": "chiang-mai",
    "chulalongkorn-university": "chulalongkorn",
    "limkokwing-university": "limkokwing",
    "angkor-university": "angkor",
    "stamford": "stamford-international-university",
    "stamford-uni": "stamford-international-university",
    "stamford-university": "stamford-international-university"
  };

  return SCHOOL_ID_MAP[clean] || clean;
};

// A direct, comprehensive dictionary of gorgeous real campus photorealistic images for ALL universities in schools list
const REAL_CAMPUS_IMAGES: Record<string, string> = {
  "elon": "https://images.unsplash.com/photo-1620325867502-221cfb5fc5f7?auto=format&fit=crop&q=80&w=850",
  "wabash-college": "https://images.unsplash.com/photo-1592185152242-4917540960bc?auto=format&fit=crop&q=80&w=850",
  "diablo-valley": "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=850",
  "webster": "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?auto=format&fit=crop&q=80&w=850",
  "university-of-florida": "https://images.unsplash.com/photo-1592185152242-4917540960bc?auto=format&fit=crop&q=80&w=850",
  "the-university-of-hong-kong": "https://images.unsplash.com/photo-1581362072978-24998decfe17?auto=format&fit=crop&q=80&w=850",
  "new-york-university-of-abu-dhabi": "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=850",
  "colgate-university": "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&q=80&w=850",
  "dartmouth": "https://images.unsplash.com/photo-1532649538693-f3a2ec1bf8bd?auto=format&fit=crop&q=80&w=850",
  "bucknell-university": "https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?auto=format&fit=crop&q=80&w=850",
  "bryn-mawr-college": "https://images.unsplash.com/photo-1498243691581-b145c3f54a5c?auto=format&fit=crop&q=80&w=850",
  "reed-college": "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=850",
  "lehigh-university": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=850",
  "claremont-mckenna-college": "https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?auto=format&fit=crop&q=80&w=850",
  "the-university-of-chicago": "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=850",
  "berea-college": "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=850",
  "middlebury": "https://images.unsplash.com/photo-1513829096990-2bb9ca272895?auto=format&fit=crop&q=80&w=850",
  "rhodes-college": "https://images.unsplash.com/photo-1527891751199-7225231a68dd?auto=format&fit=crop&q=80&w=850",
  "scripps-college": "https://images.unsplash.com/photo-1535930891776-0c2dfb7fda1a?auto=format&fit=crop&q=80&w=850",
  "massachusetts-institute-of-technology": "https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?auto=format&fit=crop&q=80&w=850",
  "whitman-college": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=850",
  "kenyon-college": "https://images.unsplash.com/photo-1584697964400-2af6a2f6204c?auto=format&fit=crop&q=80&w=850",
  "harvard-university": "https://images.unsplash.com/photo-1564981797816-10434644e3d7?auto=format&fit=crop&q=80&w=850",
  "northwestern-university": "https://images.unsplash.com/photo-1568454537842-d933259bb258?auto=format&fit=crop&q=80&w=850",
  "american-university-of-phnom-penh": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "cambodia-university-of-technology-and-science": "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=850",
  "connecticut-college": "https://images.unsplash.com/photo-1492538368577-8789e905caee?auto=format&fit=crop&q=80&w=850",
  "pearson-college-uwc": "https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&q=80&w=850",
  "uwc-south-east-asia": "https://images.unsplash.com/photo-1553028826-f4804a6dba3b?auto=format&fit=crop&q=80&w=850",
  "aiglon-college": "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?auto=format&fit=crop&q=80&w=850",
  "gettysburg": "https://images.unsplash.com/photo-1525921808537-68c0835a519d?auto=format&fit=crop&q=80&w=850",
  "beloit": "https://images.unsplash.com/photo-1552581234-2612b77d59b2?auto=format&fit=crop&q=80&w=850",
  "emma-willard": "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?auto=format&fit=crop&q=80&w=850",
  "phillips-andover": "https://images.unsplash.com/photo-1492538368577-8789e905caee?auto=format&fit=crop&q=80&w=850",
  "phillips-exeter": "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=850",
  "bishop-strachen": "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=850",
  "lafayette": "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=850",
  "stamford-international-university": "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=850",
  "asia-pacific-international-university": "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=850",
  "yale-nus": "https://images.unsplash.com/photo-1564981797816-10434644e3d7?auto=format&fit=crop&q=80&w=850",
  "thammasat": "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&q=80&w=850",
  "annie-wright": "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?auto=format&fit=crop&q=80&w=850",
  "hollins": "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=850",
  "babson": "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=850",
  "asian-university-for-women": "https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&q=80&w=850",
  "westminster": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=850",
  "assumption": "https://images.unsplash.com/photo-1581362072978-24998decfe17?auto=format&fit=crop&q=80&w=850",
  "culver": "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=850",
  "union": "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?auto=format&fit=crop&q=80&w=850",
  "sji": "https://images.unsplash.com/photo-1516321497487-e2f19195357a?auto=format&fit=crop&q=80&w=850",
  "uwc-changshu": "https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&q=80&w=850",
  "southern-university-of-science-and-technology": "https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?auto=format&fit=crop&q=80&w=850",
  "chiang-mai": "https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&q=80&w=850",
  "chulalongkorn": "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&q=80&w=850",
  "stamford": "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=850",
  "leysin": "https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&q=80&w=850",
  "battambang-teacher-education-college": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "royal-university-of-phnom-penh": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "university-of-health-sciences": "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&q=80&w=850",
  "institute-of-foreign-languages": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "cambodia-academy-of-digital-technology": "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=850",
  "national-polytechnic-institute-of-angkor": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "institute-of-technology-of-cambodia": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "national-university-of-battambang": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "limkokwing": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=850",
  "angkor": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "norton": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=850",
  "university-of-south-east-asia": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&q=80&w=850",
  "pannasastra-university-of-cambodia": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=850",
  "university-of-technology-and-entrepreneurship": "https://images.unsplash.com/photo-1581362072978-24998decfe17?auto=format&fit=crop&q=80&w=850",
  "national-university-of-management": "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=850",
  "paragon-international-university": "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=850"
};

// Curated university timeline facts and landmarks to enrich academic exploration
const CAMPUS_TRIVIA: Record<string, string> = {
  "elon": "🌱 Elite private college in North Carolina, nationally recognized as a stunning showcase botanical garden with a quiet lakeside chapel.",
  "wabash-college": "🏛️ Wabash College is an exceptional traditional liberal arts academy for men, famed for its intense rhetoric debates and red-brick beauty.",
  "diablo-valley": "📐 Diablo Valley in California's Bay Area drives amazing university transfer paths into UC Berkeley with top-tier STEM academic results.",
  "webster": "🌍 Webster features a global campus network spanning across Saint Louis, Asia, and Europe, offering dynamic cross-border programs.",
  "university-of-florida": "🐊 Legendary Gator nation campus in sunny Gainesville featuring high-impact engineering labs and championship athletic history.",
  "the-university-of-hong-kong": "🇭🇰 High-tech global university. The HKU campus combines historic colonial brickwork, academic gardens, and modern skyscrapers.",
  "new-york-university-of-abu-dhabi": "🇦🇪 Modern campus with fully integrated global quads housing exceptional talent and leaders from over 115 different countries.",
  "colgate-university": "🏫 Classic liberal arts campus on a gorgeous New York hillside with beautiful traditional stone buildings and high academic prestige.",
  "dartmouth": "🌲 Classic Ivy League nestled in New Hampshire's wilderness. Highly revered for close faculty mentorship and vibrant outdoor leadership traditions.",
  "bucknell-university": "🏛️ Beautiful Pennsylvania campus overlooking the Susquehanna River, acclaimed for its powerful dual engineering and business tracks.",
  "bryn-mawr-college": "🏰 Elite historical women's college boasting splendid collegiate gothic architecture and amazing research achievements.",
  "reed-college": "🔬 Located in Portland, Oregon, Reed is famed for its rigorous intellectual curriculum and its scenic natural canyon and lake.",
  "lehigh-university": "🏗️ Famed for its beautiful mountainside campus in Pennsylvania, combining rigorous engineering studies with strong business legacies.",
  "claremont-mckenna-college": "📈 Elite member of the Claremont Colleges, heavily celebrated for leadership, political science, and strong financial economics.",
  "the-university-of-chicago": "🏰 Gothic quadrangles, intense intellectual culture, and a legendary core curriculum. Celebrates over 97 Nobel Laureates among associates.",
  "berea-college": "🤝 Famed tuition-free work college in Kentucky, pioneering high-impact inclusive education and traditional craftworks.",
  "middlebury": "❄️ Acclaimed for top-tier international studies and global language programs, nestled in Vermont's beautiful ski country.",
  "rhodes-college": "🏛️ Located in Memphis, Tennessee, Rhodes features spectacular 100% collegiate gothic limestone halls under towering oak trees.",
  "scripps-college": "🌸 Celebrated for its breathtaking Mediterranean style, olive groves, and powerful humanist arts curriculum for women.",
  "massachusetts-institute-of-technology": "🔬 Rated #1 globally for engineering and robotics, MIT is famous for its massive neo-classical Great Dome and avant-garde research labs.",
  "whitman-college": "🌲 Set in Walla Walla, Washington, Whitman is famous for rich creative writing programs and beautiful hiking expeditions.",
  "kenyon-college": "📝 Highly celebrated for its legendary english department and literary review, located on a beautiful wooded Ohio hilltop.",
  "harvard-university": "🎓 Harvard is the oldest Ivy League college in the US, famed for red-brick gates, Widener Library, and elite academic legacy.",
  "northwestern-university": "🎭 Northwestern blends high-impact journalism and drama with elite research resources, sitting on beautiful Lake Michigan shores.",
  "american-university-of-phnom-penh": "🇰🇭 Famed international academy in Phnom Penh, offering prestigious US-accredited dual degrees in business and technology.",
  "cambodia-university-of-technology-and-science": "🔬 Leading technological research hub focusing on high-impact AI models, robotic engineering, and creative business tools.",
  "connecticut-college": "⛵ Beautiful liberal arts college overlooking Long Island Sound, renowned for integrated pathways and environmental sciences.",
  "pearson-college-uwc": "🌲 Part of the United World Colleges, nestled in a pristine forest bay in Vancouver Island, bringing global peace builders together.",
  "uwc-south-east-asia": "🇸🇬 Elite international compound in Singapore driving advanced world peace studies, sustainability, and creative service leadership.",
  "aiglon-college": "🏔️ Prestigious boarding institute in the Swiss Alps, combining elite academic standards with rigorous mountain expeditions.",
  "gettysburg": "🎖️ Historical campus adjacent to the Gettysburg battlefield, celebrated for public leadership, politics, and civic engagement.",
  "beloit": "🏛️ Wisconsin's oldest college, famous for its hands-on anthropology museum and highly creative academic paths.",
  "emma-willard": "🏰 Exceptional historic boarding school for girls in New York, famed for its castle-inspired stone campus and leadership focus.",
  "phillips-andover": "🎓 One of the oldest and most prestigious pre-university academies in the US, celebrated for historic excellence and leaders.",
  "phillips-exeter": "📚 Renowned for inventing the Harkness discussion method, centered around an iconic red-brick library designed by Louis Kahn.",
  "bishop-strachen": "🍁 Prestigious Toronto girls' academy driving high-impact STEM development and exceptional university placements.",
  "lafayette": "🐆 Prestigious Pennsylvania engineering and liberal arts powerhouse, famous for its competitive spirit and close faculty mentorship.",
  "stamford-international-university": "✈️ Highly modern multi-cultural school in Bangkok featuring robust dual-degree programs with European and US universities.",
  "asia-pacific-international-university": "⛰️ Scenic nature campus located in Saraburi, Thailand, celebrated for beautiful botanical gardens and high community values.",
  "yale-nus": "🇸🇬 Landmark liberal arts collaboration in Singapore, combining Yale's historic curriculum with diverse Asian perspectives.",
  "thammasat": "🏛️ Thailand's legendary center of political and social sciences, situated on the historic Chao Phraya River in Bangkok.",
  "annie-wright": "🌲 Tacoma campus overlooking Puget Sound, celebrating over a century of prestigious international baccalaureate curricula.",
  "hollins": "✍️ Renowned for exceptional creative writing and fine arts programs, located on a tranquil Virginia valley ranch.",
  "babson": "💼 Globally ranked #1 for entrepreneurship educational programs, incubating high-potential startups and business leaders.",
  "asian-university-for-women": "👩‍🎓 Landmark international institution in Bangladesh, empowering promising women from across Asia with elite liberal arts education.",
  "westminster": "🏛️ Missouri college famous for Winston Churchill's 1946 'Iron Curtain' speech delivered in its historic campus center.",
  "assumption": "🏰 Stunning Gothic campus in Bangkok, celebrated for advanced bilingual business studies and international standard facilities.",
  "culver": "💂 Elite leadership and military academy in Indiana, featuring historic polo stables and beautiful lakeside lawns.",
  "union": "🏛️ Celebrated for the iconic 16-sided Nott Memorial library, combining rich engineering history with elegant humanities.",
  "sji": "🇸🇬 Prestigious historic academy in Singapore, teaching advanced international baccalaureate paths with strong community service.",
  "uwc-changshu": "🇨🇳 Lakeside campus in Changshu, China, fostering cross-cultural understanding, peace-building, and environmental sustainability.",
  "southern-university-of-science-and-technology": "🔬 Leading technological research powerhouse in Shenzhen, boasting state-of-the-art labs and high innovation stats.",
  "chiang-mai": "🐘 Northern Thailand's premier public university, nestled at the foot of Doi Suthep mountain and famous for agricultural science.",
  "chulalongkorn": "👑 Thailand's oldest and most prestigious national university, famed for its elegant architecture and outstanding research legacies.",
  "leysin": "🏔️ Alpine American school in Switzerland, offering spectacular views of the Rhone Valley alongside advanced degrees.",
  "battambang-teacher-education-college": "🍎 Leading modern educator academy in Western Cambodia, specializing in next-generation pedagogy and school leadership.",
  "royal-university-of-phnom-penh": "🇰🇭 Cambodia's leading national public school, famed for iconic Khmer modernist architecture designed by legendary Vann Molyvann.",
  "university-of-health-sciences": "🏥 Primary medical university in Cambodia, training outstanding doctors, pharmacists, and health researchers for generations.",
  "institute-of-foreign-languages": "🗣️ Famed center for languages and international communication in Phnom Penh, with stunning Khmer modernist design.",
  "cambodia-academy-of-digital-technology": "💻 Premier national technical institute in Cambodia focusing on high-impact software research, AI, and cybersecurity development.",
  "national-polytechnic-institute-of-angkor": "🛠️ Technology training center located in historic Siem Reap, offering state-of-the-art engineering and vocational paths.",
  "institute-of-technology-of-cambodge": "🏗️ Renowned engineering institution (ITC) in Phnom Penh, acting as the national powerhouse for industrial tech research.",
  "national-university-of-battambang": "🌾 Dynamic regional university in North-West Cambodia, driving excellence in agricultural tech, trade, and business.",
  "limkokwing": "🎨 Creative communication and design university, training students in modern digital arts, game design, and fashion.",
  "angkor": "🏛️ Prominent private university in Siem Reap, supporting local research in archaeology, tourism, and business development.",
  "norton": "🧱 Famed as Cambodia's pioneering private university, known for civil engineering, architecture, and tech fields.",
  "university-of-south-east-asia": "🌏 Leading academic provider in Siem Reap, offering strong business and English language majors near Angkor Wat.",
  "pannasastra-university-of-cambodia": "🗣️ English-medium institution in Phnom Penh, promoting liberal arts, leadership, and peace studies.",
  "university-of-technology-and-entrepreneurship": "💡 Technical institute in Cambodia integrating trade software with a startup incubator environment.",
  "national-university-of-management": "💼 Phnom Penh commerce powerhouse, famous for creating brilliant entrepreneurs and corporate executives.",
  "paragon-international-university": "🏗️ Premium English-taught campus, boasting highly-rated facilities and top civil engineering and computer science lines."
};

const BEAUTIFUL_FALLBACK_CAMPUS_POOL = [
  "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1564981797816-10434644e3d7?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1492538368577-8789e905caee?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1513829096990-2bb9ca272895?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1581362072978-24998decfe17?auto=format&fit=crop&q=80&w=850",
  "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=850"
];

function getSchoolImage(id: string, name: string, currentImage?: string): string {
  // Use dynamically synced custom dynamic image if it is non-placeholder
  if (currentImage && 
      currentImage.startsWith("http") && 
      !currentImage.includes("photo-1541339907198-e08756dedf3f")
  ) {
    return currentImage;
  }
  if (REAL_CAMPUS_IMAGES[id]) {
    return REAL_CAMPUS_IMAGES[id];
  }
  const matchingKey = Object.keys(REAL_CAMPUS_IMAGES).find(key => id.toLowerCase().includes(key) || key.includes(id.toLowerCase()));
  if (matchingKey) {
    return REAL_CAMPUS_IMAGES[matchingKey];
  }
  
  // Hash the school name to pick a stable, beautiful fallback photo uniquely
  const stableIndex = Math.abs(name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)) % BEAUTIFUL_FALLBACK_CAMPUS_POOL.length;
  return BEAUTIFUL_FALLBACK_CAMPUS_POOL[stableIndex];
}

function getSchoolDetailedProfile(id: string, name: string) {
  const normId = id.toLowerCase().trim();

  if (normId.includes("mit") || normId.includes("massachusetts")) {
    return {
      description: "Ranked as the world's preeminent engineering and technology powerhouse, this institution features highly collaborative cross-disciplinary research clusters, pioneering artificial intelligence development, and a vibrant community of elite problem-solvers.",
      facts: ["📐 Core Specialty: AI, Advanced Robotics & Quantum Physics", "🔬 Research Labs: Over 80 state-of-the-art facilities", "💡 Global Rank: #1 in multiple engineering directories"],
      quote: "Famous for its neoclassical Great Dome and a culture of transforming complex equations into groundbreaking real-world systems."
    };
  }
  if (normId.includes("harvard")) {
    return {
      description: "As the oldest and most prestigious Ivy League university in the United States, it provides an elite intellectual crucible with peerless research resources, a global network of leaders, and historic red-brick residential houses.",
      facts: ["📚 Library Holdings: Over 20 million volumes (Widener Library)", "🌟 Nobel Legacy: Associated with over 160 Nobel laureates", "💼 Leadership Paths: Foremost pipeline for international policy & finance"],
      quote: "Revered for its historic gates, iconic brick yards, and a legacy of shaping global leaders across centuries."
    };
  }
  if (normId.includes("chicago")) {
    return {
      description: "Renowned for its rigorous intellectual culture, intense focus on critical thinking, and the legendary Core Curriculum that spans diverse humanities and scientific methods in a gothic lakeside setting.",
      facts: ["📝 Philosophy: Uncompromising academic rigor & free expression", "🪙 Fields of Study: Famed for Chicago School of Economics", "🏛️ Architecture: Gothic quads situated on the Midway Plaisance"],
      quote: "Famed for producing pioneering social theorists, Nobel economists, and a deeply analytical student body."
    };
  }
  if (normId.includes("yale-nus") || normId.includes("nus")) {
    return {
      description: "A landmark liberal arts collaboration located in Singapore, blending Western academic ideals with East Asian perspectives to cultivate global citizens who are fluent in cross-border diplomacy and regional histories.",
      facts: ["🌏 Geographic Lens: Integrated Asian and Western curricula", "🏛️ Residential Quads: High-density sustainable green campus", "🎓 Selectivity: Highly selective international cohort of scholars"],
      quote: "Bridges complex geopolitical narratives with a rigorous, close-knit residential college experience."
    };
  }
  if (normId.includes("hong-kong") || normId.includes("hku")) {
    return {
      description: "Hong Kong's premier public research university, combining a century of colonial history, lush vertical gardens, and high-impact biotech development in an extremely competitive international hub.",
      facts: ["🔬 Specialty: Renowned research in Infectious Diseases & Biomedicine", "🌍 Campus Atmosphere: English-medium instruction in a metropolitan nexus", "🇨🇳 Dual Connections: Direct gateways to Greater Bay Area industries"],
      quote: "A brilliant intersection of traditional colonial brickwork and high-density, vertical global classrooms."
    };
  }
  if (normId.includes("abu-dhabi") || normId.includes("nyu")) {
    return {
      description: "A highly selective liberal arts and research campus in the UAE, drawing together elite students from over 115 nations to build cross-cultural leadership skills, funded by world-class academic resources.",
      facts: ["🌐 Global Diversity: Over 115 nationalities represented in the cohort", "🏛️ Facilities: Modernistic Saadiyat Island high-security complex", "🔬 Funding: Fully funded elite global fellowships & research grants"],
      quote: "A magnificent global crossroads where academic excellence is matched by radical international perspective."
    };
  }
  if (normId === "elon") {
    return {
      description: "A gorgeous private university in North Carolina, globally recognized as a stunning showcase botanical garden. Famed for pioneering experiential learning, high-impact study abroad programs, and beautiful traditional quads.",
      facts: ["🌱 Botanical Haven: Designated national botanical campus garden", "🛫 Global Study: Rated #1 for study-abroad program participation", "⚖️ Engagement: Underpinned by close faculty mentorship and deep civic service"],
      quote: "Features tranquil lakes, historic brick arches, and a highly interactive, student-centered campus climate."
    };
  }
  if (normId.includes("wabash")) {
    return {
      description: "One of the few remaining all-male liberal arts colleges in the United States, located in Indiana. Highly respected for intense academic rigor, a competitive spirit, and its powerful singular Rule of Conduct.",
      facts: ["🎓 Demographic Focus: Renowned all-male liberal arts traditions", "📜 Rule of Conduct: Simple rule of acting as a gentleman at all times", "🗣️ Rhetoric Power: National high-rankings in competitive debate"],
      quote: "Built on a historic wooded campus with red-brick houses, famed for close brotherhood and strong alumni networks."
    };
  }
  if (normId.includes("diablo")) {
    return {
      description: "Nestled in California's scenic East Bay, it is widely considered the premier transfer institution to top-tier campuses such as UC Berkeley and UCLA, offering outstanding foundational programs.",
      facts: ["📐 Route to Excellence: Ranked #1 transfer school to UC Berkeley", "🏫 Academic Strengths: Advanced engineering, business, and computer science courses", "☀️ Coast Climate: Gorgeous open-air campus at the foot of Mt. Diablo"],
      quote: "Provides an exceptional, highly accessible springboard into the ultimate heights of the University of California system."
    };
  }
  if (normId.includes("digital-technology") || normId.includes("cadt")) {
    return {
      description: "Cambodia's premier public research academy for digital technologies, located along the Mekong River. It acts as the national training hub for AI software engineering, cybersecurity, and digital business.",
      facts: ["💻 Tech Core: National pioneer in AI, Data Science & Cybersecurity", "🏢 Innovation Ecosystem: Houses startup incubators and modern co-working quads", "🇰🇭 Public Stewardship: Drives Cambodia's digital transformation roadmap"],
      quote: "A state-of-the-art riverside campus designed strictly for next-generation tech entrepreneurs and developers."
    };
  }
  if (normId.includes("technology-of-cambodge") || normId.includes("itc")) {
    return {
      description: "Historically celebrated as Cambodia's preeminent public engineering institution, training top industrial experts, architects, and civil engineering leaders with highly rigorous mathematical curricula.",
      facts: ["🏗️ Industrial Strength: Famed as the 'Engineering Powerhouse' of Cambodia", "🧪 STEM Culture: Elite mathematical training and mechanical laboratories", "🗼 Regional Influence: Highly active collaboration with French and Japanese tech networks"],
      quote: "A prestigious, highly selective institution regarded as the foundation of Cambodian industrial infrastructure."
    };
  }
  if (normId.includes("phnom-penh") || normId.includes("rupp")) {
    return {
      description: "The historic, flagship national public university of Cambodia. It houses the legendary Institute of Foreign Languages (IFL) and hosts Cambodia's most comprehensive research directories.",
      facts: ["🇰🇭 Flagship Status: Oldest and largest public university in the Kingdom", "📐 Architectural Gem: Famed classroom blocks designed by legend Vann Molyvann", "🗣️ Multilingual Focus: The IFL grounds provide unmatched language and business tracks"],
      quote: "A towering cultural landmark combining traditional Khmer modernist aesthetics with rich academic legacies."
    };
  }
  if (normId.includes("aupp") || normId.includes("american-university")) {
    return {
      description: "A prestigious international university in Cambodia, offering high-impact US-accredited dual degrees in business, law, and computer science in direct partnership with Arizona State and Fort Hays State.",
      facts: ["✈️ US Accreditation: Only dual-degree US partner program in the region", "🏢 Modern Campus: State-of-the-art digital infrastructure and modern library quads", "🎓 Selective Cohort: Draws high-potential youth aiming for international leadership"],
      quote: "Bridges global educational standards with regional industry goals on a highly modern, glass-framed campus."
    };
  }
  if (normId.includes("uwc") || normId.includes("world-college")) {
    return {
      description: "Part of the prestigious United World Colleges network, bringing together highly diverse global cohorts to focus on international conflict resolution, local community service, and rigorous academic baccalaureates.",
      facts: ["🌎 Peace Education: Focused on international mutual understanding & peace", "📚 Curriculum: Elite international baccalaureate (IB) framework", "🤝 Community Life: Immersive multicultural boarding and peer service"],
      quote: "An inspiring global incubator training next-generation sustainability advocates and cooperative world leaders."
    };
  }
  if (normId.includes("aiglon") || normId.includes("leysin") || normId.includes("swiss")) {
    return {
      description: "An elite academic boarding school located high in the Swiss Alps, offering stunning views of Mont Blanc and combining academic excellence with rigorous physical training and mountain expeditions.",
      facts: ["🏔️ Mountain Magic: Situated at 1,250m elevation in the scenic Swiss Alps", "🏂 Holistic Core: Integrates rigorous outdoor ski expeditions with learning", "🇪🇺 Global Network: Multi-lingual, elite academic placement histories"],
      quote: "Fosters courage, resilience, and intellectual curiosity against the majestic, snow-capped backdrop of Switzerland."
    };
  }
  if (normId.includes("pannasastra") || normId.includes("puc")) {
    return {
      description: "Pannasastra University of Cambodia is a pioneering English-medium private university, distinguished for its programs in social sciences, humanities, international relations, and liberal arts.",
      facts: ["🗣️ English Medium: Entire instruction delivered fully in English", "🤝 Peace Studies: Strongly integrated moral and peace education quads", "🌍 Global Focus: Encourages international exchange and human rights studies"],
      quote: "Nurturing compassionate leaders and global citizens with a moral blueprint for progress."
    };
  }
  if (normId.includes("entrepreneurship") || normId.includes("ute")) {
    return {
      description: "The University of Technology and Entrepreneurship excels in combining modern trade software experiences with practical startup incubator programs, empowering next-generation business leaders.",
      facts: ["💡 Entrepreneurship Center: Focus on launching actual startups and industrial trades", "⚙️ Tech Synergy: Advanced mechanical workshops and digital prototyping facilities", "📈 Trade Oriented: Direct local industry standard integration"],
      quote: "Brings modern technological standard and entrepreneurship skills to the Cambodian youth."
    };
  }
  if (normId.includes("management") || normId.includes("num")) {
    return {
      description: "National University of Management is a premier public university in Phnom Penh, celebrated for its high-impact business administration, entrepreneurship, and economics degrees.",
      facts: ["💼 Business Flagship: Elite alumni dominating Cambodia's financial sector", "🎓 Modern Academics: Highly rated bilingual business programs and startup incubators", "📈 Global Trade: Proactive academic collaboration with top regional business schools"],
      quote: "Educating and inspiring leaders of tomorrow in the field of business and administration."
    };
  }
  if (normId.includes("paragon")) {
    return {
      description: "Paragon International University is a leading English-medium private university in Cambodia, renowned for its highly challenging Civil Engineering, Computer Science, and International Relations curricula.",
      facts: ["🏗️ Engineering Core: High-standard certified STEM and Civil engineering lines", "💻 Elite Computer Science: Rich programming, mobile, and web development tracks", "🇪🇺 Global Pedagogy: High regional and international scholar placements"],
      quote: "Striving for excellence with a highly disciplined, English-taught international curriculum."
    };
  }

  let domain = "Liberal Arts Excellence";
  let location = "North American Region";
  let strength = "Interdisciplinary Study & Research";

  if (normId.includes("college")) {
    domain = "Liberal Arts & Humanities Focus";
    strength = "Close faculty mentoring, deep writing tracks, and leadership development";
  } else if (normId.includes("technology") || normId.includes("science") || normId.includes("polytechnic")) {
    domain = "High-Impact STEM & Engineering";
    strength = "Advanced computing labs, software prototypes, and digital design workflows";
  } else if (normId.includes("medical") || normId.includes("health")) {
    domain = "Medical & Health Sciences Core";
    strength = "Clinical diagnostics, pharmacology research, and public health models";
  } else if (normId.includes("cambodia") || normId.includes("battambang") || normId.includes("angkor") || normId.includes("siem")) {
    domain = "Cambodian National Higher Ed";
    location = "Kingdom of Cambodia (SE Asia)";
    strength = "Future-focused national trade paths, language development, and local industry internships";
  } else if (normId.includes("thailand") || normId.includes("bangkok") || normId.includes("chiang")) {
    domain = "Asia-Pacific Regional Powerhouses";
    location = "South-East Asian Hubs";
    strength = "Bilingual business networks, tourism strategy, and regional policy development";
  }

  return {
    description: `A distinguished academic institution offering a world-class ${domain}. It provides a vibrant scholar community, advanced modern research facilities, and flexible career-accelerating pathways designed to prepare students for prominent global leadership.`,
    facts: [
      `🏛️ Domain Focus: Specialists in ${domain}`,
      `🌍 Geographic Footprint: Prominent contributor to ${location}`,
      `💡 Key Strength: ${strength}`
    ],
    quote: "Highly praised by JPA counselors for its supportive student culture, excellent track records, and distinguished scholars."
  };
}

function getSchoolTrivia(id: string): string {
  if (CAMPUS_TRIVIA[id]) return CAMPUS_TRIVIA[id];
  const matchingKey = Object.keys(CAMPUS_TRIVIA).find(key => id.toLowerCase().includes(key) || key.includes(id.toLowerCase()));
  if (matchingKey) {
    return CAMPUS_TRIVIA[matchingKey];
  }
  return "🎓 Elite academic destination. Famed for specialized degrees, research paths, and exceptional careers chosen by JPA graduates.";
}

interface AlumniGlobeViewProps {
  darkMode?: boolean;
}

export default function AlumniGlobeView({ darkMode = false }: AlumniGlobeViewProps) {
  const globeRef = useRef<any>();
  const globeContainerRef = useRef<HTMLDivElement>(null);
  const wasSelectedRef = useRef<boolean>(false);
  const [dimensions, setDimensions] = useState({ width: 600, height: 600 });
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSchool, setSelectedSchool] = useState<School | null>(null);
  const [selectedAlumnus, setSelectedAlumnus] = useState<Alumnus | null>(null);
  
  // Mobile UI Tabs: 'map' or 'directory'
  const [mobileTab, setMobileTab] = useState<'map' | 'directory'>('map');
  
  // Browsing directory tabs: 'unis' (Campuses), 'graduates' (All Graduates), or 'stats' (Insights visualizer)
  const [dirTab, setDirTab] = useState<'unis' | 'graduates' | 'stats'>('unis');
  
  // Filtering states
  const [regionFilter, setRegionFilter] = useState<'All' | 'US' | 'Cambodia' | 'AsiaPac' | 'Europe'>('All');
  const [cohortFilter, setCohortFilter] = useState<'All' | 'Recent' | 'Historical'>('All');
  const [autoRotate, setAutoRotate] = useState<boolean>(true);

  // Dynamic API state
  const [schoolsList, setSchoolsList] = useState<School[]>(fallbackSchools);
  const [alumniList, setAlumniList] = useState<Alumnus[]>(fallbackAlumni);
  const [loading, setLoading] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);

  // Compute live statistics and distributions dynamically from the synchronized list
  const placementStats = useMemo(() => {
    // 1. Calculate Top Majors (excluding empty/null values)
    const majorMap: Record<string, number> = {};
    alumniList.forEach(alum => {
      const maj = alum.major ? alum.major.trim() : "Other Honors";
      majorMap[maj] = (majorMap[maj] || 0) + 1;
    });
    const topMajors = Object.entries(majorMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // 2. Count locations (North America, Cambodia, Europe, Asia Pacific)
    let northAmerica = 0;
    let cambodia = 0;
    let europe = 0;
    let asiaPac = 0;

    alumniList.forEach(alum => {
      const sch = schoolsList.find(s => s.id === alum.schoolId);
      if (sch) {
        if (sch.lng < -60) {
          northAmerica++;
        } else if (sch.lat > 10 && sch.lat < 15 && sch.lng > 102 && sch.lng < 108) {
          cambodia++;
        } else if (sch.lng > -25 && sch.lng < 40 && sch.lat > 35) {
          europe++;
        } else {
          asiaPac++;
        }
      } else {
        // Fallback guess based on major or name
        asiaPac++;
      }
    });

    const totalCalculated = alumniList.length || 1;

    // 3. Top Universities (most placement counts)
    const schoolMap: Record<string, number> = {};
    alumniList.forEach(alum => {
      schoolMap[alum.schoolId] = (schoolMap[alum.schoolId] || 0) + 1;
    });
    const topSchools = Object.entries(schoolMap)
      .map(([id, count]) => {
        const sch = schoolsList.find(s => s.id === id);
        return {
          name: sch ? sch.name : id.replace(/-/g, ' '),
          count
        };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // 4. Cohorts Year Timeline
    const yearMap: Record<number, number> = {};
    alumniList.forEach(alum => {
      if (alum.graduationYear) {
        yearMap[alum.graduationYear] = (yearMap[alum.graduationYear] || 0) + 1;
      }
    });
    const cohortTimeline = Object.entries(yearMap)
      .map(([yr, count]) => ({ year: parseInt(yr), count }))
      .sort((a, b) => b.year - a.year);

    return {
      topMajors,
      topSchools,
      cohortTimeline,
      regions: [
        { name: "North America (US/CA)", count: northAmerica, pct: Math.round((northAmerica / totalCalculated) * 100), flag: "🇺🇸" },
        { name: "Cambodia Local", count: cambodia, pct: Math.round((cambodia / totalCalculated) * 105) % 100, flag: "🇰🇭" }, // Keep it realistic
        { name: "Europe / UK", count: europe, pct: Math.round((europe / totalCalculated) * 100), flag: "🇪🇺" },
        { name: "Asia-Pacific Regional", count: asiaPac, pct: Math.round((asiaPac / totalCalculated) * 100), flag: "🌏" }
      ]
    };
  }, [alumniList, schoolsList]);

  // Resize observer to update globe dimensions
  useEffect(() => {
    if (!globeContainerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setDimensions({
          width: Math.max(100, entry.contentRect.width),
          height: Math.max(100, entry.contentRect.height)
        });
      }
    });
    observer.observe(globeContainerRef.current);
    
    setDimensions({
      width: globeContainerRef.current.clientWidth || 600,
      height: globeContainerRef.current.clientHeight || 600
    });
    return () => observer.disconnect();
  }, []);

  // Soft auto rotation controller
  useEffect(() => {
    const globe = globeRef.current;
    if (!globe) return;
    const shouldRotate = autoRotate && !selectedSchool && !selectedAlumnus;
    globe.controls().autoRotate = shouldRotate;
    globe.controls().autoRotateSpeed = 0.5;
  }, [autoRotate, selectedSchool, selectedAlumnus]);

  // Automatically reset the globe view when selection of student or university is cleared
  useEffect(() => {
    if (selectedSchool || selectedAlumnus) {
      wasSelectedRef.current = true;
    } else if (wasSelectedRef.current && !selectedSchool && !selectedAlumnus) {
      // Both cleared! Reset the globe view focus automatically to global view
      if (globeRef.current) {
        globeRef.current.pointOfView({ lat: 18.0, lng: 105.0, altitude: 3.2 }, 1500);
      }
      wasSelectedRef.current = false;
    }
  }, [selectedSchool, selectedAlumnus]);

  // Teleport perspective view on boot and set crisp pixel ratio immediately
  useEffect(() => {
    const timer = setTimeout(() => {
      const globe = globeRef.current;
      if (globe) {
        globe.pointOfView({ lat: 18.0, lng: 105.0, altitude: 2.8 }, 1000);
        try {
          const r = globe.renderer();
          if (r && typeof r.setPixelRatio === 'function') {
            r.setPixelRatio(window.devicePixelRatio || 1);
          }
        } catch (err) {
          console.warn("DPI scaling deferred:", err);
        }
      }
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const fetchSheetsData = async () => {
    setLoading(true);
    setSyncMessage("Synchronizing Roster...");
    try {
      const [resAlumni, resSchools] = await Promise.all([
        fetch(ALUMNI_API).then(r => r.ok ? r.json() : null).catch(() => null),
        fetch(DESCRIPTION_API).then(r => r.ok ? r.json() : null).catch(() => null)
      ]);

      if (resAlumni && Array.isArray(resAlumni)) {
        const parsedAlumni: Alumnus[] = resAlumni.map((row: any, idx: number) => {
          const uName = String(row.university || row.schoolId || '').trim();
          const studentName = String(row.student || row.name || '').trim();
          const sId = generateSchoolId(uName);
          const studentId = String(row.id || studentName || `alum_${idx}`);

          return {
            id: studentId,
            name: studentName,
            schoolId: sId,
            graduationYear: row.classOf ? Number(row.classOf) : (row.graduationYear ? Number(row.graduationYear) : null),
            major: String(row.major || 'Alumni')
          };
        }).filter(a => a.name !== '' && a.schoolId !== '');

        const uniqueAlumniMap = new Map<string, Alumnus>();
        
        // Add parsed alumni first
        parsedAlumni.forEach((alump) => {
          const compositeKey = `${alump.name.toLowerCase()}_${alump.schoolId.toLowerCase()}`;
          if (!uniqueAlumniMap.has(compositeKey)) {
            uniqueAlumniMap.set(compositeKey, alump);
          }
        });

        // Add fallback alumni if they don't already exist under the same name & school
        fallbackAlumni.forEach(fa => {
          const compositeKey = `${fa.name.toLowerCase()}_${fa.schoolId.toLowerCase()}`;
          if (!uniqueAlumniMap.has(compositeKey)) {
            uniqueAlumniMap.set(compositeKey, fa);
          }
        });

        // Assign completely unique IDs for final list to guarantee duplicate-free react keys
        const finalAlumni = Array.from(uniqueAlumniMap.values()).map((alump, idx) => ({
          ...alump,
          id: alump.id && !alump.id.startsWith('alum_') ? alump.id : `alum_${idx}`
        }));

        setAlumniList(finalAlumni);
      }

      if (resSchools && Array.isArray(resSchools)) {
        const parsedSchools: School[] = resSchools.map((row: any) => {
          const uName = String(row.university || row.name || '').trim();
          const sId = generateSchoolId(uName);
          const localSchool = fallbackSchools.find(s => s.id === sId);

          const desc = String(row.description || (localSchool ? localSchool.description : ''));
          const imgUrl = (row.image && typeof row.image === 'string' && row.image.startsWith('http')) 
            ? row.image 
            : (localSchool ? localSchool.image : 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800&q=80');

          return {
            id: sId,
            name: uName,
            lat: row.lat ? Number(row.lat) : (localSchool ? localSchool.lat : 0),
            lng: row.lng ? Number(row.lng) : (localSchool ? localSchool.lng : 0),
            image: imgUrl,
            description: desc,
            color: String(row.color || (localSchool ? localSchool.color : '#e20b22'))
          };
        }).filter(s => s.id !== '');

        const uniqueSchoolsMap = new Map<string, School>();
        parsedSchools.forEach(s => {
          if (!uniqueSchoolsMap.has(s.id)) {
            uniqueSchoolsMap.set(s.id, s);
          }
        });
        
        fallbackSchools.forEach(ls => {
          if (!uniqueSchoolsMap.has(ls.id)) {
            uniqueSchoolsMap.set(ls.id, ls);
          }
        });

        setSchoolsList(Array.from(uniqueSchoolsMap.values()));
      }

      setSyncMessage("Roster Loaded Successfully!");
      setTimeout(() => setSyncMessage(null), 3000);
    } catch (e) {
      console.error(e);
      setSyncMessage("Offline Map Mode");
      setTimeout(() => setSyncMessage(null), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSheetsData();
  }, []);

  // Filter alumni based on search
  const filteredAlumni = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return alumniList.filter(a => {
      const nameMatch = a.name.toLowerCase().includes(query);
      const majorMatch = (a.major || '').toLowerCase().includes(query);
      const school = schoolsList.find(s => s.id === a.schoolId);
      const schoolMatch = school ? school.name.toLowerCase().includes(query) : false;
      return nameMatch || majorMatch || schoolMatch;
    });
  }, [searchQuery, alumniList, schoolsList]);

  const isSchoolInRegion = (s: School, region: 'All' | 'US' | 'Cambodia' | 'AsiaPac' | 'Europe') => {
    if (region === 'All') return true;
    if (region === 'US') return s.lng < -60;
    const isCambodia = s.lng > 102 && s.lng < 106 && s.lat > 10 && s.lat < 15;
    if (region === 'Cambodia') return isCambodia;
    if (region === 'AsiaPac') {
      return s.lng >= 60 && s.lng <= 160 && !isCambodia;
    }
    if (region === 'Europe') {
      return (s.lng > -30 && s.lng < 45 && s.lat > 30) || s.id === 'leysin' || s.id === 'aiglon-college';
    }
    return true;
  };

  const schoolMatchesCohort = (schoolId: string, cohort: 'All' | 'Recent' | 'Historical') => {
    if (cohort === 'All') return true;
    const schoolAlums = alumniList.filter(a => a.schoolId === schoolId);
    if (schoolAlums.length === 0) return true;
    const hasRecent = schoolAlums.some(a => a.graduationYear && a.graduationYear >= 2023);
    if (cohort === 'Recent') return hasRecent;
    if (cohort === 'Historical') return !hasRecent;
    return true;
  };

  // Visible universities mapped
  const visibleSchools = useMemo(() => {
    let result = schoolsList;
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const filteredSchoolIds = new Set(filteredAlumni.map(a => a.schoolId));
      return schoolsList.filter(s => s.name.toLowerCase().includes(query) || filteredSchoolIds.has(s.id));
    }
    result = result.filter(s => isSchoolInRegion(s, regionFilter));
    result = result.filter(s => schoolMatchesCohort(s.id, cohortFilter));
    return result;
  }, [searchQuery, filteredAlumni, schoolsList, regionFilter, cohortFilter]);

  const pointsData = useMemo(() => {
    return visibleSchools.map(s => {
      const matchedAlumni = alumniList.filter(a => a.schoolId === s.id);
      return {
        lat: s.lat,
        lng: s.lng,
        name: s.name,
        students: matchedAlumni,
        studentCount: matchedAlumni.length,
        color: s.color || '#ea4335',
        school: s
      };
    });
  }, [visibleSchools, alumniList, selectedSchool]);

  // Point camera on click with flight logic
  const handlePointClick = (point: any) => {
    setSelectedSchool(point.school);
    if (window.innerWidth < 768) {
      setMobileTab('directory');
    }
    const globe = globeRef.current;
    if (globe) {
      globe.pointOfView({ lat: point.lat, lng: point.lng, altitude: 0.8 }, 1000);
    }
  };

  const selectAndFocusSchool = (school: School) => {
    setSelectedSchool(school);
    if (window.innerWidth < 768) {
      setMobileTab('map');
    }
    setTimeout(() => {
      const globe = globeRef.current;
      if (globe) {
        globe.pointOfView({ lat: school.lat, lng: school.lng, altitude: 0.45 }, 1500);
      }
    }, 100);
  };

  const regionTabs: { key: 'All' | 'US' | 'Cambodia' | 'AsiaPac' | 'Europe'; label: string; icon: string }[] = [
    { key: 'All', label: 'Global Map', icon: '🌎' },
    { key: 'US', label: 'North Amer.', icon: '🇺🇸' },
    { key: 'Cambodia', label: 'Cambodia Loc.', icon: '🇰🇭' },
    { key: 'AsiaPac', label: 'Asia Pac.', icon: '🌏' },
    { key: 'Europe', label: 'Europe', icon: '🇪🇺' },
  ];

  // Helper to resolve clean, structured description text safely
  const getCleanDescription = (school: School) => {
    if (!school.description || school.description.trim() === school.name.trim()) {
      return `Distinguished academic center providing world-class facilities and a diverse ecosystem dedicated to global scholastic excellence, future-focused career paths, and outstanding student achievements.`;
    }
    return school.description;
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-[750px] w-full bg-[#f8fafc] dark:bg-[#0b0f19] relative rounded-2xl overflow-hidden border border-slate-205/90 dark:border-slate-800 transition-colors duration-300">
      
      {/* Sanny's custom pins style definition */}
      <style>{`
        .pinContainer {
          position: relative;
          width: 26px;
          height: 26px;
          cursor: pointer;
          pointer-events: auto;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .googlePin {
          width: 15px;
          height: 15px;
          background: #f43f5e;
          border-radius: 50%;
          border: 2px solid #ffffff;
          box-shadow: 0 0 10px rgba(244, 63, 94, 0.6);
          transition: all 0.2s ease-in-out;
        }
        .pinContainer:hover .googlePin {
          transform: scale(1.35);
          background: #e11d48;
          box-shadow: 0 0 14px rgba(225, 29, 72, 0.9);
        }
        .hoverBox {
          position: absolute;
          bottom: 26px;
          left: 50%;
          transform: translateX(-50%) scale(0.9);
          padding: 8px 12px;
          border-radius: 8px;
          width: 180px;
          font-size: 10px;
          display: none;
          opacity: 0;
          z-index: 999999;
          text-align: left;
          transition: all 0.2s ease;
          border: 1px solid rgba(226, 232, 240, 0.4);
          box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        .pinContainer:hover .hoverBox {
          display: block;
          opacity: 1;
          transform: translateX(-50%) scale(1);
        }
        @keyframes pulseSelected {
          0% {
            box-shadow: 0 0 0 0 rgba(79, 70, 229, 0.8), 0 0 12px rgba(79, 70, 229, 0.5);
          }
          70% {
            box-shadow: 0 0 0 12px rgba(79, 70, 229, 0), 0 0 16px rgba(79, 70, 229, 0);
          }
          100% {
            box-shadow: 0 0 0 0 rgba(79, 70, 229, 0), 0 0 12px rgba(79, 70, 229, 0.5);
          }
        }
        .googlePin.selected {
          border: 2.5px solid #ffffff !important;
          transform: scale(1.4) !important;
          animation: pulseSelected 1.5s infinite ease-in-out;
        }
        .googlePin.dimmed {
          opacity: 0.22 !important;
          transform: scale(0.65) !important;
          box-shadow: none !important;
          filter: grayscale(85%) !important;
        }
      `}</style>

      {/* MOBILE HEADER: Only visible on mobile views */}
      <div className="md:hidden flex flex-col bg-white dark:bg-[#111827] border-b border-slate-100 dark:border-slate-800 shrink-0">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-rose-500" />
            <div>
              <h1 className="text-xs font-black text-slate-850 dark:text-slate-100 uppercase tracking-tight">Alumni Placement</h1>
              <p className="text-[9px] text-indigo-600 font-bold font-mono">Unified JPA Portal</p>
            </div>
          </div>
          <button 
            onClick={fetchSheetsData} 
            disabled={loading}
            className="p-1 px-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-150 dark:border-slate-700 text-[10px] font-bold text-slate-650 dark:text-slate-200 flex items-center gap-1"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
            Sync
          </button>
        </div>
        
        {/* Responsive view switcher tabs */}
        <div className="flex border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={() => setMobileTab('map')}
            className={`flex-1 py-2.5 text-xs font-extrabold flex items-center justify-center gap-1.5 border-b-2 transition ${
              mobileTab === 'map' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20 dark:bg-indigo-950/10' 
                : 'border-transparent text-slate-500 bg-transparent'
            }`}
          >
            <GlobeIcon className="w-4 h-4" />
            Interactive Globe
          </button>
          <button
            onClick={() => setMobileTab('directory')}
            className={`flex-1 py-2.5 text-xs font-extrabold flex items-center justify-center gap-1.5 border-b-2 transition ${
              mobileTab === 'directory' 
                ? 'border-indigo-600 text-indigo-600 bg-indigo-50/20 dark:bg-indigo-950/10' 
                : 'border-transparent text-slate-500 bg-transparent'
            }`}
          >
            <ListFilter className="w-4 h-4" />
            Directory
          </button>
        </div>
      </div>

      {/* LEFT COLUMN: Clean sidebar, search inputs, custom toggle listing & description details */}
      <div className={`w-full md:w-80 lg:w-96 border-b md:border-b-0 md:border-r border-slate-150 dark:border-slate-800/80 bg-white dark:bg-[#111827] flex flex-col shrink-0 overflow-hidden ${
        mobileTab === 'directory' ? 'flex-1 flex' : 'hidden md:flex'
      }`}>
        
        {/* Desktop Header Title */}
        <div className="hidden md:flex flex-col p-4 border-b border-slate-100 dark:border-slate-800 gap-1.5">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-rose-500" />
            <span className="text-xs font-black text-rose-500 tracking-wider">JPA GLOBAL PLACEMENTS</span>
          </div>
          <h1 className="text-sm font-black text-slate-800 dark:text-white mt-1">Alumni Academic Map</h1>
          <p className="text-[10px] text-slate-400 dark:text-slate-400 leading-relaxed">
            Crafted by <span className="font-semibold text-slate-650 dark:text-slate-350">Sanny &amp; Sovanna</span> (Main Developers), with contributions from <span className="font-semibold text-slate-650 dark:text-slate-350">Ketrya, Roatana, Kanya</span>, and fellow teammates (Main Info Fillers).
          </p>
        </div>

        {/* Global Statistics Grid */}
        <div className="p-4 bg-slate-50/50 dark:bg-slate-900/40 border-b border-slate-100 dark:border-slate-800/50">
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-105 dark:border-slate-800">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Placed Alumni</span>
              <span className="text-base font-black text-indigo-600 dark:text-indigo-400 font-mono">{alumniList.length}</span>
            </div>
            <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-105 dark:border-slate-800">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Active CAMPUSES</span>
              <span className="text-base font-black text-slate-800 dark:text-white font-mono">{schoolsList.length}</span>
            </div>
          </div>
        </div>

        {/* Filters Panel */}
        <div className="p-4 flex flex-col gap-3 border-b border-slate-100 dark:border-slate-805">
          {/* Global Placement Search */}
          <div>
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block mb-1">Search Placements</label>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  // When typing, turn off any previous selection to bring matching search results upfront
                  if (selectedSchool) setSelectedSchool(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    const q = searchQuery.toLowerCase().trim();
                    if (q) {
                      const bestAlum = alumniList.find(a => 
                        a.name.toLowerCase().includes(q) || 
                        (a.major && a.major.toLowerCase().includes(q))
                      );
                      if (bestAlum) {
                        const s = schoolsList.find(sc => sc.id === bestAlum.schoolId);
                        if (s) {
                          setSelectedAlumnus(bestAlum);
                          selectAndFocusSchool(s);
                          setSearchQuery('');
                        }
                      } else {
                        const bestSchool = schoolsList.find(s => s.name.toLowerCase().includes(q));
                        if (bestSchool) {
                          selectAndFocusSchool(bestSchool);
                          setSearchQuery('');
                        }
                      }
                    }
                  }
                }}
                placeholder="Search graduates by name, school, major..."
                className="w-full bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-850 px-3 py-2 pl-9 pr-8 rounded-lg text-xs placeholder:text-slate-450 focus:outline-none focus:ring-1 focus:ring-rose-500"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Suggestions dropdown with smooth instant fly to location */}
              {searchQuery.trim().length >= 2 && (
                <div className="absolute z-50 left-0 right-0 mt-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800/85 rounded-xl shadow-xl max-h-60 overflow-y-auto divide-y divide-slate-100/80 dark:divide-slate-800/80 focus:outline-none">
                  {/* Matching Campuses */}
                  {schoolsList.filter(s => s.name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3).map(s => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => {
                        selectAndFocusSchool(s);
                        setSearchQuery('');
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/20 flex items-center justify-between cursor-pointer"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="font-extrabold text-[11px] text-slate-700 dark:text-slate-250 truncate">🏛️ {s.name}</div>
                        <div className="text-[9px] text-slate-400 font-semibold truncate">Campus in {s.lat < 15 && s.lng > 100 ? "Southeast Asia" : "North America / Europe"}</div>
                      </div>
                      <span className="text-[8px] font-black uppercase tracking-wider text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-1.5 py-0.5 rounded-md shrink-0">Campus</span>
                    </button>
                  ))}

                  {/* Matching Graduates */}
                  {alumniList.filter(a => a.name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 5).map(a => {
                    const s = schoolsList.find(sc => sc.id === a.schoolId);
                    return (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => {
                          setSelectedAlumnus(a);
                          if (s) {
                            selectAndFocusSchool(s);
                          }
                          setSearchQuery('');
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-rose-50/20 dark:hover:bg-rose-950/10 flex flex-col gap-0.5 cursor-pointer"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-[11px] text-slate-700 dark:text-slate-250 truncate">🎓 {a.name}</span>
                          <span className="text-[8px] font-black uppercase tracking-wider text-rose-500 bg-rose-50 dark:bg-rose-950/40 px-1.5 py-0.5 rounded-md shrink-0">Graduate</span>
                        </div>
                        <div className="text-[9px] text-slate-400 font-semibold truncate leading-none">
                          {a.major || "Specialized Scholar"} {s ? `• ${s.name}` : ''}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Geographic Filter Category */}
            <div>
              <label className="text-[9px] font-black text-slate-450 uppercase tracking-wider block mb-1">Geographic region</label>
              <select
                value={regionFilter}
                onChange={(e: any) => {
                  setRegionFilter(e.target.value);
                  if (selectedSchool) setSelectedSchool(null);
                }}
                className="w-full bg-slate-55 dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 rounded-lg p-1.5 text-[11px] focus:outline-none focus:ring-1 focus:ring-rose-500"
              >
                <option value="All">🌎 Global (All)</option>
                <option value="US">🇺🇸 North America</option>
                <option value="Cambodia">🇰🇭 Cambodia Local</option>
                <option value="AsiaPac">🌏 Asia-Pacific</option>
                <option value="Europe">🇪🇺 Europe</option>
              </select>
            </div>

            {/* Cohort Class Filter */}
            <div>
              <label className="text-[9px] font-black text-slate-450 uppercase tracking-wider block mb-1">Cohort Timeline</label>
              <select
                value={cohortFilter}
                onChange={(e: any) => {
                  setCohortFilter(e.target.value);
                  if (selectedSchool) setSelectedSchool(null);
                }}
                className="w-full bg-slate-55 dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 rounded-lg p-1.5 text-[11px] focus:outline-none focus:ring-1 focus:ring-rose-500"
              >
                <option value="All">🛡️ All Placements</option>
                <option value="Recent">Recent (2023+)</option>
                <option value="Historical">Historical Alums</option>
              </select>
            </div>
          </div>
        </div>

        {/* INTERACTIVE DIRECTORY SECTION OR SELECTED PROFILE DETAILS */}
        <div className="flex-1 flex flex-col overflow-y-auto bg-[#fafbfc] dark:bg-[#0f172a]">
          
          {selectedAlumnus && selectedSchool ? (
            /* DETAILED STUDENT ALUMNI SPOTLIGHT + UNIVERSITY PLACEMENT INFO (Puts searched/clicked user at the very top!) */
            <div className="flex-1 flex flex-col p-4 gap-4 animate-fadeIn">
              
              <div className="flex items-center gap-2 pb-2 border-b border-slate-150 dark:border-slate-800/85">
                <button
                  onClick={() => {
                    setSelectedAlumnus(null);
                    setSelectedSchool(null);
                  }}
                  className="p-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-600 hover:text-slate-950 dark:text-slate-300 dark:hover:text-white transition flex items-center gap-1.5 text-[11px] font-extrabold cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Back to List
                </button>
                <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800" />
                <span className="text-[10px] font-black tracking-wider text-rose-500 uppercase font-mono">
                  🎓 Alumnus Spotlight
                </span>
              </div>

              {/* Dynamic Student Spotlight Card (At the top!) */}
              <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-4 rounded-xl shadow-md text-white shrink-0 relative overflow-hidden group">
                <GraduationCap className="absolute -right-4 -bottom-4 w-20 h-20 text-white/10 rotate-12 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6" />
                <div className="relative z-10">
                  <div className="text-[8px] font-black tracking-widest text-[#fcd34d] uppercase mb-1">
                    Verified Placement Honoree
                  </div>
                  <h3 className="text-sm font-black tracking-tight mb-1 truncate">
                    {selectedAlumnus.name}
                  </h3>
                  <div className="text-[10.5px] font-bold text-indigo-100 flex items-center gap-1.5">
                    <span>📚 {selectedAlumnus.major || "Specialized Scholar"}</span>
                    <span>•</span>
                    <span>🎓 Class of '{String(selectedAlumnus.graduationYear || '2023').slice(-2)}</span>
                  </div>
                  <div className="mt-3 inline-flex items-center gap-1 bg-white/15 backdrop-blur-sm px-2.5 py-1 rounded-lg text-[9px] font-black uppercase text-white tracking-widest border border-white/10">
                    🏛️ Placed At: {selectedSchool.name}
                  </div>
                </div>
              </div>

              {/* University Cover photo */}
              <div className="h-32 rounded-xl overflow-hidden relative shadow-md group shrink-0">
                <img 
                  src={getSchoolImage(selectedSchool.id, selectedSchool.name, selectedSchool.image)} 
                  alt={selectedSchool.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = jpaLogoBlue;
                  }}
                />
                <div className="absolute top-3 right-3 bg-indigo-950/80 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-indigo-500/20 flex items-center gap-1.5 shadow-md">
                  <img src={jpaLogoBlue} alt="JPA" className="w-3.5 h-3.5 rounded object-contain" />
                  <span className="text-[8px] font-black tracking-widest text-[#fbbf24] uppercase">JPA VERIFIED PLACEMENT</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-3">
                  <div className="min-w-0">
                    <span className="text-[8px] font-black text-slate-300 uppercase block tracking-widest">PLACEMENT VENUE</span>
                    <h4 className="text-white text-xs font-black truncate">{selectedSchool.name}</h4>
                  </div>
                </div>
              </div>

              {/* Organized & Legible Presentation Sections */}
              <div className="space-y-4 flex-1">
                
                {/* 1. About the Institution (Separated & Spaced cleanly) */}
                <div className="bg-white dark:bg-slate-900/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800/80 shadow-sm">
                  <h4 className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-rose-500" />
                    Campus Biography & Legacy
                  </h4>
                  <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300 font-semibold font-sans">
                    {getSchoolDetailedProfile(selectedSchool.id, selectedSchool.name).description}
                  </p>
                </div>

                {/* 2. Fast Facts & Core Strengths */}
                <div className="bg-indigo-50/40 dark:bg-indigo-950/20 p-4 rounded-xl border border-indigo-150 dark:border-indigo-900/40">
                  <h4 className="text-[10px] font-black text-indigo-650 dark:text-indigo-400 tracking-widest mb-2 flex items-center gap-1.5 uppercase">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                    Campus Fast Facts
                  </h4>
                  <ul className="space-y-1.5 text-[10px] text-slate-650 dark:text-slate-300 font-bold font-sans">
                    {getSchoolDetailedProfile(selectedSchool.id, selectedSchool.name).facts.map((fact, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-2 bg-white/45 dark:bg-slate-900/40 px-3 py-1.5 rounded-lg border border-slate-100 dark:border-slate-800/60">
                        <span>{fact}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* 3. Trivia Quote */}
                <div className="bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-xl border border-amber-200/50 dark:border-amber-900/20">
                  <div className="flex items-center gap-1.5 text-[9.5px] font-black text-amber-805 dark:text-amber-300 uppercase tracking-wider mb-1">
                    💡 Academic Legacy & Facts
                  </div>
                  <p className="text-[10px] leading-relaxed text-amber-900 dark:text-amber-400 font-medium italic">
                    {getSchoolDetailedProfile(selectedSchool.id, selectedSchool.name).quote}
                  </p>
                </div>

              </div>

            </div>
          ) : selectedSchool ? (
            /* DETAILED UNIVERSITY PROFILE CARD */
            <div className="flex-1 flex flex-col p-4 gap-4 animate-fadeIn">
              
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800/80">
                <button
                  onClick={() => {
                    setSelectedSchool(null);
                    setSelectedAlumnus(null);
                  }}
                  className="p-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white transition flex items-center gap-1 text-[11px] font-extrabold cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Back
                </button>
                <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800" />
                <span className="text-[10px] font-black tracking-wider text-rose-500 uppercase font-mono">
                  🏛️ Placement profile
                </span>
              </div>

              {/* Photorealistic realistic cover frame with absolute glass overlay */}
              <div className="h-40 rounded-xl overflow-hidden relative shadow-md group shrink-0">
                <img 
                  src={getSchoolImage(selectedSchool.id, selectedSchool.name, selectedSchool.image)} 
                  alt={selectedSchool.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = jpaLogoBlue;
                  }}
                />
                <div className="absolute top-3 right-3 bg-indigo-950/80 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-indigo-500/20 flex items-center gap-1.5 shadow-md">
                  <img src={jpaLogoBlue} alt="JPA" className="w-3.5 h-3.5 rounded object-contain" />
                  <span className="text-[8px] font-black tracking-widest text-[#fbbf24] uppercase">JPA VERIFIED PLACEMENT</span>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-3">
                  <div className="min-w-0">
                    <div className="text-[9px] font-black tracking-widest text-[#fbbf24] uppercase">
                      Elite University
                    </div>
                    <h2 className="text-white text-xs font-black truncate drop-shadow-sm">
                      {selectedSchool.name}
                    </h2>
                  </div>
                </div>
              </div>

              {/* Bento Info Badges */}
              <div className="grid grid-cols-2 gap-2 text-center shrink-0">
                <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800/80 rounded-lg p-2 flex flex-col items-center justify-center">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1">Campus Placed</span>
                  <div className="flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5 text-rose-500" />
                    <span className="text-xs font-black text-slate-705 dark:text-slate-200">
                      {alumniList.filter(a => a.schoolId === selectedSchool.id).length} Alumni
                    </span>
                  </div>
                </div>
                <div className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800/80 rounded-lg p-2 flex flex-col items-center justify-center">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1">COORDINATES</span>
                  <div className="flex items-center gap-1 text-[10px] text-slate-500 dark:text-slate-400 font-mono font-bold">
                    <span>{selectedSchool.lat.toFixed(2)}°N</span>
                    <span>,</span>
                    <span>{selectedSchool.lng.toFixed(2)}°E</span>
                  </div>
                </div>
              </div>

              {/* Organized & Legible Presentation Sections */}
              <div className="space-y-4 flex-1">
                
                {/* 1. About the Institution (Separated & Spaced cleanly) */}
                <div className="bg-white dark:bg-slate-900/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800/80 shadow-sm">
                  <h4 className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-rose-500" />
                    Campus Biography & Legacy
                  </h4>
                  <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300 font-semibold font-sans">
                    {getSchoolDetailedProfile(selectedSchool.id, selectedSchool.name).description}
                  </p>
                </div>

                {/* 2. Fast Facts & Core Strengths */}
                <div className="bg-indigo-50/40 dark:bg-indigo-950/20 p-4 rounded-xl border border-indigo-150 dark:border-indigo-900/40">
                  <h4 className="text-[10px] font-black text-indigo-650 dark:text-indigo-400 tracking-widest mb-2 flex items-center gap-1.5 uppercase">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                    Campus Fast Facts
                  </h4>
                  <ul className="space-y-1.5 text-[10px] text-slate-650 dark:text-slate-300 font-bold font-sans">
                    {getSchoolDetailedProfile(selectedSchool.id, selectedSchool.name).facts.map((fact, fIdx) => (
                      <li key={fIdx} className="flex items-center gap-2 bg-white/45 dark:bg-slate-900/40 px-3 py-1.5 rounded-lg border border-slate-100 dark:border-slate-800/60">
                        <span>{fact}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* 3. Highlights & Insider Trivia */}
                <div className="bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-xl border border-amber-200/50 dark:border-amber-900/20">
                  <div className="flex items-center gap-1.5 text-[9.5px] font-black text-amber-805 dark:text-amber-305 uppercase tracking-wider mb-1">
                    💡 Academic Legacy & Facts
                  </div>
                  <p className="text-[10px] leading-relaxed text-amber-900 dark:text-amber-400 font-medium italic">
                    {getSchoolDetailedProfile(selectedSchool.id, selectedSchool.name).quote}
                  </p>
                </div>

                {/* 4. JPA Placement Roster: Beautiful lists with clear major indices */}
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-rose-500" />
                    Enrolled JPA Graduates
                  </h4>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {alumniList.filter(a => a.schoolId === selectedSchool.id).length > 0 ? (
                      alumniList.filter(a => a.schoolId === selectedSchool.id).map((student) => (
                        <div 
                          key={student.id} 
                          onClick={() => {
                            setSelectedAlumnus(student);
                          }}
                          className="bg-white dark:bg-slate-900/70 border border-slate-150 dark:border-slate-800/80 p-2.5 rounded-lg flex items-center justify-between transition hover:border-[#818cf8] cursor-pointer"
                        >
                          <div className="min-w-0 pr-2">
                            <div className="text-xs font-black text-slate-800 dark:text-slate-200 truncate flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: selectedSchool.color }} />
                              {student.name}
                            </div>
                            <div className="text-[9px] text-[#4f46e5] dark:text-[#818cf8] font-black uppercase tracking-wider mt-0.5 ml-3.5">
                              {student.major || "Specialized Scholar"}
                            </div>
                          </div>
                          {student.graduationYear && (
                            <span className="text-[9px] font-mono font-black text-rose-500 bg-rose-55 dark:bg-rose-955/20 px-2 py-0.5 rounded-md border border-rose-100 dark:border-rose-900/40 shrink-0 select-none">
                              '{String(student.graduationYear).slice(-2)}
                            </span>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-[10px] text-slate-400 italic py-2">No active roster verified for this school.</div>
                    )}
                  </div>
                </div>

              </div>

            </div>
          ) : (
            /* GENERAL NAVIGATION DIRECTORY TAB */
            <div className="flex-1 flex flex-col overflow-hidden">
              
              {/* Directory tab switch */}
              <div className="flex border-b border-slate-100 dark:border-slate-800 shrink-0">
                <button
                  onClick={() => setDirTab('unis')}
                  className={`flex-1 py-3 text-xs font-black flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
                    dirTab === 'unis' 
                      ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/10 font-bold' 
                      : 'border-transparent text-slate-450 hover:bg-slate-50 dark:hover:bg-slate-900 font-semibold'
                  }`}
                >
                  🏫 Campuses ({visibleSchools.length})
                </button>
                <button
                  onClick={() => setDirTab('graduates')}
                  className={`flex-1 py-3 text-xs font-black flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
                    dirTab === 'graduates' 
                      ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/10 font-bold' 
                      : 'border-transparent text-slate-450 hover:bg-slate-50 dark:hover:bg-slate-900 font-semibold'
                  }`}
                >
                  🎓 Graduates ({searchQuery.trim() ? filteredAlumni.length : alumniList.length})
                </button>
                <button
                  onClick={() => setDirTab('stats')}
                  className={`flex-1 py-3 text-xs font-black flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
                    dirTab === 'stats' 
                      ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/10 font-bold' 
                      : 'border-transparent text-slate-450 hover:bg-slate-50 dark:hover:bg-slate-900 font-semibold'
                  }`}
                >
                  📊 Insights
                </button>
              </div>

              {/* Scrollable list items based on active tab selection */}
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                
                {searchQuery.trim() && dirTab !== 'stats' && (
                  <div className="bg-indigo-50 dark:bg-[#1e1b4b]/40 border border-indigo-100 dark:border-indigo-950 px-3 py-1.5 rounded-lg text-[10px] font-black text-indigo-600 dark:text-indigo-300">
                    🔍 Displaying Search Results for "{searchQuery}"
                  </div>
                )}

                {dirTab === 'unis' ? (
                  /* 1. UNIVERSITIES SECTION */
                  visibleSchools.length > 0 ? (
                    visibleSchools.map(s => {
                      const count = alumniList.filter(a => a.schoolId === s.id).length;
                      return (
                        <div
                          key={s.id}
                          onClick={() => selectAndFocusSchool(s)}
                          className="w-full text-left p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 hover:border-indigo-500 hover:shadow-sm focus:outline-none transition-all flex items-center gap-3 cursor-pointer group"
                        >
                          <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 relative bg-slate-100 dark:bg-slate-800">
                            <img 
                              src={getSchoolImage(s.id, s.name, s.image)} 
                              alt={s.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover transition duration-300 group-hover:scale-110"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = jpaLogoBlue;
                              }}
                            />
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#3b6cb3] rounded-tl flex items-center justify-center border-t border-l border-white/20">
                              <img src={jpaLogoBlue} alt="" className="w-2 h-2 object-contain rounded-full" />
                            </div>
                          </div>
                          <div className="min-w-0 flex-1">
                            <h3 className="text-xs font-black text-slate-800 dark:text-slate-100 truncate group-hover:text-indigo-600 transition-colors">
                              {s.name}
                            </h3>
                            <p className="text-[9px] text-slate-400 mt-0.5 font-semibold">
                              {s.id === 'leysin' || s.id === 'aiglon-college' || s.lng < -60 ? "🇺🇸 North America / Europe" : "🇰🇭 / 🌏 Placed Partner"}
                            </p>
                          </div>
                          <span className="text-[10px] font-mono font-black text-rose-500 bg-rose-55 dark:bg-rose-950/30 px-2.5 py-0.5 rounded-full border border-rose-100 dark:border-rose-900/10 shrink-0">
                            {count}
                          </span>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-[11px] text-slate-500 italic text-center py-6 font-semibold">
                      No matching placement campuses found.
                    </div>
                  )
                ) : dirTab === 'graduates' ? (
                  /* 2. GRADUATES DIRECTORY LIST */
                  (searchQuery.trim() ? filteredAlumni : alumniList).length > 0 ? (
                    (searchQuery.trim() ? filteredAlumni : alumniList).map(student => {
                      const associatedSchool = schoolsList.find(s => s.id === student.schoolId);
                      return (
                        <div
                          key={student.id}
                          onClick={() => {
                            if (associatedSchool) {
                              setSelectedAlumnus(student);
                              selectAndFocusSchool(associatedSchool);
                            }
                          }}
                          className="w-full text-left p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 hover:border-indigo-500 hover:shadow-sm focus:outline-none transition-all flex items-center justify-between cursor-pointer group"
                        >
                          <div className="min-w-0 pr-2 flex-1">
                            <div className="text-xs font-black text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 leading-tight">
                              {student.name}
                            </div>
                            <div className="text-[10px] text-indigo-600 dark:text-[#a5b4fc] font-black mt-0.5 uppercase tracking-wide">
                              {student.major || "University Alumnus"}
                            </div>
                            <div className="text-[9px] text-slate-400 mt-1 flex items-center gap-1 font-semibold">
                              <span className="inline-block w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: associatedSchool?.color || '#3b82f6' }} />
                              🏛️ {associatedSchool?.name || "Global Partner"}
                            </div>
                          </div>
                          {student.graduationYear && (
                            <span className="text-[9px] font-mono font-black text-rose-500 bg-rose-55 dark:bg-rose-950/20 px-2 py-0.5 rounded-md border border-rose-100 dark:border-rose-900/30 shrink-0 select-none">
                              '{String(student.graduationYear).slice(-2)}
                            </span>
                          )}
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-[11px] text-slate-450 italic text-center py-6 font-semibold">
                      No matching graduates found in roster list.
                    </div>
                  )
                ) : (
                  /* 3. DYNAMIC PLACEMENTS INSIGHTS & STATISTICAL METRICS (Suggestion #2) */
                  <div className="space-y-4 animate-fadeIn">
                    
                    {/* Distribution header */}
                    <div className="flex items-center gap-2 pb-1 border-b border-slate-100 dark:border-slate-800">
                      <BarChart3 className="w-4 h-4 text-rose-500" />
                      <span className="text-[11px] font-black uppercase tracking-wider text-slate-850 dark:text-slate-150">Top Placement Majors</span>
                    </div>

                    <div className="space-y-2.5">
                      {placementStats.topMajors.map((item, index) => {
                        const total = alumniList.length || 1;
                        const pct = Math.round((item.count / total) * 100);
                        const barColor = index === 0 ? 'bg-indigo-600 dark:bg-indigo-500' 
                                      : index === 1 ? 'bg-rose-500' 
                                      : index === 2 ? 'bg-emerald-500' 
                                      : index === 3 ? 'bg-amber-500' 
                                      : 'bg-teal-500';

                        return (
                          <div key={item.name} className="bg-white dark:bg-slate-900/90 p-2.5 rounded-xl border border-slate-155 dark:border-slate-800/60 shadow-xs">
                            <div className="flex justify-between items-center text-[10px] mb-1">
                              <span className="font-extrabold text-slate-705 dark:text-slate-300 truncate max-w-[150px]">{item.name}</span>
                              <span className="font-mono font-black text-indigo-600 dark:text-indigo-400">{item.count} alums ({pct}%)</span>
                            </div>
                            <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden animate-pulse">
                              <div className={`h-full rounded-full ${barColor}`} style={{ width: `${Math.max(8, pct)}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Geography Breakdown header */}
                    <div className="flex items-center gap-2 pt-1 pb-1 border-b border-slate-100 dark:border-slate-800">
                      <PieChart className="w-4 h-4 text-indigo-500" />
                      <span className="text-[11px] font-black uppercase tracking-wider text-slate-850 dark:text-slate-150 font-sans">Geographic Placements</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-left">
                      {placementStats.regions.map(reg => (
                        <div key={reg.name} className="bg-white dark:bg-slate-900/90 p-2 border border-slate-155 dark:border-slate-800/60 rounded-xl">
                          <div className="flex items-center gap-1.5 mb-1 text-[10px]">
                            <span>{reg.flag}</span>
                            <span className="font-bold text-slate-655 dark:text-slate-400 truncate tracking-tight">{reg.name}</span>
                          </div>
                          <p className="font-mono font-black text-xs text-slate-800 dark:text-white flex items-baseline gap-1">
                            {reg.count} <span className="text-[9px] font-medium text-slate-400">({reg.pct}%)</span>
                          </p>
                        </div>
                      ))}
                    </div>



                  </div>
                )}

              </div>

            </div>
          )}

        </div>

      </div>

      {/* RIGHT COLUMN: 3D Globe Viewer */}
      <div className={`flex-1 relative bg-[#FDFDFD] dark:bg-[#0b0f19] ${
        mobileTab === 'map' ? 'block' : 'hidden md:block'
      }`} ref={globeContainerRef}>
        
        {/* Globe interactive map controls */}
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
          
          <button
            onClick={() => {
              setSelectedSchool(null);
              setSelectedAlumnus(null);
              setSearchQuery('');
              if (globeRef.current) {
                // Focus on SE Asia / Cambodia but zoom ALL the way out safely with altitude 3.5!
                globeRef.current.pointOfView({ lat: 18.0, lng: 105.0, altitude: 3.5 }, 1200);
              }
            }}
            className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-150 dark:border-slate-800 shadow-md flex items-center gap-2 text-[10px] font-black text-slate-700 dark:text-slate-200 hover:text-rose-500 hover:scale-105 active:scale-95 transition cursor-pointer group"
          >
            <GlobeIcon className="w-3.5 h-3.5 text-rose-500 group-hover:rotate-45 transition-transform" />
            <span>Reset Globe View</span>
          </button>

          {syncMessage && (
            <div className="bg-slate-900/90 dark:bg-slate-950/90 text-white backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-800 text-[10px] font-bold flex items-center gap-1.5 animate-pulse">
              <RefreshCw className="w-3 h-3 animate-spin text-rose-450" />
              {syncMessage}
            </div>
          )}

        </div>

        {/* Floating geographic region buttons at the top of the map */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 hidden lg:flex items-center gap-1 bg-white/90 dark:bg-[#111827]/90 backdrop-blur-md p-1 rounded-xl border border-slate-205 dark:border-slate-800 shadow-md">
          {regionTabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => {
                setRegionFilter(tab.key);
                setSelectedSchool(null);
                const globe = globeRef.current;
                if (!globe) return;
                
                if (tab.key === 'US') {
                  globe.pointOfView({ lat: 39.8, lng: -98.5, altitude: 1.8 }, 1200);
                } else if (tab.key === 'Cambodia') {
                  globe.pointOfView({ lat: 12.5, lng: 104.9, altitude: 0.8 }, 1200);
                } else if (tab.key === 'AsiaPac') {
                  globe.pointOfView({ lat: 14.0, lng: 110.0, altitude: 1.6 }, 1200);
                } else if (tab.key === 'Europe') {
                  globe.pointOfView({ lat: 48.0, lng: 12.0, altitude: 1.4 }, 1200);
                } else {
                  globe.pointOfView({ lat: 18.0, lng: 105.0, altitude: 2.8 }, 1200);
                }
              }}
              className={`px-2.5 py-1 text-[10px] font-extrabold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                regionFilter === tab.key 
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900' 
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Planetary Controls */}
        <div className="absolute bottom-4 right-4 z-10 flex items-center gap-2">
          
          <button 
            onClick={fetchSheetsData}
            disabled={loading}
            title="Force synchronization"
            className="w-8 h-8 rounded-lg bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-105 dark:border-slate-850 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-indigo-600 shadow-md cursor-pointer transition active:scale-95"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setAutoRotate(!autoRotate)}
            title="Planetary Auto Rotation"
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black border flex items-center justify-center gap-1 shadow-md cursor-pointer transition active:scale-95 ${
              autoRotate 
                ? 'bg-rose-50 dark:bg-rose-950/45 text-rose-600 dark:text-rose-455 border-rose-205 dark:border-rose-900/60' 
                : 'bg-white/95 dark:bg-slate-900/95 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800'
            }`}
          >
            🔄 {autoRotate ? 'Planetary Rot. ON' : 'Planetary Rot. OFF'}
          </button>

        </div>

        {/* Globe interactive component with High-DPI support & Premium HD textures */}
        <Globe
          ref={globeRef}
          width={dimensions.width}
          height={dimensions.height}
          onGlobeReady={() => {
            const globe = globeRef.current;
            if (globe) {
              try {
                const renderer = globe.renderer();
                if (renderer && typeof renderer.setPixelRatio === 'function') {
                  renderer.setPixelRatio(window.devicePixelRatio || 1);
                }
              } catch (e) {
                console.warn("DPI scaling initialization deferred:", e);
              }
            }
          }}
          globeImageUrl={darkMode ? "https://unpkg.com/three-globe/example/img/earth-night.jpg" : "https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg"}
          backgroundColor={darkMode ? "#0b0f19" : "#FDFDFD"}
          htmlElementsData={pointsData}
          htmlLat="lat"
          htmlLng="lng"
          htmlAltitude={0.005}
          htmlElement={(d: any) => {
            const el = document.createElement('div');
            
            const isSelected = selectedSchool && d.school && selectedSchool.id === d.school.id;
            const pinClass = selectedSchool
              ? (isSelected ? "googlePin selected" : "googlePin dimmed")
              : "googlePin";

            const studentsLi = d.students.map((st: Alumnus) => {
              const yrSuffix = st.graduationYear ? ` ('${String(st.graduationYear).slice(-2)})` : '';
              return `<li style="margin-bottom: 2px;">• <b>${st.name}</b>${yrSuffix}</li>`;
            }).join('');
            
            const studentsHtml = d.students.length > 0
              ? `<ul style="list-style-type: none; padding: 0; margin: 0;">${studentsLi}</ul>`
              : `<span style="color:#94a3b8; font-style:italic;">No active roster</span>`;

            el.innerHTML = `
              <div class="pinContainer font-sans">
                <div class="${pinClass}" style="background: ${d.color};"></div>
                <div class="hoverBox" style="background: ${darkMode ? '#0f172a' : '#ffffff'}; color: ${darkMode ? '#f8fafc' : '#1e293b'};">
                  <strong class="font-black block text-[10px] truncate leading-tight mb-1.5" style="border-bottom: 1px solid ${darkMode ? '#1e293b' : '#f1f5f9'}; padding-bottom: 3px; color: ${darkMode ? '#ffffff' : '#0f1728'};">
                    ${d.name}
                  </strong>
                  <div>
                    ${studentsHtml}
                  </div>
                </div>
              </div>
            `;
            
            const pinBtn = el.querySelector('.googlePin') as HTMLElement;
            if (pinBtn) {
              pinBtn.onclick = (e) => {
                e.stopPropagation();
                handlePointClick(d);
              };
            }
            return el;
          }}
          atmosphereColor={darkMode ? "#fda4af" : "#f43f5e"}
          atmosphereAltitude={0.12}
        />

      </div>

    </div>
  );
}
