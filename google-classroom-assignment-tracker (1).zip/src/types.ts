export interface Course {
  id: string;
  name: string;
  section?: string;
  descriptionHeading?: string;
  description?: string;
  alternateLink?: string;
  color?: string; // Tailwind bg color class
}

export interface CourseWork {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  state: "PUBLISHED" | "DRAFT";
  alternateLink?: string;
  creationTime: string;
  updateTime: string;
  maxPoints?: number;
  dueDate?: {
    year: number;
    month: number;
    day: number;
  };
  dueTime?: {
    hours: number;
    minutes?: number;
  };
  workType: "ASSIGNMENT" | "SHORT_ANSWER_QUESTION" | "MULTIPLE_CHOICE_QUESTION";
}

export type SubmissionState = "NEW" | "CREATED" | "TURNED_IN" | "RETURNED" | "RECLAIMED_BY_STUDENT";

export interface StudentSubmission {
  id: string;
  courseId: string;
  courseWorkId: string;
  userId: string;
  state: SubmissionState;
  assignedGrade?: number;
  draftGrade?: number;
  alternateLink?: string;
}

export type AssignmentUIState = "assigned" | "missing" | "submitted" | "graded";

export interface UnifiedAssignment {
  id: string;
  courseId: string;
  courseName: string;
  courseColor: string;
  title: string;
  description?: string;
  maxPoints?: number;
  dueDate: Date | null;
  state: AssignmentUIState;
  grade?: number;
  alternateLink?: string;
  updateTime: string;
}

export interface SyncConfig {
  autoSync: boolean;
  intervalSec: number;
}

export interface NotificationItem {
  id: string;
  type: "new" | "graded" | "due_soon" | "sync" | "warning";
  message: string;
  timestamp: Date;
  read?: boolean;
  assignmentId?: string;
  assignmentTitle?: string;
}

export interface Contact {
  id: string;
  name: string;
  email?: string;
  photoUrl?: string;
  phone?: string;
  role: string; // "classmate" | "teacher" | "other"
  title?: string;
}

export interface SharedHomework {
  id: string;
  courseId: string;
  courseName: string;
  courseColor: string;
  title: string;
  description?: string;
  dueDate: string | null; // ISO string
  maxPoints?: number;
  createdBy: string;
  createdById: string;
  gradeLevel: string; // "Grade 9" | "Grade 10" | "Grade 11" | "Grade 12" | "All Grades"
  updatedAt: string;
}

export interface DashboardData {
  courses: Array<{
    id: string;
    name: string;
    section: string;
    descriptionHeading: string;
    room?: string;
    alternateLink: string;
    colorTheme: string;
  }>;
  assignments: Array<{
    id: string;
    courseId: string;
    courseName: string;
    title: string;
    description: string;
    dueDate: {
      year: number;
      month: number;
      day: number;
    };
    dueTime: {
      hours: number;
      minutes: number;
    };
    maxPoints: number;
    alternateLink: string;
  }>;
  submissions: Array<{
    id: string;
    courseId: string;
    courseWorkId: string;
    courseWorkTitle?: string;
    assignedGrade?: number;
    state: string;
    alternateLink: string;
  }>;
  announcements: Array<{
    id: string;
    courseId: string;
    courseName: string;
    text: string;
    creationTime: string;
    alternateLink: string;
    authorName: string;
  }>;
}
